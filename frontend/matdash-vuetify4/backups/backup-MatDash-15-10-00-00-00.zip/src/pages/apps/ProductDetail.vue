<script setup>
import { ref, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import ProductCard from "../../components/apps/ProductCard.vue";
import { demo, money, addToCart } from "../../composables/useDemoStore";
import { notify } from "../../composables/useFeedback";
const route = useRoute(),
  router = useRouter();
const product = computed(() =>
  demo.products.find((p) => p.id === Number(route.params.id)),
);
const quantity = ref(1),
  color = ref("#ff6692"),
  tab = ref("Description"),
  image = ref("");
const related = computed(() =>
  demo.products.filter((p) => p.id !== product.value?.id).slice(0, 4),
);
function add(buy = false) {
  addToCart(product.value.id, quantity.value);
  if (buy) router.push("/ecommerce/checkout");
  else notify("Added to your demo cart.");
}
</script>
<template>
  <WorkspacePage title="Product Detail"
    ><template v-if="product"
      ><v-card class="workspace-card product-detail"
        ><div>
          <img
            :src="image || product.image"
            :alt="product.name"
            class="product-hero"
          />
          <div class="product-thumbnails">
            <button
              v-for="src in [product.image, ...related.map((p) => p.image)]"
              :key="src"
              @click="image = src"
              :aria-label="'Preview ' + src.split('/').at(-1)"
            >
              <img :src="src" alt="Product gallery view" />
            </button>
          </div>
        </div>
        <div class="product-detail-copy">
          <div class="d-flex align-center ga-2">
            <v-chip
              :color="product.stock ? 'success' : 'error'"
              size="small"
              rounded="sm"
              >{{ product.stock ? "In Stock" : "Out of Stock" }}</v-chip
            ><span class="text-caption muted">{{ product.category }}</span>
          </div>
          <h1>{{ product.name }}</h1>
          <p class="muted">{{ product.description }}</p>
          <div class="detail-price">
            <del>{{ money(product.oldPrice) }}</del
            ><strong>{{ money(product.price) }}</strong>
          </div>
          <div class="d-flex align-center ga-3">
            <v-rating
              :model-value="product.rating"
              readonly
              color="warning"
              active-color="warning"
              size="20"
              density="compact"
            /><span class="text-caption muted">(236 reviews)</span>
          </div>
          <v-divider class="my-6" />
          <div class="d-flex align-center ga-4">
            <h3>Colors*</h3>
            <div class="color-choices">
              <button
                v-for="c in ['#ff6692', '#ffd648', '#635bff', '#16cdc7']"
                :key="c"
                :style="{ background: c }"
                :aria-label="'Select color ' + c"
                @click="color = c"
              >
                <Icon v-if="color === c" name="check" :size="16" />
              </button>
            </div>
          </div>
          <div class="quantity-line">
            <h3>Quantity</h3>
            <div class="quantity-control">
              <v-btn
                size="30"
                variant="text"
                :disabled="quantity <= 1"
                aria-label="Decrease quantity"
                @click="quantity--"
                >−</v-btn
              ><span>{{ quantity }}</span
              ><v-btn
                size="30"
                variant="text"
                :disabled="quantity >= Math.max(1, product.stock)"
                aria-label="Increase quantity"
                @click="quantity++"
                >+</v-btn
              >
            </div>
          </div>
          <v-divider class="my-6" />
          <div class="d-flex ga-4">
            <v-btn color="primary" :disabled="!product.stock" @click="add(true)"
              >Buy Now</v-btn
            ><v-btn color="error" :disabled="!product.stock" @click="add()"
              >Add To Cart</v-btn
            >
          </div>
          <p class="text-caption muted mt-5">
            Dispatched in 2–3 weeks<br />Sample product and delivery
            information.
          </p>
          <v-btn
            :to="'/ecommerce/edit-product?id=' + product.id"
            variant="text"
            color="primary"
            class="mt-3"
            >Edit Product</v-btn
          >
        </div></v-card
      ><v-card class="workspace-card mt-6"
        ><v-tabs v-model="tab" color="primary"
          ><v-tab value="Description">Description</v-tab
          ><v-tab value="Review">Review</v-tab></v-tabs
        >
        <div class="py-6" v-if="tab === 'Description'">
          <h3>Designed for everyday moments.</h3>
          <p class="muted mt-4">{{ product.description }}</p>
          <p class="muted mt-4">
            Carefully selected materials and considered details come together in
            a simple, dependable product. This sample description can be changed
            from Edit Product.
          </p>
        </div>
        <div v-else class="review-list">
          <div
            v-for="(name, i) in [
              'Jennie Alvarado',
              'Robert Murray',
              'Lenora Hernandez',
            ]"
            :key="name"
          >
            <strong>{{ name }}</strong
            ><v-rating
              :model-value="5 - (i % 2)"
              readonly
              density="compact"
              size="16"
              color="warning"
              active-color="warning"
            />
            <p class="muted">
              A thoughtful design with a great finish. Very happy with the
              quality.
            </p>
          </div>
        </div></v-card
      >
      <h2 class="my-6">Related Products</h2>
      <div class="related-product-grid">
        <ProductCard
          v-for="p in related"
          :key="p.id"
          :product="p"
        /></div></template
    ><v-card v-else class="workspace-empty"
      ><h2>Product not found</h2>
      <v-btn to="/ecommerce/products" color="primary"
        >Back to shop</v-btn
      ></v-card
    ></WorkspacePage
  >
</template>
