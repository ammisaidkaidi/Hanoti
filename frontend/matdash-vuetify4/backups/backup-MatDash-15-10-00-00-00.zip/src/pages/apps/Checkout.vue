<script setup>
import { ref, reactive } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import {
  demo,
  cartLines,
  cartTotal,
  money,
  nextId,
} from "../../composables/useDemoStore";
import { required, validEmail, notify } from "../../composables/useFeedback";
import { asset } from "../../data/app-seed";
const step = ref(1),
  form = ref(null),
  order = ref(null),
  method = ref("Invoice on delivery");
const billing = reactive({
  name: "",
  email: "",
  address: "",
  city: "",
  postcode: "",
  country: "United States",
});
async function next() {
  if (step.value === 2 && !(await form.value.validate()).valid) return;
  step.value++;
}
function place() {
  if (!cartLines.value.length) return;
  const value = {
    id: nextId(demo.orders),
    total: cartTotal.value,
    items: cartLines.value.map((l) => ({
      name: l.product.name,
      price: l.product.price,
      quantity: l.quantity,
    })),
    billing: { ...billing },
    method: method.value,
    date: new Date().toISOString(),
  };
  demo.orders.push(value);
  demo.cart = [];
  order.value = value;
  notify("Demo order created locally. No payment was charged.");
}
</script>
<template>
  <WorkspacePage title="Checkout"
    ><v-card class="workspace-card"
      ><div class="checkout-steps">
        <button
          v-for="(title, i) in ['Item Cart', 'Billing', 'Payment']"
          :key="title"
          :class="{ active: step === i + 1 }"
          :disabled="i + 1 > step"
          @click="step = i + 1"
        >
          <v-avatar size="36" :color="step === i + 1 ? 'primary' : 'rail'"
            ><Icon
              :name="['basket', 'invoice', 'creditcard'][i]"
              :size="20" /></v-avatar
          ><span
            ><strong>{{ title }}</strong
            ><small>{{
              ["Product Summary", "Billing Information", "Demo payment method"][
                i
              ]
            }}</small></span
          >
        </button>
      </div>
      <div v-if="order" class="workspace-empty">
        <v-avatar size="80" color="success" variant="tonal"
          ><Icon name="checks" :size="42"
        /></v-avatar>
        <h2>Demo order #{{ order.id }} created</h2>
        <p class="muted">
          {{ money(order.total) }} · Saved locally. Nothing was charged or sent.
        </p>
        <v-btn color="primary" to="/ecommerce/products"
          >Continue Shopping</v-btn
        >
      </div>
      <div v-else-if="!cartLines.length" class="workspace-empty checkout-empty">
        <img :src="asset('empty-shopping-cart-')" alt="Empty shopping cart" />
        <h2>Cart is Empty</h2>
        <v-btn color="primary" to="/ecommerce/products"
          >Go Back To Shopping</v-btn
        >
      </div>
      <template v-else
        ><div v-if="step === 1" class="checkout-layout">
          <section>
            <div
              v-for="line in cartLines"
              :key="line.productId"
              class="cart-line"
            >
              <img :src="line.product.image" :alt="line.product.name" />
              <div>
                <router-link :to="'/ecommerce/product/detail/' + line.productId"
                  ><h3>{{ line.product.name }}</h3></router-link
                >
                <p class="muted">{{ money(line.product.price) }}</p>
                <div class="quantity-control mt-2">
                  <v-btn
                    size="26"
                    variant="text"
                    :disabled="line.quantity <= 1"
                    aria-label="Decrease cart quantity"
                    @click="
                      demo.cart.find((l) => l.productId === line.productId)
                        .quantity--
                    "
                    >−</v-btn
                  ><span>{{ line.quantity }}</span
                  ><v-btn
                    size="26"
                    variant="text"
                    aria-label="Increase cart quantity"
                    @click="
                      demo.cart.find((l) => l.productId === line.productId)
                        .quantity++
                    "
                    >+</v-btn
                  >
                </div>
              </div>
              <v-spacer /><strong>{{
                money(line.product.price * line.quantity)
              }}</strong
              ><v-btn
                icon
                size="30"
                color="error"
                variant="text"
                :aria-label="'Remove ' + line.product.name"
                @click="
                  demo.cart = demo.cart.filter(
                    (l) => l.productId !== line.productId,
                  )
                "
                ><Icon name="trash" :size="18"
              /></v-btn>
            </div>
          </section>
          <v-card variant="outlined" class="order-summary"
            ><h2>Order Summary</h2>
            <p>
              <span>Subtotal</span><strong>{{ money(cartTotal) }}</strong>
            </p>
            <p><span>Shipping</span><span class="text-success">Free</span></p>
            <v-divider class="my-4" />
            <p>
              <strong>Total</strong><strong>{{ money(cartTotal) }}</strong>
            </p>
            <v-btn color="primary" block class="mt-6" @click="next"
              >Continue to Billing</v-btn
            ></v-card
          >
        </div>
        <v-form
          v-else-if="step === 2"
          ref="form"
          @submit.prevent="next"
          class="billing-form"
          ><h2 class="mb-6">Billing Information</h2>
          <div class="account-fields">
            <v-text-field
              v-for="key in ['name', 'email', 'address', 'city', 'postcode']"
              :key="key"
              v-model="billing[key]"
              :label="key.charAt(0).toUpperCase() + key.slice(1)"
              :rules="key === 'email' ? [required, validEmail] : [required]"
              hide-details="auto"
            /><v-select
              v-model="billing.country"
              label="Country"
              :items="[
                'United States',
                'United Kingdom',
                'Algeria',
                'India',
                'France',
              ]"
            />
          </div>
          <div class="workspace-actions mt-6">
            <v-btn variant="text" @click="step--">Back</v-btn
            ><v-btn color="primary" type="submit">Continue to Payment</v-btn>
          </div></v-form
        >
        <div v-else class="billing-form">
          <h2>Payment</h2>
          <v-alert type="info" variant="tonal" class="my-6"
            >This is a local checkout preview. No payment details are collected
            and no charges are made.</v-alert
          ><v-radio-group v-model="method"
            ><v-radio
              label="Invoice on delivery"
              value="Invoice on delivery"
              color="primary" /><v-radio
              label="Demo card ending in 2102"
              value="Demo card ending in 2102"
              color="primary"
          /></v-radio-group>
          <div class="order-summary">
            <h3>Deliver to {{ billing.name }}</h3>
            <p>
              {{ billing.address }}, {{ billing.city }}, {{ billing.country }}
            </p>
            <p>
              <strong>Order total</strong
              ><strong>{{ money(cartTotal) }}</strong>
            </p>
          </div>
          <div class="workspace-actions mt-6">
            <v-btn variant="text" @click="step--">Back</v-btn
            ><v-btn color="primary" @click="place">Place Demo Order</v-btn>
          </div>
        </div></template
      ><v-btn
        v-if="!order"
        variant="tonal"
        color="primary"
        to="/ecommerce/products"
        class="mt-6"
        >Continue Shopping</v-btn
      ></v-card
    ></WorkspacePage
  >
</template>
