<script setup>
import { ref, computed } from "vue";
const props = defineProps({ embedded: Boolean });
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import RecordDialog from "../../components/apps/RecordDialog.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { notify, confirmDemo } from "../../composables/useFeedback";
const today = new Date();
const focus = ref(
  new Date(today.getFullYear(), today.getMonth(), today.getDate()),
);
const mode = ref("Month"),
  editor = ref(false),
  record = ref({}),
  datePick = ref(new Date());
const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const iso = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const heading = computed(() =>
  focus.value.toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
    ...(mode.value === "Day" ? { day: "numeric" } : {}),
  }),
);
const days = computed(() => {
  const date = new Date(focus.value);
  let count = 42;
  if (mode.value === "Month") {
    date.setDate(1);
    date.setDate(date.getDate() - date.getDay());
  } else if (mode.value === "Week") {
    date.setDate(date.getDate() - date.getDay());
    count = 7;
  } else count = 1;
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(date);
    d.setDate(date.getDate() + i);
    return {
      date: d,
      key: iso(d),
      day: d.getDate(),
      outside: d.getMonth() !== focus.value.getMonth(),
      today: iso(d) === iso(today),
    };
  });
});
const fields = [
  { key: "title", label: "Event title", required: true },
  { key: "date", label: "Start date", type: "date", required: true },
  { key: "end", label: "End date (optional)", type: "date" },
  { key: "time", label: "Time", type: "time", required: true },
  { key: "color", label: "Event color", type: "color" },
];
function edit(event, date) {
  record.value = event
    ? { ...event }
    : {
        title: "",
        date: date || iso(focus.value),
        end: "",
        time: "09:00",
        color: "#635bff",
      };
  editor.value = true;
}
function save(event) {
  if (event.end && event.end < event.date)
    return notify("End date must not be before the start date.", "error");
  if (event.id)
    demo.events.splice(
      demo.events.findIndex((e) => e.id === event.id),
      1,
      event,
    );
  else demo.events.push({ ...event, id: nextId(demo.events) });
  editor.value = false;
  notify("Calendar event saved locally.");
}
function move(n) {
  const d = new Date(focus.value);
  if (mode.value === "Month") {
    d.setDate(1);
    d.setMonth(d.getMonth() + n);
  } else d.setDate(d.getDate() + n * (mode.value === "Week" ? 7 : 1));
  focus.value = d;
}
async function remove(event) {
  if (await confirmDemo("Delete " + event.title + "?"))
    demo.events = demo.events.filter((e) => e.id !== event.id);
}
const onDay = (key) =>
  demo.events.filter((e) => e.date <= key && (e.end || e.date) >= key);
</script>
<template>
  <component :is="props.embedded ? 'div' : WorkspacePage" title="Calendar"
    ><v-card class="workspace-card"
      ><div class="d-flex align-center justify-space-between mb-6">
        <h2>Full Calendar</h2>
        <v-btn color="primary" @click="edit()">Add Event</v-btn>
      </div>
      <div class="calendar-toolbar">
        <div class="d-flex ga-1">
          <v-btn
            icon
            variant="tonal"
            size="34"
            aria-label="Previous period"
            @click="move(-1)"
            ><Icon name="back" :size="17" /></v-btn
          ><v-btn
            icon
            variant="tonal"
            size="34"
            aria-label="Next period"
            @click="move(1)"
            ><Icon name="right" :size="17" /></v-btn
          ><v-btn color="primary" class="ml-2" @click="focus = new Date()"
            >Today</v-btn
          >
        </div>
        <h2>{{ heading }}</h2>
        <v-btn-toggle
          v-model="mode"
          mandatory
          color="primary"
          density="compact"
          divided
          ><v-btn v-for="m in ['Month', 'Week', 'Day']" :key="m" :value="m">{{
            m
          }}</v-btn></v-btn-toggle
        >
      </div>
      <div class="calendar-scroll">
        <div :class="['calendar-grid', { 'day-view': mode === 'Day' }]">
          <template v-if="mode !== 'Day'"
            ><div v-for="day in weekdays" :key="day" class="calendar-weekday">
              {{ day }}
            </div></template
          >
          <div
            v-for="day in days"
            :key="day.key"
            :class="[
              'calendar-cell',
              { outside: day.outside, today: day.today },
            ]"
            tabindex="0"
            role="button"
            :aria-label="'Add event on ' + day.key"
            @click="edit(null, day.key)"
            @keydown.enter="edit(null, day.key)"
          >
            <span>{{ day.day }}</span
            ><button
              v-for="event in onDay(day.key)"
              :key="event.id"
              class="calendar-event"
              :style="{ background: event.color }"
              @click.stop="edit(event)"
            >
              {{ mode === "Month" ? "" : event.time + " " }}{{ event.title }}
            </button>
          </div>
        </div>
      </div></v-card
    >
    <div v-if="!props.embedded" class="calendar-extras">
      <v-card class="workspace-card"
        ><h2>Calendar with Date</h2>
        <v-date-picker
          v-model="datePick"
          color="primary"
          width="100%"
          @update:model-value="
            (value) => {
              if (value) focus = new Date(value);
            }
          " /></v-card
      ><v-card class="workspace-card"
        ><h2>Upcoming Events</h2>
        <div
          v-for="event in [...demo.events].sort((a, b) =>
            a.date.localeCompare(b.date),
          )"
          :key="event.id"
          class="agenda-row"
        >
          <i :style="{ background: event.color }" />
          <div>
            <button class="text-button" @click="edit(event)">
              {{ event.title }}
            </button>
            <p class="muted text-caption">
              {{ event.date }} · {{ event.time }}
            </p>
          </div>
          <v-btn
            icon
            size="28"
            variant="text"
            :aria-label="'Delete event ' + event.title"
            @click="remove(event)"
            ><Icon name="trash" :size="15"
          /></v-btn></div
      ></v-card>
    </div>
    <RecordDialog
      v-model="editor"
      :title="record.id ? 'Edit Event' : 'Add Event'"
      :record="record"
      :fields="fields"
      @save="save"
  /></component>
</template>
