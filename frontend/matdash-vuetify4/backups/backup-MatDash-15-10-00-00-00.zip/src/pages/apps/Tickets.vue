<script setup>
import { ref, computed } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import RecordDialog from "../../components/apps/RecordDialog.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { notify, confirmDemo } from "../../composables/useFeedback";
import { avatar } from "../../data/app-seed";
const search = ref(""),
  status = ref("All"),
  editor = ref(false),
  record = ref({});
const colors = {
  All: "primary",
  Pending: "warning",
  Open: "success",
  Closed: "error",
};
const filtered = computed(() =>
  demo.tickets.filter(
    (t) => status.value === "All" || t.status === status.value,
  ),
);
const headers = [
  { title: "Id", key: "id" },
  { title: "Ticket", key: "title" },
  { title: "Assigned To", key: "assigned" },
  { title: "Status", key: "status" },
  { title: "Date", key: "date" },
  { title: "Action", key: "actions", sortable: false },
];
const fields = [
  { key: "title", label: "Ticket title", required: true },
  {
    key: "description",
    label: "Description",
    type: "textarea",
    required: true,
  },
  {
    key: "assigned",
    label: "Assigned to",
    items: ["Liam", "Steve", "Jack"],
    required: true,
  },
  {
    key: "status",
    label: "Status",
    items: ["Open", "Pending", "Closed"],
    required: true,
  },
  {
    key: "priority",
    label: "Priority",
    items: ["Low", "Medium", "High"],
    required: true,
  },
];
function edit(t) {
  record.value = t
    ? { ...t }
    : {
        title: "",
        description: "",
        assigned: "Liam",
        status: "Open",
        priority: "Medium",
        date: new Date().toISOString().slice(0, 10),
      };
  editor.value = true;
}
function save(t) {
  if (t.id)
    demo.tickets.splice(
      demo.tickets.findIndex((x) => x.id === t.id),
      1,
      t,
    );
  else demo.tickets.push({ ...t, id: nextId(demo.tickets) });
  editor.value = false;
  notify("Ticket saved locally.");
}
async function remove(t) {
  if (await confirmDemo("Delete ticket #" + t.id + "?"))
    demo.tickets = demo.tickets.filter((x) => x.id !== t.id);
}
</script>
<template>
  <WorkspacePage title="Tickets App"
    ><v-card class="workspace-card"
      ><div class="ticket-metrics">
        <button
          v-for="s in ['All', 'Pending', 'Open', 'Closed']"
          :key="s"
          :class="[
            'ticket-metric',
            'metric-' + colors[s],
            { chosen: status === s },
          ]"
          @click="status = s"
        >
          <strong>{{
            s === "All"
              ? demo.tickets.length
              : demo.tickets.filter((t) => t.status === s).length
          }}</strong
          ><span>{{ s === "All" ? "Total" : s }} Tickets</span>
        </button>
      </div>
      <div class="workspace-toolbar">
        <v-btn color="primary" @click="edit()">Create Ticket</v-btn
        ><v-spacer /><v-text-field
          v-model="search"
          label="Search Tickets"
          density="compact"
          clearable
        />
      </div>
      <v-data-table
        :headers="headers"
        :items="filtered"
        :search="search"
        :items-per-page="10"
        class="workspace-table"
        ><template #item.title="{ item }"
          ><button class="text-button ticket-title" @click="edit(item)">
            <strong>{{ item.title }}</strong
            ><span>{{ item.description }}</span>
          </button></template
        ><template #item.assigned="{ item }"
          ><div class="person-cell">
            <v-avatar size="32"
              ><img
                :src="avatar((item.id % 6) + 2)"
                :alt="item.assigned" /></v-avatar
            >{{ item.assigned }}
          </div></template
        ><template #item.status="{ item }"
          ><v-chip :color="colors[item.status]" size="small" rounded="sm">{{
            item.status
          }}</v-chip></template
        ><template #item.actions="{ item }"
          ><v-btn
            icon
            size="30"
            color="error"
            variant="tonal"
            :aria-label="'Delete ticket ' + item.id"
            @click="remove(item)"
            ><Icon
              name="trash"
              :size="15" /></v-btn></template></v-data-table></v-card
    ><RecordDialog
      v-model="editor"
      :title="record.id ? 'Edit Ticket' : 'Create Ticket'"
      :record="record"
      :fields="fields"
      @save="save"
  /></WorkspacePage>
</template>
