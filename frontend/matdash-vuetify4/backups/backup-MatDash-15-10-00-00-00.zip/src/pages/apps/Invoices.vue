<script setup>
import { ref, computed } from "vue";
import { useRoute, useRouter } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import {
  demo,
  nextId,
  clone,
  money,
  invoiceSubtotal,
  invoiceTotal,
  downloadText,
} from "../../composables/useDemoStore";
import { notify, confirmDemo, required } from "../../composables/useFeedback";
const route = useRoute(),
  router = useRouter();
const mode = route.path.includes("/details/")
  ? "detail"
  : route.path.includes("/edit/")
    ? "edit"
    : route.path.endsWith("/create")
      ? "create"
      : "list";
const existing = demo.invoices.find((i) => i.id === Number(route.params.id));
const form = ref(null),
  search = ref(""),
  status = ref("All");
const draft = ref(
  clone(
    existing || {
      id: nextId(demo.invoices),
      from: "",
      to: "",
      fromAddress: "",
      toAddress: "",
      fromEmail: "",
      toEmail: "",
      date: new Date().toISOString().slice(0, 10),
      status: "Pending",
      vat: 10,
      items: [{ name: "", price: 0, quantity: 1 }],
    },
  ),
);
const title = {
  list: "Invoice List",
  detail: "Invoice Details",
  edit: "Edit Invoice",
  create: "Create Invoice",
}[mode];
const colors = {
  All: "primary",
  Shipped: "success",
  Delivered: "secondary",
  Pending: "warning",
};
const filtered = computed(() =>
  demo.invoices.filter(
    (i) => status.value === "All" || i.status === status.value,
  ),
);
const headers = [
  { title: "ID", key: "id" },
  { title: "BILL FROM", key: "from" },
  { title: "BILL TO", key: "to" },
  { title: "TOTAL COST", key: "total" },
  { title: "STATUS", key: "status" },
  { title: "ACTION", key: "actions", sortable: false },
];
async function save() {
  if (!(await form.value.validate()).valid) return;
  if (!draft.value.items.length)
    return notify("Add at least one line item.", "error");
  if (mode === "edit")
    demo.invoices.splice(
      demo.invoices.findIndex((i) => i.id === draft.value.id),
      1,
      clone(draft.value),
    );
  else demo.invoices.push(clone(draft.value));
  notify("Invoice saved locally.");
  router.push("/apps/invoice/details/" + draft.value.id);
}
async function remove(i) {
  if (await confirmDemo("Delete invoice #" + i.id + "?"))
    demo.invoices = demo.invoices.filter((x) => x.id !== i.id);
}
function exportInvoice() {
  const i = draft.value;
  downloadText(
    `invoice-${i.id}.txt`,
    `INVOICE #${i.id}\n${i.date}\n\nBill from: ${i.from}\n${i.fromAddress}\nBill to: ${i.to}\n${i.toAddress}\n\n${i.items.map((l) => `${l.name}: ${l.quantity} x ${money(l.price)} = ${money(l.price * l.quantity)}`).join("\n")}\n\nSubtotal: ${money(invoiceSubtotal(i))}\nVAT: ${i.vat}%\nTotal: ${money(invoiceTotal(i))}\n\nLocal demo invoice — not sent.`,
  );
}
</script>
<template>
  <WorkspacePage :title="title"
    ><v-card v-if="mode === 'list'" class="workspace-card"
      ><div class="invoice-metrics">
        <button
          v-for="s in ['All', 'Shipped', 'Delivered', 'Pending']"
          :key="s"
          :class="{ selected: status === s }"
          @click="status = s"
        >
          <v-avatar :color="colors[s]" variant="tonal" size="46"
            ><Icon name="invoice" :size="23"
          /></v-avatar>
          <div>
            <strong>{{ s === "All" ? "Total" : s }}</strong
            ><small
              >{{
                demo.invoices.filter((i) => s === "All" || i.status === s)
                  .length
              }}
              invoices</small
            ><span>{{
              money(
                demo.invoices
                  .filter((i) => s === "All" || i.status === s)
                  .reduce((sum, i) => sum + invoiceTotal(i), 0),
              )
            }}</span>
          </div>
        </button>
      </div>
      <div class="workspace-toolbar">
        <v-text-field
          v-model="search"
          label="Search Invoice"
          density="compact"
        /><v-spacer /><v-btn color="primary" to="/apps/invoice/create"
          >New Invoice</v-btn
        >
      </div>
      <v-data-table
        :headers="headers"
        :items="filtered"
        :search="search"
        :items-per-page="10"
        class="workspace-table"
        ><template #item.id="{ item }"
          ><router-link :to="'/apps/invoice/details/' + item.id">{{
            item.id
          }}</router-link></template
        ><template #item.total="{ item }">{{
          money(invoiceTotal(item))
        }}</template
        ><template #item.status="{ item }"
          ><v-chip :color="colors[item.status]" size="small" rounded="sm">{{
            item.status
          }}</v-chip></template
        ><template #item.actions="{ item }"
          ><div class="row-actions">
            <v-btn
              icon
              variant="tonal"
              size="29"
              color="success"
              :to="'/apps/invoice/edit/' + item.id"
              :aria-label="'Edit invoice ' + item.id"
              ><Icon name="edit" :size="14" /></v-btn
            ><v-btn
              icon
              variant="tonal"
              size="29"
              color="primary"
              :to="'/apps/invoice/details/' + item.id"
              :aria-label="'View invoice ' + item.id"
              ><Icon name="eye" :size="14" /></v-btn
            ><v-btn
              icon
              variant="tonal"
              size="29"
              color="error"
              :aria-label="'Delete invoice ' + item.id"
              @click="remove(item)"
              ><Icon name="trash" :size="14"
            /></v-btn></div></template></v-data-table
    ></v-card>
    <v-card
      v-else-if="(mode === 'detail' || mode === 'edit') && !existing"
      class="workspace-empty"
      ><h2>Invoice not found</h2>
      <p class="muted">
        This invoice may have been deleted from the local workspace.
      </p>
      <v-btn to="/apps/invoice" color="primary">Back to invoices</v-btn></v-card
    >
    <v-card v-else class="workspace-card invoice-sheet"
      ><v-form ref="form" @submit.prevent="save"
        ><div class="invoice-heading">
          <img
            v-if="mode === 'detail'"
            src="/assets/logo-Dq6uoD-m.svg"
            alt="MatDash"
            width="135"
          />
          <div v-else>
            <h2>{{ mode === "edit" ? "Edit" : "Add New" }} Invoice Details</h2>
            <p class="muted mt-5">
              ID: {{ draft.id }}<br />Date: {{ draft.date }}
            </p>
          </div>
          <div v-if="mode === 'detail'" class="text-right">
            <v-chip :color="colors[draft.status]" size="small">{{
              draft.status
            }}</v-chip>
            <h3 class="mt-2"># {{ draft.id }}</h3>
          </div>
        </div>
        <div v-if="mode === 'detail'" class="invoice-addresses">
          <div>
            <h3>Bill From</h3>
            <p>{{ draft.from }}</p>
            <p>{{ draft.fromEmail }}</p>
            <p>{{ draft.fromAddress }}</p>
          </div>
          <div class="text-right">
            <h3>Bill To</h3>
            <p>{{ draft.to }}</p>
            <p>{{ draft.toEmail }}</p>
            <p>{{ draft.toAddress }}</p>
          </div>
        </div>
        <div v-else class="invoice-fields">
          <v-text-field
            v-model="draft.from"
            label="Bill From"
            :rules="[required]"
            hide-details="auto"
          /><v-text-field
            v-model="draft.to"
            label="Bill To"
            :rules="[required]"
            hide-details="auto"
          /><v-select
            v-model="draft.status"
            label="Status"
            :items="['Shipped', 'Delivered', 'Pending']"
          /><v-text-field
            v-model="draft.fromAddress"
            label="From Address"
            :rules="[required]"
            hide-details="auto"
          /><v-text-field
            v-model="draft.toAddress"
            label="Bill To Address"
            :rules="[required]"
            hide-details="auto"
          /><v-text-field
            v-model="draft.vat"
            type="number"
            min="0"
            max="100"
            label="VAT (%)"
            :rules="[
              (v) => (Number(v) >= 0 && Number(v) <= 100) || 'Use 0–100%',
            ]"
            hide-details="auto"
          />
        </div>
        <v-table class="invoice-items"
          ><thead>
            <tr>
              <th>Item Name</th>
              <th>Unit Price</th>
              <th>Units</th>
              <th>Total Cost</th>
              <th v-if="mode !== 'detail'"></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(line, index) in draft.items" :key="index">
              <template v-if="mode === 'detail'"
                ><td>{{ line.name }}</td>
                <td>{{ money(line.price) }}</td>
                <td>{{ line.quantity }}</td></template
              ><template v-else
                ><td>
                  <v-text-field
                    v-model="line.name"
                    label="Item Name"
                    :rules="[required]"
                    density="compact"
                    hide-details="auto"
                  />
                </td>
                <td>
                  <v-text-field
                    v-model.number="line.price"
                    type="number"
                    min="0"
                    label="Unit Price"
                    :rules="[
                      (v) => (Number(v) >= 0 && v !== '') || 'Enter a price',
                    ]"
                    density="compact"
                    hide-details="auto"
                  />
                </td>
                <td>
                  <v-text-field
                    v-model.number="line.quantity"
                    type="number"
                    min="1"
                    label="Units"
                    :rules="[(v) => Number(v) > 0 || 'Use at least 1']"
                    density="compact"
                    hide-details="auto"
                  /></td
              ></template>
              <td>{{ money(line.price * line.quantity) }}</td>
              <td v-if="mode !== 'detail'">
                <v-btn
                  icon
                  size="30"
                  variant="text"
                  :disabled="draft.items.length === 1"
                  aria-label="Remove line"
                  @click="draft.items.splice(index, 1)"
                  ><Icon name="trash" :size="17"
                /></v-btn>
              </td>
            </tr></tbody></v-table
        ><v-btn
          v-if="mode !== 'detail'"
          color="primary"
          variant="tonal"
          class="mt-4"
          @click="draft.items.push({ name: '', price: 0, quantity: 1 })"
          ><Icon name="plus" :size="17" class="mr-2" />Add Item</v-btn
        >
        <div class="invoice-totals">
          <p>
            <span>Sub Total:</span
            ><strong>{{ money(invoiceSubtotal(draft)) }}</strong>
          </p>
          <p>
            <span>VAT ({{ draft.vat }}%):</span
            ><strong>{{
              money((invoiceSubtotal(draft) * draft.vat) / 100)
            }}</strong>
          </p>
          <p>
            <span>Grand Total:</span
            ><strong>{{ money(invoiceTotal(draft)) }}</strong>
          </p>
        </div>
        <div class="workspace-actions">
          <template v-if="mode === 'detail'"
            ><v-btn variant="outlined" @click="exportInvoice">Download</v-btn
            ><v-btn color="primary" :to="'/apps/invoice/edit/' + draft.id"
              >Edit Invoice</v-btn
            ><v-btn variant="tonal" color="primary" to="/apps/invoice"
              >Back To Invoice List</v-btn
            ></template
          ><template v-else
            ><v-btn color="primary" type="submit">{{
              mode === "create" ? "Create Invoice" : "Save"
            }}</v-btn
            ><v-btn color="error" variant="tonal" to="/apps/invoice"
              >Cancel</v-btn
            ></template
          >
        </div></v-form
      ></v-card
    ></WorkspacePage
  >
</template>
