<script setup>
import { ref, computed } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import {
  required,
  validEmail,
  notify,
  confirmDemo,
} from "../../composables/useFeedback";
import { avatar } from "../../data/app-seed";
const folder = ref("Inbox"),
  search = ref(""),
  selected = ref(demo.mails[0]?.id),
  composer = ref(false),
  form = ref(null),
  draft = ref({ to: "", subject: "", body: "" });
const folders = ["Inbox", "Sent", "Draft", "Spam", "Trash"];
const labelColors = {
  Promotional: "primary",
  Social: "error",
  Health: "success",
};
const filtered = computed(() =>
  demo.mails.filter(
    (m) =>
      (folder.value === "Starred"
        ? m.starred
        : folder.value === "Important"
          ? m.important
          : ["Promotional", "Social", "Health"].includes(folder.value)
            ? m.label === folder.value
            : m.folder === folder.value) &&
      (m.subject + " " + m.from + " " + m.body)
        .toLowerCase()
        .includes((search.value || "").toLowerCase()),
  ),
);
const mail = computed(
  () =>
    filtered.value.find((m) => m.id === selected.value) || filtered.value[0],
);
function open(m) {
  selected.value = m.id;
  m.read = true;
}
function compose(reply = false, forward = false) {
  draft.value = {
    to: reply ? mail.value?.email || "" : "",
    subject:
      (reply ? "Re: " : forward ? "Fwd: " : "") +
      (reply || forward ? mail.value?.subject || "" : ""),
    body: forward ? "\n\nForwarded message:\n" + mail.value?.body : "",
  };
  composer.value = true;
}
function savedMail(target) {
  demo.mails.unshift({
    ...draft.value,
    id: nextId(demo.mails),
    from: "David McMichael",
    email: "david@example.com",
    folder: target,
    label: "Social",
    read: true,
    starred: false,
    important: false,
    date: new Date().toISOString().slice(0, 10),
  });
  composer.value = false;
  folder.value = target;
  selected.value = demo.mails[0].id;
  notify(
    target === "Sent"
      ? "Message saved to the local Sent folder. No email was sent."
      : "Draft saved locally.",
  );
}
async function send() {
  if ((await form.value.validate()).valid) savedMail("Sent");
}
async function remove() {
  const m = mail.value;
  if (!m) return;
  if (m.folder === "Trash") {
    if (await confirmDemo("Permanently delete this sample email?"))
      demo.mails = demo.mails.filter((x) => x.id !== m.id);
  } else {
    m.folder = "Trash";
    notify("Moved to local Trash.");
  }
}
</script>
<template>
  <WorkspacePage title="Email App"
    ><v-card class="email-layout"
      ><aside class="email-folders">
        <v-btn color="primary" block class="mb-5" @click="compose()"
          >Compose</v-btn
        ><button
          v-for="name in folders"
          :key="name"
          :class="{ active: folder === name }"
          @click="folder = name"
        >
          {{ name
          }}<small>{{
            demo.mails.filter((m) => m.folder === name).length || ""
          }}</small>
        </button>
        <h4>SORT BY</h4>
        <button
          v-for="name in ['Starred', 'Important']"
          :key="name"
          :class="{ active: folder === name }"
          @click="folder = name"
        >
          {{ name }}
        </button>
        <h4>LABELS</h4>
        <button
          v-for="name in ['Promotional', 'Social', 'Health']"
          :key="name"
          :class="{ active: folder === name }"
          @click="folder = name"
        >
          <i :class="'label-dot bg-' + labelColors[name]" />{{ name }}
        </button>
      </aside>
      <section class="email-messages">
        <div class="pa-5">
          <v-text-field
            v-model="search"
            label="Search Emails"
            density="compact"
          />
        </div>
        <button
          v-for="m in filtered"
          :key="m.id"
          :class="[
            'email-preview',
            { active: mail?.id === m.id, unread: !m.read },
          ]"
          @click="open(m)"
        >
          <div>
            <strong>{{ m.from }}</strong
            ><v-chip
              :color="labelColors[m.label]"
              size="x-small"
              rounded="sm"
              >{{ m.label }}</v-chip
            >
          </div>
          <p>{{ m.subject }}</p>
          <small>{{ m.date }}</small>
        </button>
        <p v-if="!filtered.length" class="muted pa-6">
          No messages in this view.
        </p>
      </section>
      <section class="email-detail" v-if="mail">
        <div class="mail-actions">
          <v-btn
            icon
            variant="text"
            size="32"
            :color="mail.starred ? 'warning' : undefined"
            aria-label="Toggle starred"
            @click="mail.starred = !mail.starred"
            ><Icon name="star" :size="18" /></v-btn
          ><v-btn
            icon
            variant="text"
            size="32"
            :color="mail.important ? 'primary' : undefined"
            aria-label="Toggle important"
            @click="mail.important = !mail.important"
            ><Icon name="info" :size="18" /></v-btn
          ><v-btn
            icon
            variant="text"
            size="32"
            aria-label="Delete email"
            @click="remove"
            ><Icon name="trash" :size="18"
          /></v-btn>
        </div>
        <div class="person-cell mt-5">
          <v-avatar size="42"
            ><img :src="avatar(10)" :alt="mail.from"
          /></v-avatar>
          <div>
            <strong>{{ mail.from }}</strong
            ><span>{{ mail.email }}</span>
          </div>
          <v-spacer /><v-chip :color="labelColors[mail.label]" size="small">{{
            mail.label
          }}</v-chip>
        </div>
        <h2 class="my-6">{{ mail.subject }}</h2>
        <p class="mail-body">{{ mail.body }}</p>
        <v-divider class="my-7" />
        <div class="d-flex ga-3">
          <v-btn variant="outlined" @click="compose(true)"
            ><Icon name="back" :size="16" class="mr-2" />Reply</v-btn
          ><v-btn variant="outlined" @click="compose(false, true)"
            >Forward<Icon name="right" :size="16" class="ml-2"
          /></v-btn>
        </div>
      </section>
      <section v-else class="workspace-empty">
        <Icon name="email" :size="42" />
        <h3>No email selected</h3>
      </section></v-card
    ><v-dialog v-model="composer" max-width="650"
      ><v-card class="dialog-body"
        ><div class="dialog-title">
          <h2>New Message</h2>
          <v-btn
            icon
            size="30"
            variant="text"
            aria-label="Close composer"
            @click="composer = false"
            ><Icon name="close"
          /></v-btn>
        </div>
        <v-form ref="form" @submit.prevent="send"
          ><div class="record-fields">
            <v-text-field
              v-model="draft.to"
              label="To"
              :rules="[required, validEmail]"
              hide-details="auto"
            /><v-text-field
              v-model="draft.subject"
              label="Subject"
              :rules="[required]"
              hide-details="auto"
            /><v-textarea
              v-model="draft.body"
              label="Message"
              rows="8"
              variant="outlined"
              :rules="[required]"
              hide-details="auto"
            />
          </div>
          <p class="demo-caption mt-4">
            Local demonstration only. Messages are not delivered.
          </p>
          <div class="dialog-actions">
            <v-btn variant="tonal" @click="savedMail('Draft')">Save Draft</v-btn
            ><v-btn color="primary" type="submit">Send Demo Message</v-btn>
          </div></v-form
        ></v-card
      ></v-dialog
    ></WorkspacePage
  >
</template>
