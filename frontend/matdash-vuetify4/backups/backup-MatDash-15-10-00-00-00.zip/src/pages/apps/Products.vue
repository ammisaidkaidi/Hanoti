<script setup>
import { ref, computed } from "vue";
import { useRoute } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import ProductCard from "../../components/apps/ProductCard.vue";
import { demo, money } from "../../composables/useDemoStore";
import { confirmDemo } from "../../composables/useFeedback";
const list = useRoute().path.endsWith("productlist");
const search = ref(""),
  categories = ref([]),
  gender = ref([]),
  price = ref("All prices"),
  rating = ref(0),
  sort = ref("Price: low to high");
const priceOptions = [
  "All prices",
  "$10 - $50",
  "$50 - $100",
  "$100 - $150",
  "$150 - $200",
  "Over $200",
];
const filtered = computed(() => {
  let p = demo.products.filter((p) =>
    (p.name + " " + p.category)
      .toLowerCase()
      .includes((search.value || "").toLowerCase()),
  );
  if (!list) {
    p = p.filter(
      (p) =>
        (!categories.value.length || categories.value.includes(p.category)) &&
        (!gender.value.length || gender.value.includes(p.gender)) &&
        p.rating >= rating.value,
    );
    const index = priceOptions.indexOf(price.value);
    if (index > 0)
      p = p.filter((p) =>
        index === 5
          ? p.price > 200
          : p.price >= (index - 1) * 50 && p.price <= index * 50,
      );
    p.sort((a, b) =>
      sort.value === "Name"
        ? a.name.localeCompare(b.name)
        : sort.value === "Price: high to low"
          ? b.price - a.price
          : a.price - b.price,
    );
  }
  return p;
});
const headers = [
  { title: "Product Image", key: "name" },
  { title: "Category", key: "category" },
  { title: "Date", key: "date" },
  { title: "Status", key: "stock" },
  { title: "Price", key: "price" },
  { title: "Actions", key: "actions", sortable: false },
];
function reset() {
  categories.value = [];
  gender.value = [];
  price.value = "All prices";
  rating.value = 0;
  search.value = "";
}
async function remove(p) {
  if (await confirmDemo("Delete " + p.name + "?")) {
    demo.products = demo.products.filter((x) => x.id !== p.id);
    demo.cart = demo.cart.filter((x) => x.productId !== p.id);
  }
}
</script>
<template>
  <WorkspacePage :title="list ? 'Product List' : 'Shop'"
    ><v-card v-if="list" class="workspace-card"
      ><div class="workspace-toolbar">
        <v-text-field
          v-model="search"
          label="Search"
          density="compact"
        /><v-spacer /><v-btn color="primary" to="/ecommerce/add-product"
          >Add New Item</v-btn
        >
      </div>
      <v-data-table
        :headers="headers"
        :items="filtered"
        :items-per-page="5"
        class="workspace-table"
        ><template #item.name="{ item }"
          ><router-link
            class="person-cell"
            :to="'/ecommerce/product/detail/' + item.id"
            ><v-avatar rounded="lg" size="50"
              ><img :src="item.image" :alt="item.name"
            /></v-avatar>
            <div>
              <strong>{{ item.name }}</strong
              ><span>{{ item.category }}</span>
            </div></router-link
          ></template
        ><template #item.date="{ item }">{{
          item.date || "Oct 14, 2026"
        }}</template
        ><template #item.stock="{ item }"
          ><v-chip :color="item.stock > 0 ? 'success' : 'error'" size="small">{{
            item.stock > 0 ? "In Stock" : "Out of Stock"
          }}</v-chip></template
        ><template #item.price="{ item }">{{ money(item.price) }}</template
        ><template #item.actions="{ item }"
          ><div class="row-actions">
            <v-btn
              icon
              variant="text"
              size="30"
              color="primary"
              :to="'/ecommerce/edit-product?id=' + item.id"
              :aria-label="'Edit ' + item.name"
              ><Icon name="edit" :size="17" /></v-btn
            ><v-btn
              icon
              variant="text"
              size="30"
              color="error"
              :aria-label="'Delete ' + item.name"
              @click="remove(item)"
              ><Icon name="trash" :size="17"
            /></v-btn></div></template></v-data-table
    ></v-card>
    <v-card v-else class="shop-layout"
      ><aside class="shop-filters">
        <h3>Filter by Category</h3>
        <v-checkbox
          :model-value="!categories.length"
          label="All"
          hide-details
          density="compact"
          color="primary"
          @update:model-value="categories = []"
        /><v-checkbox
          v-for="name in [
            'Kitchen',
            'Electronics',
            'Books',
            'Fashion',
            'Toys',
            'Beauty',
          ]"
          :key="name"
          v-model="categories"
          :label="name"
          :value="name"
          hide-details
          density="compact"
          color="primary"
        />
        <h3>By Gender</h3>
        <v-checkbox
          v-for="name in ['Male', 'Female', 'Kids']"
          :key="name"
          v-model="gender"
          :label="name"
          :value="name"
          hide-details
          density="compact"
          color="primary"
        />
        <h3>By Pricing</h3>
        <v-radio-group v-model="price" hide-details
          ><v-radio
            v-for="p in priceOptions"
            :key="p"
            :label="p"
            :value="p"
            color="primary"
            density="compact"
        /></v-radio-group>
        <h3>By Rating</h3>
        <v-rating
          v-model="rating"
          clearable
          color="warning"
          active-color="warning"
          density="compact"
          size="24"
        /><v-btn
          color="primary"
          variant="tonal"
          block
          class="mt-6"
          @click="reset"
          >Reset Filters</v-btn
        >
      </aside>
      <section class="shop-content">
        <div class="workspace-toolbar">
          <h2>Products</h2>
          <v-spacer /><v-text-field
            v-model="search"
            placeholder="Search Product"
            aria-label="Search Product"
            density="compact"
            ><template #prepend-inner
              ><Icon name="search" :size="17" /></template
          ></v-text-field>
        </div>
        <div class="shop-sort">
          <span class="muted text-caption">{{ filtered.length }} products</span
          ><v-select
            v-model="sort"
            :items="['Price: low to high', 'Price: high to low', 'Name']"
            aria-label="Sort products"
          />
        </div>
        <div class="product-grid">
          <ProductCard v-for="p in filtered" :key="p.id" :product="p" />
        </div>
        <div v-if="!filtered.length" class="workspace-empty">
          <Icon name="search" :size="36" />
          <h3>No products match your filters</h3>
          <v-btn color="primary" variant="tonal" @click="reset"
            >Reset Filters</v-btn
          >
        </div>
      </section></v-card
    ></WorkspacePage
  >
</template>
