<script setup>
import { ref, computed, nextTick } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { notify } from "../../composables/useFeedback";
import { avatar, asset } from "../../data/app-seed";
const search = ref(""),
  selected = ref(demo.chatPeople[0]?.id),
  text = ref(""),
  messages = ref(null),
  info = ref(true),
  attachment = ref(null);
const filtered = computed(() =>
  demo.chatPeople.filter((p) =>
    p.name.toLowerCase().includes((search.value || "").toLowerCase()),
  ),
);
const person = computed(() =>
  demo.chatPeople.find((p) => p.id === selected.value),
);
async function send(image = "") {
  if (!text.value.trim() && !image) return;
  person.value.messages.push({
    id: nextId(person.value.messages),
    text: text.value.trim(),
    image,
    own: true,
    time: new Date().toLocaleTimeString("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
    }),
  });
  text.value = "";
  await nextTick();
  messages.value?.scrollTo({
    top: messages.value.scrollHeight,
    behavior: "smooth",
  });
}
function upload(e) {
  const f = e.target.files?.[0];
  if (!f) return;
  if (!["image/jpeg", "image/png"].includes(f.type) || f.size > 800 * 1024)
    return notify("Choose a JPG or PNG up to 800 KB.", "error");
  const r = new FileReader();
  r.onload = () => send(r.result);
  r.readAsDataURL(f);
}
</script>
<template>
  <WorkspacePage title="Chat App"
    ><v-card :class="['chat-layout', { 'hide-info': !info }]"
      ><aside class="chat-contacts">
        <div class="person-cell pa-5">
          <v-avatar size="44"
            ><img :src="avatar(1)" alt="David McMichael"
          /></v-avatar>
          <div><strong>David McMichael</strong><span>Designer</span></div>
        </div>
        <div class="px-5">
          <v-text-field
            v-model="search"
            label="Search Contact"
            density="compact"
          />
          <p class="muted text-caption my-4">Recent Chats</p>
        </div>
        <button
          v-for="p in filtered"
          :key="p.id"
          :class="['chat-contact', { active: selected === p.id }]"
          @click="selected = p.id"
        >
          <v-avatar size="40"><img :src="p.image" :alt="p.name" /></v-avatar>
          <div>
            <strong>{{ p.name }}</strong
            ><span>{{
              p.messages.at(-1)?.text || "Start a conversation"
            }}</span>
          </div>
          <i :class="{ online: p.online }" />
        </button>
      </aside>
      <section v-if="person" class="chat-conversation">
        <header>
          <div class="person-cell">
            <v-avatar size="42"
              ><img :src="person.image" :alt="person.name"
            /></v-avatar>
            <div>
              <strong>{{ person.name }}</strong
              ><span
                >{{ person.online ? "online" : "offline" }} · sample
                status</span
              >
            </div>
          </div>
          <v-spacer /><v-btn
            icon
            variant="text"
            size="32"
            aria-label="Toggle conversation details"
            @click="info = !info"
            ><Icon name="menu" :size="19"
          /></v-btn>
        </header>
        <div ref="messages" class="chat-messages">
          <div
            v-for="m in person.messages"
            :key="m.id"
            :class="['chat-message', { own: m.own }]"
          >
            <small>{{ m.own ? "You" : person.name }} · {{ m.time }}</small>
            <p v-if="m.text">{{ m.text }}</p>
            <img v-if="m.image" :src="m.image" alt="Shared local attachment" />
          </div>
        </div>
        <form class="chat-compose" @submit.prevent="send()">
          <v-text-field
            v-model="text"
            placeholder="Type a Message"
            aria-label="Type a Message"
            variant="plain"
          /><v-btn
            icon
            variant="text"
            aria-label="Attach image"
            @click="attachment.click()"
            ><Icon name="attachment" :size="18" /></v-btn
          ><v-btn
            icon
            color="primary"
            size="36"
            type="submit"
            :disabled="!text.trim()"
            aria-label="Send message"
            ><Icon name="send" :size="18" /></v-btn
          ><input
            ref="attachment"
            type="file"
            accept="image/jpeg,image/png"
            hidden
            @change="upload"
          />
        </form>
      </section>
      <aside v-if="info" class="chat-info">
        <h3>Media</h3>
        <img :src="asset('blog-img1-')" alt="Sample conversation media" />
        <h3 class="mt-6 mb-4">Conversation details</h3>
        <p class="muted">
          Messages and uploaded images stay in this browser. They are not
          delivered to another person.
        </p>
        <v-chip color="primary" size="small" class="mt-5"
          >Local conversation</v-chip
        >
      </aside></v-card
    ></WorkspacePage
  >
</template>
