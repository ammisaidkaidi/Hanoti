<script setup>
import { ref, computed } from "vue";
import { useRoute } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { articles, avatar } from "../../data/app-seed";
import { demo } from "../../composables/useDemoStore";
import { notify } from "../../composables/useFeedback";
const route = useRoute();
const list = route.path.endsWith("/posts");
const article = computed(() =>
  articles.find((a) => a.slug === route.params.slug),
);
const comment = ref("");
const comments = computed(() => demo.articleComments[article.value?.id] || []);
function post() {
  if (!comment.value.trim()) return;
  demo.articleComments[article.value.id] ??= [];
  demo.articleComments[article.value.id].push({
    id: Date.now(),
    name: "David McMichael",
    text: comment.value.trim(),
    date: new Date().toISOString().slice(0, 10),
  });
  comment.value = "";
  notify("Comment saved locally.");
}
</script>
<template>
  <WorkspacePage :title="list ? 'Blog app' : 'Blog Details'"
    ><template v-if="list"
      ><div class="blog-featured">
        <router-link
          v-for="a in articles.slice(0, 2)"
          :key="a.id"
          :to="'/apps/blog/' + a.slug"
          class="featured-article"
          :style="{
            backgroundImage:
              'linear-gradient(180deg,rgba(15,10,28,.06),rgba(15,10,28,.78)),url(' +
              a.image +
              ')',
          }"
          ><div class="featured-top">
            <v-avatar size="38"
              ><img :src="a.avatar" :alt="a.author" /></v-avatar
            ><v-chip color="primary" variant="flat" size="small">{{
              a.category
            }}</v-chip>
          </div>
          <div>
            <h2>{{ a.title }}</h2>
            <div class="article-meta">
              <span><Icon name="eye" :size="15" />{{ a.views }}</span
              ><span
                ><Icon name="chats" :size="15" />{{
                  demo.articleComments[a.id]?.length || 3
                }}</span
              ><time>{{ a.date }}</time>
            </div>
          </div></router-link
        >
      </div>
      <div class="blog-grid">
        <v-card v-for="a in articles.slice(2)" :key="a.id" class="blog-card"
          ><router-link :to="'/apps/blog/' + a.slug"
            ><img
              :src="a.image"
              :alt="a.title"
              class="blog-card-image"
              loading="lazy" /></router-link
          ><v-avatar class="blog-author" size="40"
            ><img :src="a.avatar" :alt="a.author"
          /></v-avatar>
          <div class="pa-6 pt-4">
            <v-chip size="x-small" color="primary">{{ a.category }}</v-chip
            ><router-link :to="'/apps/blog/' + a.slug"
              ><h2 class="mt-3">{{ a.title }}</h2></router-link
            >
            <div class="article-meta muted">
              <span><Icon name="eye" :size="14" />{{ a.views }}</span
              ><span><Icon name="chats" :size="14" />3</span
              ><time>{{ a.date }}</time>
            </div>
          </div></v-card
        >
      </div></template
    ><template v-else-if="article"
      ><v-card class="article-card"
        ><img :src="article.image" :alt="article.title" class="article-hero" />
        <div class="article-title">
          <v-avatar size="44" class="mb-4"
            ><img :src="article.avatar" :alt="article.author"
          /></v-avatar>
          <div>
            <v-chip size="small" color="primary">{{ article.category }}</v-chip>
          </div>
          <h1>{{ article.title }}</h1>
          <div class="article-meta muted">
            <span><Icon name="eye" :size="16" />{{ article.views }}</span
            ><span><Icon name="chats" :size="16" />{{ comments.length }}</span
            ><time>{{ article.date }}</time>
          </div>
        </div>
        <v-divider />
        <div class="article-body">
          <h2>Title of the paragraph</h2>
          <p>
            Thoughtful design makes technology feel more approachable. From the
            products we use every day to the services that help us stay
            connected, the best experiences are clear, useful, and built around
            people.
          </p>
          <p>
            Finding the right product means looking beyond the headline.
            Consider the details, compare the features that matter to you, and
            take the time to understand how it fits into your everyday routine.
          </p>
          <p><strong>This is strong text.</strong></p>
          <p><em>This is italic text.</em></p>
          <h2>Unordered list.</h2>
          <ul>
            <li>Focus on the features that matter most.</li>
            <li>Compare quality, usability, and long-term value.</li>
            <li>Look for thoughtful details and dependable support.</li>
          </ul>
          <h2>Ordered list.</h2>
          <ol>
            <li>Explore your options and collect inspiration.</li>
            <li>Review the details and compare your shortlist.</li>
            <li>Make a considered choice that works for you.</li>
          </ol>
          <h2>Quotes</h2>
          <blockquote>
            “Great design is the result of clear thinking and careful attention
            to the details.”
          </blockquote>
          <p class="text-caption muted">
            Illustrative article copy for this front-end recreation.
          </p>
        </div></v-card
      ><v-card class="workspace-card mt-6"
        ><h2>Comments {{ comments.length }}</h2>
        <div v-for="c in comments" :key="c.id" class="article-comment">
          <v-avatar size="42"><img :src="avatar(1)" :alt="c.name" /></v-avatar>
          <div>
            <h3>
              {{ c.name }} <small class="muted">{{ c.date }}</small>
            </h3>
            <p>{{ c.text }}</p>
          </div>
        </div>
        <v-textarea
          v-model="comment"
          label="Write a comment"
          rows="4"
          variant="outlined"
          class="mt-6"
          hide-details
        />
        <div class="workspace-actions mt-4">
          <v-btn color="primary" :disabled="!comment.trim()" @click="post"
            >Post Comment</v-btn
          >
        </div></v-card
      ></template
    ><v-card v-else class="workspace-empty"
      ><h2>Article not found</h2>
      <v-btn color="primary" to="/apps/blog/posts"
        >Browse articles</v-btn
      ></v-card
    ></WorkspacePage
  >
</template>
