<script setup>
import { ref, computed } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { confirmDemo, notify } from "../../composables/useFeedback";
const search = ref(""),
  selected = ref(demo.notes[0]?.id);
const filtered = computed(() =>
  demo.notes.filter((n) =>
    (n.title + " " + n.body)
      .toLowerCase()
      .includes((search.value || "").toLowerCase()),
  ),
);
const note = computed(() => demo.notes.find((n) => n.id === selected.value));
function add() {
  const n = {
    id: nextId(demo.notes),
    title: "Untitled note",
    body: "",
    color: "#635bff",
    date: new Date().toISOString().slice(0, 10),
  };
  demo.notes.unshift(n);
  selected.value = n.id;
  search.value = "";
}
async function remove(n) {
  if (await confirmDemo("Delete this note?")) {
    demo.notes = demo.notes.filter((x) => x.id !== n.id);
    if (selected.value === n.id) selected.value = demo.notes[0]?.id;
  }
}
</script>
<template>
  <WorkspacePage title="Notes App"
    ><v-card class="notes-layout"
      ><aside class="notes-list">
        <h3>All Notes</h3>
        <v-text-field
          v-model="search"
          placeholder="Search Notes"
          aria-label="Search Notes"
          density="compact"
          class="my-4"
        /><button
          v-for="n in filtered"
          :key="n.id"
          :class="['note-preview', { selected: selected === n.id }]"
          :style="{ '--note-color': n.color }"
          @click="selected = n.id"
        >
          <strong>{{ n.title || "Untitled note" }}</strong>
          <p>{{ n.body }}</p>
          <span>{{ n.date }}</span
          ><v-btn
            icon
            variant="text"
            size="25"
            :aria-label="'Delete ' + n.title"
            @click.stop="remove(n)"
            ><Icon name="trash" :size="15"
          /></v-btn>
        </button>
        <p v-if="!filtered.length" class="muted">No matching notes.</p>
      </aside>
      <section class="note-editor">
        <div class="workspace-toolbar">
          <h3>Edit Notes</h3>
          <v-spacer /><v-btn color="primary" @click="add">Add Notes</v-btn>
        </div>
        <template v-if="note"
          ><label class="field-label">Change Title</label
          ><v-text-field
            v-model="note.title"
            aria-label="Note title"
            class="mb-6"
          /><v-textarea
            v-model="note.body"
            label="Your note"
            rows="10"
            auto-grow
            variant="outlined"
            hide-details
          />
          <h3 class="mt-7 mb-4">Change Notes Color</h3>
          <div class="color-choices">
            <button
              v-for="color in [
                '#e8bc22',
                '#16cdc7',
                '#ff6692',
                '#36c76c',
                '#635bff',
              ]"
              :key="color"
              :style="{ background: color }"
              :aria-label="'Note color ' + color"
              :aria-pressed="note.color === color"
              @click="note.color = color"
            >
              <Icon v-if="note.color === color" name="check" :size="18" />
            </button>
          </div>
          <p class="muted text-caption mt-7">
            Notes save automatically in this browser.
          </p></template
        >
        <div v-else class="workspace-empty">
          <Icon name="notes" :size="40" />
          <h3>Your ideas start here</h3>
          <v-btn color="primary" @click="add">Create a note</v-btn>
        </div>
      </section></v-card
    ></WorkspacePage
  >
</template>
