<script setup>
import { ref } from "vue";
import { useRoute, useRouter, onBeforeRouteLeave } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { demo, nextId, clone, money } from "../../composables/useDemoStore";
import { notify, required, confirmDemo } from "../../composables/useFeedback";
import { asset } from "../../data/app-seed";
const route = useRoute(),
  router = useRouter(),
  editing = route.path.endsWith("edit-product");
const existing = editing
  ? demo.products.find((p) => p.id === Number(route.query.id || 12))
  : null;
const empty = {
  name: "",
  description: "",
  price: 0,
  basePrice: 0,
  oldPrice: 0,
  category: "Electronics",
  gender: "All",
  status: "Published",
  stock: 25,
  rating: 4,
  image: asset("preview-img-"),
  sku: "",
  tags: [],
  tax: 10,
  discountType: "No Discount",
  discount: 0,
  template: "Default",
  weight: 0.5,
};
const draft = ref(clone(existing || empty));
draft.value.basePrice = existing?.basePrice ?? existing?.price ?? 0;
const initial = JSON.stringify(draft.value);
let saved = false;
const tab = ref("General"),
  form = ref(null),
  upload = ref(null),
  tagText = ref((draft.value.tags || []).join(", "));
async function pick(e) {
  const file = e.target.files?.[0];
  if (!file) return;
  if (
    !["image/jpeg", "image/png"].includes(file.type) ||
    file.size > 800 * 1024
  ) {
    notify("Choose a JPG or PNG no larger than 800 KB.", "error");
    return;
  }
  const reader = new FileReader();
  reader.onload = () => (draft.value.image = reader.result);
  reader.readAsDataURL(file);
}
async function save() {
  if (!(await form.value.validate()).valid) return;
  if (!draft.value.name.trim() || Number(draft.value.basePrice) <= 0) {
    tab.value = "General";
    return notify(
      "Enter a product name and a price greater than zero.",
      "error",
    );
  }
  const p = clone(draft.value);
  p.tags = tagText.value
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);
  p.oldPrice = Number(p.basePrice);
  p.price =
    p.discountType === "Percentage %"
      ? p.basePrice * (1 - Number(p.discount) / 100)
      : p.discountType === "Fixed Price"
        ? Math.max(0, p.basePrice - Number(p.discount))
        : Number(p.basePrice);
  p.price = Math.round(p.price * 100) / 100;
  p.date = new Date().toISOString().slice(0, 10);
  if (editing && existing)
    demo.products.splice(
      demo.products.findIndex((x) => x.id === existing.id),
      1,
      p,
    );
  else {
    p.id = nextId(demo.products);
    demo.products.push(p);
  }
  saved = true;
  notify("Product saved locally.");
  router.push("/ecommerce/productlist");
}
onBeforeRouteLeave(
  async () =>
    saved ||
    JSON.stringify(draft.value) === initial ||
    (await confirmDemo("Discard unsaved product changes?")),
);
</script>
<template>
  <WorkspacePage :title="editing ? 'Edit Product' : 'Add Product'"
    ><v-card v-if="editing && !existing" class="workspace-empty"
      ><h2>Product not found</h2>
      <v-btn to="/ecommerce/productlist">Back to products</v-btn></v-card
    ><v-form v-else ref="form" @submit.prevent="save"
      ><v-tabs v-model="tab" color="primary" class="mb-6"
        ><v-tab value="General">General</v-tab
        ><v-tab value="Advanced">Advanced</v-tab
        ><v-tab v-if="editing" value="Reviews">Reviews</v-tab></v-tabs
      >
      <div class="product-editor-grid">
        <div class="stack-cards">
          <template v-if="tab === 'General'"
            ><v-card class="workspace-card"
              ><h2>General</h2>
              <v-text-field
                v-model="draft.name"
                label="Product Name *"
                :rules="[required]"
                hide-details="auto"
                class="mt-6"
              />
              <p class="field-help">
                A product name is required and recommended to be unique.
              </p>
              <v-textarea
                v-model="draft.description"
                label="Description"
                variant="outlined"
                rows="7"
                hide-details
                class="mt-6"
              />
              <p class="field-help">
                Set a description for better product visibility.
              </p></v-card
            ><v-card class="workspace-card"
              ><h2>Media</h2>
              <button class="upload-zone" type="button" @click="upload.click()">
                <Icon name="upload" :size="28" /><span
                  >Click to upload a product image</span
                ><small>JPG or PNG · up to 800 KB</small>
              </button></v-card
            ><v-card class="workspace-card"
              ><h2>Pricing</h2>
              <v-text-field
                v-model.number="draft.basePrice"
                label="Base Price *"
                type="number"
                min="0.01"
                :rules="[
                  (v) => Number(v) > 0 || 'Enter a price greater than zero',
                ]"
                hide-details="auto"
                class="mt-6" />
              <h3 class="mt-6">Discount Type</h3>
              <v-radio-group v-model="draft.discountType" inline hide-details
                ><v-radio
                  v-for="d in ['No Discount', 'Percentage %', 'Fixed Price']"
                  :key="d"
                  :label="d"
                  :value="d"
                  color="primary" /></v-radio-group
              ><v-text-field
                v-if="draft.discountType !== 'No Discount'"
                v-model.number="draft.discount"
                type="number"
                label="Discount amount"
                :rules="[
                  (v) =>
                    (Number(v) >= 0 &&
                      (draft.discountType !== 'Percentage %' ||
                        Number(v) <= 100)) ||
                    'Enter a valid discount',
                ]"
                hide-details="auto"
                class="mt-4" /><v-text-field
                v-model.number="draft.tax"
                type="number"
                label="VAT Amount (%)"
                min="0"
                max="100"
                :rules="[
                  (v) => (Number(v) >= 0 && Number(v) <= 100) || 'Use 0–100%',
                ]"
                hide-details="auto"
                class="mt-6" /></v-card></template
          ><v-card v-else-if="tab === 'Advanced'" class="workspace-card"
            ><h2>Inventory &amp; Shipping</h2>
            <div class="record-fields mt-6">
              <v-text-field v-model="draft.sku" label="SKU" /><v-text-field
                v-model.number="draft.stock"
                type="number"
                min="0"
                label="Stock quantity"
                :rules="[(v) => Number(v) >= 0 || 'Use zero or more']"
                hide-details="auto"
              /><v-text-field
                v-model.number="draft.weight"
                type="number"
                min="0"
                label="Weight (kg)"
              /><v-select
                v-model="draft.gender"
                :items="['All', 'Male', 'Female', 'Kids']"
                label="Audience"
              />
            </div>
            <p class="field-help">
              Inventory is sample data stored in this browser.
            </p></v-card
          ><v-card v-else class="workspace-card"
            ><h2>Reviews</h2>
            <div class="review-list">
              <div
                v-for="name in ['Jennie Alvarado', 'Robert Murray']"
                :key="name"
              >
                <h3>{{ name }}</h3>
                <v-rating
                  :model-value="4"
                  readonly
                  color="warning"
                  active-color="warning"
                  density="compact"
                  size="20"
                />
                <p class="muted">A great product with thoughtful details.</p>
              </div>
            </div></v-card
          >
        </div>
        <aside class="stack-cards">
          <v-card class="workspace-card"
            ><h2>Thumbnail</h2>
            <button
              type="button"
              class="thumbnail-upload"
              @click="upload.click()"
            >
              <img :src="draft.image" alt="Product thumbnail" />
            </button>
            <p class="field-help">
              Set the product thumbnail. JPG and PNG images are accepted.
            </p>
            <input
              ref="upload"
              type="file"
              accept="image/jpeg,image/png"
              hidden
              @change="pick" /></v-card
          ><v-card class="workspace-card"
            ><h2>Status</h2>
            <v-select
              v-model="draft.status"
              :items="['Published', 'Draft', 'Archived']"
              label="Product status"
              class="mt-5" /></v-card
          ><v-card class="workspace-card"
            ><h2>Product Details</h2>
            <v-select
              v-model="draft.category"
              :items="[
                'Kitchen',
                'Electronics',
                'Books',
                'Fashion',
                'Toys',
                'Beauty',
              ]"
              label="Categories"
              class="mt-5" /><v-text-field
              v-model="tagText"
              label="Tags, separated by commas"
              class="mt-5" /><v-select
              v-model="draft.template"
              :items="['Default', 'Office Stationary', 'Digital Product']"
              label="Product Template"
              class="mt-5"
          /></v-card>
        </aside>
      </div>
      <div class="workspace-actions mt-6">
        <v-btn type="submit" color="primary">Save Changes</v-btn
        ><v-btn color="error" variant="tonal" to="/ecommerce/productlist"
          >Cancel</v-btn
        >
      </div></v-form
    ></WorkspacePage
  >
</template>
