<script setup>
import { ref } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import RecordDialog from "../../components/apps/RecordDialog.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { confirmDemo, notify } from "../../composables/useFeedback";
import { avatar } from "../../data/app-seed";
const props = defineProps({
  title: { type: String, default: "Contact App" },
  heading: String,
});
const search = ref(""),
  editor = ref(false),
  record = ref({});
const headers = [
  { title: "Id", key: "id" },
  { title: "UserInfo", key: "name" },
  { title: "Phone", key: "phone" },
  { title: "Joining Date", key: "joined" },
  { title: "Role", key: "role" },
  { title: "Actions", key: "actions", sortable: false },
];
const fields = [
  { key: "name", label: "Full name", required: true },
  { key: "email", label: "Email address", type: "email", required: true },
  { key: "phone", label: "Phone", required: true },
  { key: "joined", label: "Joining date", type: "date", required: true },
  {
    key: "role",
    label: "Role",
    items: ["Designer", "Developer", "Accountant", "HR", "Manager", "Chairman"],
    required: true,
  },
];
function edit(item) {
  record.value = item
    ? { ...item }
    : {
        name: "",
        email: "",
        phone: "",
        joined: new Date().toISOString().slice(0, 10),
        role: "Designer",
      };
  editor.value = true;
}
function save(item) {
  if (item.id) {
    demo.contacts.splice(
      demo.contacts.findIndex((c) => c.id === item.id),
      1,
      item,
    );
  } else
    demo.contacts.push({
      ...item,
      id: nextId(demo.contacts),
      image: avatar(1),
    });
  editor.value = false;
  notify("Contact saved locally.");
}
async function remove(item) {
  if (await confirmDemo("Delete " + item.name + "?"))
    demo.contacts = demo.contacts.filter((c) => c.id !== item.id);
}
const colors = {
  Designer: "primary",
  Developer: "secondary",
  Accountant: "error",
  HR: "warning",
  Manager: "primary",
  Chairman: "secondary",
};
</script>
<template>
  <WorkspacePage :title="props.title"
    ><v-card class="workspace-card"
      ><h2 v-if="props.heading" class="mb-6">{{ props.heading }}</h2>
      <div class="workspace-toolbar">
        <v-text-field
          v-model="search"
          label="Search Contacts"
          density="compact"
          clearable
          ><template #prepend-inner
            ><Icon name="search" :size="18" /></template></v-text-field
        ><v-spacer /><v-btn color="primary" @click="edit()"
          ><Icon name="user" :size="17" class="mr-2" />Add Contact</v-btn
        >
      </div>
      <v-data-table
        :headers="headers"
        :items="demo.contacts"
        :search="search"
        :items-per-page="10"
        class="workspace-table"
        ><template #item.id="{ item }">#{{ item.id }}</template
        ><template #item.name="{ item }"
          ><div class="person-cell">
            <v-avatar size="42"
              ><img :src="item.image" :alt="item.name"
            /></v-avatar>
            <div>
              <strong>{{ item.name }}</strong
              ><span>{{ item.email }}</span>
            </div>
          </div></template
        ><template #item.role="{ item }"
          ><v-chip :color="colors[item.role]" size="small" rounded="sm">{{
            item.role
          }}</v-chip></template
        ><template #item.actions="{ item }"
          ><div class="row-actions">
            <v-btn
              icon
              size="32"
              variant="text"
              color="primary"
              :aria-label="'Edit ' + item.name"
              @click="edit(item)"
              ><Icon name="edit" :size="17" /></v-btn
            ><v-btn
              icon
              size="32"
              variant="text"
              color="error"
              :aria-label="'Delete ' + item.name"
              @click="remove(item)"
              ><Icon name="trash" :size="17"
            /></v-btn></div></template></v-data-table></v-card
    ><RecordDialog
      v-model="editor"
      :title="record.id ? 'Edit Contact' : 'Add Contact'"
      :record="record"
      :fields="fields"
      @save="save"
  /></WorkspacePage>
</template>
