<script setup>
import { ref } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { avatar, asset } from "../../data/app-seed";
import { notify } from "../../composables/useFeedback";
const text = ref(""),
  comments = ref({}),
  upload = ref(null),
  image = ref(""),
  story = ref(false),
  storyText = ref("");
function post() {
  if (!text.value.trim() && !image.value) return;
  demo.posts.unshift({
    id: nextId(demo.posts),
    author: "David McMichael",
    avatar: avatar(1),
    text: text.value.trim(),
    image: image.value,
    likes: 0,
    liked: false,
    comments: [],
  });
  text.value = "";
  image.value = "";
  notify("Post saved locally.");
}
function addComment(p) {
  if (!comments.value[p.id]?.trim()) return;
  p.comments.push({
    name: "David McMichael",
    text: comments.value[p.id].trim(),
  });
  comments.value[p.id] = "";
}
function photo(e) {
  const f = e.target.files?.[0];
  if (!f) return;
  if (!["image/jpeg", "image/png"].includes(f.type) || f.size > 800 * 1024)
    return notify("Choose a JPG or PNG up to 800 KB.", "error");
  const r = new FileReader();
  r.onload = () => (image.value = r.result);
  r.readAsDataURL(f);
}
</script>
<template>
  <WorkspacePage title="User Profile"
    ><v-card class="profile-cover-card"
      ><img
        :src="asset('profilebg-')"
        alt="Lavender abstract profile cover"
        class="profile-cover"
      />
      <div class="profile-overview">
        <div class="profile-stats">
          <div>
            <Icon name="file" :size="20" /><strong>{{
              938 + demo.posts.length - 3
            }}</strong
            ><span>Posts</span>
          </div>
          <div>
            <Icon name="profile" :size="20" /><strong>3,586</strong
            ><span>Followers</span>
          </div>
          <div>
            <Icon name="user" :size="20" /><strong>2,659</strong
            ><span>Following</span>
          </div>
        </div>
        <div class="profile-identity">
          <v-avatar size="105"
            ><img :src="avatar(1)" alt="David McMichael"
          /></v-avatar>
          <h2>David McMichael</h2>
          <p class="muted">Designer</p>
        </div>
        <div class="profile-social">
          <v-btn variant="tonal" color="primary" to="/pages/account-settings"
            >Edit Profile</v-btn
          ><v-btn color="primary" @click="story = true">Add To Story</v-btn>
        </div>
      </div>
      <v-tabs
        color="primary"
        class="profile-navigation"
        align-tabs="end"
        model-value="/apps/user/profile"
        ><v-tab
          v-for="[name, path, icon] in [
            ['Profile', '/apps/user/profile', 'profile'],
            ['Followers', '/apps/user/profile/followers', 'heart'],
            ['Friends', '/apps/user/profile/friends', 'user'],
            ['Gallery', '/apps/user/profile/gallery', 'grid'],
          ]"
          :key="name"
          :value="path"
          :to="path"
          ><Icon :name="icon" :size="17" class="mr-2" />{{ name }}</v-tab
        ></v-tabs
      ></v-card
    >
    <div class="profile-feed-layout">
      <aside class="stack-cards">
        <v-card class="workspace-card"
          ><h2>Introduction</h2>
          <p class="muted my-5">
            Hello, I am David McMichael. I love making websites and graphics.
            Sharing ideas, learning new things, and building thoughtful
            experiences.
          </p>
          <p
            v-for="[icon, label] in [
              ['invoice', 'Sir, P P Institute Of Science'],
              ['email', 'xyzjonathan@gmail.com'],
              ['monitor', 'www.xyz.com'],
              ['home', 'Newyork, USA - 100001'],
            ]"
            :key="label"
            class="profile-info-line"
          >
            <Icon :name="icon" :size="18" />{{ label }}
          </p></v-card
        ><v-card class="workspace-card"
          ><h2 class="mb-5">Photos</h2>
          <div class="profile-photos">
            <img
              v-for="i in [1, 2, 3, 4, 5, 6]"
              :key="i"
              :src="asset('s' + i + '-')"
              alt="Profile gallery sample"
            /></div
        ></v-card>
      </aside>
      <section class="stack-cards">
        <v-card class="workspace-card"
          ><v-textarea
            v-model="text"
            label="Share your thoughts"
            variant="outlined"
            rows="4"
            hide-details /><img
            v-if="image"
            :src="image"
            alt="Post attachment preview"
            class="post-attachment" />
          <div class="post-compose-actions">
            <v-btn variant="text" @click="upload.click()"
              ><Icon name="grid" :size="18" class="text-primary mr-2" />Photo /
              Video</v-btn
            ><v-spacer /><v-btn
              color="primary"
              :disabled="!text.trim() && !image"
              @click="post"
              >Post</v-btn
            >
          </div>
          <input
            ref="upload"
            type="file"
            accept="image/jpeg,image/png"
            hidden
            @change="photo" /></v-card
        ><v-card
          v-for="p in demo.posts"
          :key="p.id"
          class="workspace-card feed-post"
          ><div class="person-cell">
            <v-avatar size="44"
              ><img :src="p.avatar" :alt="p.author"
            /></v-avatar>
            <div>
              <strong>{{ p.author }}</strong
              ><span>Just now · Local post</span>
            </div>
          </div>
          <p class="post-text">{{ p.text }}</p>
          <img
            v-if="p.image"
            :src="p.image"
            alt="Post image"
            class="feed-image" />
          <div class="post-reactions">
            <v-btn
              variant="text"
              :color="p.liked ? 'error' : undefined"
              @click="
                p.liked = !p.liked;
                p.likes += p.liked ? 1 : -1;
              "
              ><Icon name="heart" :size="18" class="mr-2" />{{ p.likes }}</v-btn
            ><span
              ><Icon name="chats" :size="18" />{{ p.comments.length }}</span
            >
          </div>
          <div v-for="(c, i) in p.comments" :key="i" class="feed-comment">
            <v-avatar size="30"
              ><img :src="avatar(2)" :alt="c.name"
            /></v-avatar>
            <div>
              <strong>{{ c.name }}</strong>
              <p>{{ c.text }}</p>
            </div>
          </div>
          <form class="d-flex ga-3 mt-4" @submit.prevent="addComment(p)">
            <v-text-field
              v-model="comments[p.id]"
              label="Comment"
              density="compact"
            /><v-btn
              color="primary"
              icon
              size="40"
              type="submit"
              :disabled="!comments[p.id]?.trim()"
              :aria-label="'Post comment on ' + p.id"
              ><Icon name="send" :size="17"
            /></v-btn></form
        ></v-card>
      </section>
    </div>
    <v-dialog v-model="story"
      ><v-card class="dialog-body"
        ><h2>Add to your story</h2>
        <p class="muted mt-2 mb-5">
          Stories in this demo are added to your local profile feed.
        </p>
        <v-textarea
          v-model="storyText"
          label="Your story"
          variant="outlined"
          rows="4"
        />
        <div class="dialog-actions">
          <v-btn variant="text" @click="story = false">Cancel</v-btn
          ><v-btn
            color="primary"
            :disabled="!storyText.trim()"
            @click="
              text = storyText;
              post();
              storyText = '';
              story = false;
            "
            >Share Story</v-btn
          >
        </div></v-card
      ></v-dialog
    ></WorkspacePage
  >
</template>
