<script setup>
import { ref } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import RecordDialog from "../../components/apps/RecordDialog.vue";
import { demo, nextId } from "../../composables/useDemoStore";
import { confirmDemo, notify } from "../../composables/useFeedback";
const columns = ["Todo", "In Progress", "Pending", "Done"];
const editor = ref(false),
  record = ref({}),
  dragged = ref(null);
const fields = [
  { key: "title", label: "Task title", required: true },
  { key: "description", label: "Description", type: "textarea" },
  { key: "column", label: "Column", items: columns, required: true },
  {
    key: "tag",
    label: "Category",
    items: ["Design", "Development", "Mobile"],
    required: true,
  },
];
function edit(task, column = "Todo") {
  record.value = task
    ? { ...task }
    : {
        title: "",
        description: "",
        column,
        tag: "Design",
        image: "",
        date: new Date().toISOString().slice(0, 10),
      };
  editor.value = true;
}
function save(task) {
  if (task.id)
    demo.tasks.splice(
      demo.tasks.findIndex((t) => t.id === task.id),
      1,
      task,
    );
  else demo.tasks.push({ ...task, id: nextId(demo.tasks) });
  editor.value = false;
  notify("Task saved locally.");
}
function drop(column) {
  const task = demo.tasks.find((t) => t.id === dragged.value);
  if (task) task.column = column;
  dragged.value = null;
}
async function remove(task) {
  if (await confirmDemo("Delete this task?"))
    demo.tasks = demo.tasks.filter((t) => t.id !== task.id);
}
</script>
<template>
  <WorkspacePage title="Kanban Application"
    ><div class="kanban-board">
      <section
        v-for="(column, index) in columns"
        :key="column"
        :class="['kanban-column', 'column-' + index]"
        @dragover.prevent
        @drop.prevent="drop(column)"
      >
        <header>
          <h3>
            {{ column }}
            <small>{{
              demo.tasks.filter((t) => t.column === column).length
            }}</small>
          </h3>
          <v-btn
            icon
            size="28"
            variant="text"
            :aria-label="'Add task to ' + column"
            @click="edit(null, column)"
            ><Icon name="plus" :size="18"
          /></v-btn>
        </header>
        <v-card
          v-for="task in demo.tasks.filter((t) => t.column === column)"
          :key="task.id"
          class="task-card"
          draggable="true"
          @dragstart="dragged = task.id"
          @dragend="dragged = null"
          ><div class="task-head">
            <button class="text-button" @click="edit(task)">
              {{ task.title }}</button
            ><v-menu
              ><template #activator="{ props }"
                ><v-btn
                  v-bind="props"
                  icon
                  variant="text"
                  size="24"
                  :aria-label="'Task actions ' + task.id"
                  ><Icon name="more" :size="15" /></v-btn></template
              ><v-list density="compact"
                ><v-list-item
                  title="Edit / move task"
                  @click="edit(task)" /><v-list-item
                  title="Delete task"
                  @click="remove(task)" /></v-list
            ></v-menu>
          </div>
          <img
            v-if="task.image"
            :src="task.image"
            alt="Task inspiration"
            class="task-image"
          />
          <p v-if="task.description" class="task-description">
            {{ task.description }}
          </p>
          <footer>
            <span><Icon name="calendar" :size="12" /> {{ task.date }}</span
            ><v-chip
              :color="
                task.tag === 'Design'
                  ? 'success'
                  : task.tag === 'Mobile'
                    ? 'primary'
                    : 'warning'
              "
              size="x-small"
              rounded="sm"
              >{{ task.tag }}</v-chip
            >
          </footer></v-card
        ><button
          v-if="!demo.tasks.some((t) => t.column === column)"
          class="kanban-empty"
          @click="edit(null, column)"
        >
          Drop a task here or add one
        </button>
      </section>
    </div>
    <p class="text-caption muted mt-4">
      Drag cards between columns, or use Edit / move task on mobile.
    </p>
    <RecordDialog
      v-model="editor"
      :title="record.id ? 'Edit Task' : 'Add Task'"
      :record="record"
      :fields="fields"
      @save="save"
  /></WorkspacePage>
</template>
