<script setup>
import { ref, reactive } from "vue";
import { required, validEmail } from "../../composables/useFeedback";
const menu = ref(false),
  form = ref(),
  submitted = ref(false);
const values = reactive({
  first: "",
  last: "",
  phone: "",
  email: "",
  enquiry: "General Enquiry",
  message: "",
});
const links = [
  ["About Us", "/front-page/about-us"],
  ["Blog", "/front-page/blog/posts"],
  ["Portfolio", "/front-page/portfolio"],
  ["Dashboard", "/dashboards/dashboard1"],
  ["Pricing", "/front-page/pricing"],
  ["Contact", "/front-page/contact-us"],
];
async function submit() {
  if ((await form.value.validate()).valid) submitted.value = true;
}
</script>
<template>
  <section class="contact-page" data-page-ready="true" data-batch="2">
    <header class="front-header">
      <div class="front-container front-header-inner">
        <router-link to="/dashboards/dashboard1" aria-label="MatDash dashboard"
          ><img src="/assets/logo-Dq6uoD-m.svg" alt="MatDash" width="145"
        /></router-link>
        <nav
          :class="['front-nav', { open: menu }]"
          aria-label="Front page navigation"
        >
          <router-link
            v-for="[label, path] in links"
            :key="path"
            :to="path"
            :class="{ active: label === 'Contact' }"
            @click="menu = false"
            >{{ label }}</router-link
          ><v-btn to="/auth/login" color="primary" rounded="pill">Log In</v-btn>
        </nav>
        <v-btn
          class="front-menu-button"
          icon
          variant="text"
          aria-label="Toggle navigation"
          :aria-expanded="menu"
          @click="menu = !menu"
          ><Icon :name="menu ? 'close' : 'menu'"
        /></v-btn>
      </div>
    </header>
    <div class="front-hero">
      <div class="front-container">
        <h1>We’d love to hear from you</h1>
        <p>
          <router-link to="/dashboards/dashboard1">MATDASH</router-link
          ><span>•</span>CONTACT US
        </p>
      </div>
    </div>
    <div class="front-container contact-body">
      <aside class="contact-info">
        <div class="contact-orbit" aria-hidden="true"></div>
        <v-avatar color="white" variant="tonal" size="64" class="mb-7"
          ><Icon name="chats" :size="30"
        /></v-avatar>
        <h2>Reach Out Today</h2>
        <p>Have questions or need assistance? We're just a message away.</p>
        <div class="contact-location">
          <Icon name="globe" :size="30" />
          <h2>Our Location</h2>
          <p>
            Visit us in person or find our contact details to connect with us
            directly.
          </p>
        </div>
        <div class="contact-decoration" aria-hidden="true">
          <Icon name="send" :size="80" />
        </div>
      </aside>
      <v-form
        ref="form"
        @submit.prevent="submit"
        aria-label="Contact enquiry"
        class="contact-form"
        ><div class="demo-field-grid two-columns">
          <div class="demo-field">
            <label for="contact-first">First Name <span>*</span></label
            ><v-text-field
              id="contact-first"
              v-model="values.first"
              placeholder="Name"
              :rules="[required]"
              density="comfortable"
              hide-details="auto"
            />
          </div>
          <div class="demo-field">
            <label for="contact-last">Last Name <span>*</span></label
            ><v-text-field
              id="contact-last"
              v-model="values.last"
              placeholder="Last Name"
              :rules="[required]"
              density="comfortable"
              hide-details="auto"
            />
          </div>
          <div class="demo-field">
            <label for="contact-phone">Phone Number <span>*</span></label
            ><v-text-field
              id="contact-phone"
              v-model="values.phone"
              type="tel"
              placeholder="xxx xxx xxxx"
              :rules="[
                required,
                (v) =>
                  /^[+\d()\s.-]{7,25}$/.test(v) ||
                  'Enter a valid phone number.',
              ]"
              density="comfortable"
              hide-details="auto"
            />
          </div>
          <div class="demo-field">
            <label for="contact-email">Email <span>*</span></label
            ><v-text-field
              id="contact-email"
              v-model="values.email"
              type="email"
              placeholder="Email address"
              :rules="[required, validEmail]"
              density="comfortable"
              hide-details="auto"
            />
          </div>
          <div class="demo-field wide">
            <label for="contact-enquiry"
              >Enquire related to <span>*</span></label
            ><v-select
              id="contact-enquiry"
              v-model="values.enquiry"
              :items="[
                'General Enquiry',
                'Product Support',
                'Partnership',
                'Feedback',
              ]"
              :rules="[required]"
              density="comfortable"
              hide-details="auto"
            />
          </div>
          <div class="demo-field wide">
            <label for="contact-message">Message</label
            ><v-textarea
              id="contact-message"
              v-model="values.message"
              placeholder="Write your message here..."
              rows="5"
              variant="outlined"
              hide-details
            />
          </div>
        </div>
        <v-alert
          v-if="submitted"
          type="success"
          variant="tonal"
          density="compact"
          class="mt-5"
          role="status"
          >Your enquiry was validated in this browser. This demo does not send
          messages.</v-alert
        ><v-btn type="submit" color="primary" class="mt-6" size="large"
          >Submit</v-btn
        >
        <p class="field-help mt-4">
          Front-end demo only. Your information is not sent or saved.
        </p></v-form
      >
    </div>
    <section class="front-cta">
      <div class="front-container">
        <h2>
          Focus on what truly matters—creating stunning, functional designs.
        </h2>
        <p>
          Designed for ease of use and customization, this template helps you
          build professional dashboards faster.
        </p>
        <v-btn to="/auth/register" color="primary" size="large" rounded="pill"
          >Register</v-btn
        >
      </div>
    </section>
    <footer class="front-container front-footer">
      <img src="/assets/logo-Dq6uoD-m.svg" alt="MatDash" width="130" /><span
        >MatDash · Vue 3 + Vuetify 4 front-end recreation</span
      ><router-link to="/pages/route-directory"
        >View route progress</router-link
      >
    </footer>
  </section>
</template>
