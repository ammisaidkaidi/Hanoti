<script setup>
import { ref } from "vue";
import { useRoute } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import TableCard from "../../components/tables/TableCard.vue";
import SampleTable from "../../components/tables/SampleTable.vue";
const kind = useRoute().path.split("/").at(-1);
const titles = {
  basic: "Basic Table",
  dark: "Dark Table",
  density: "Density Table",
  "fixed-header": "Fixed Header Table",
  height: "Height Table",
};
const density = ref("compact");
</script>
<template>
  <WorkspacePage :title="titles[kind]" class="b4-page" data-batch="4"
    ><TableCard
      :title="kind === 'fixed-header' ? 'Header Fixed Table' : titles[kind]"
      ><template v-if="kind === 'density'" #actions
        ><v-select
          v-model="density"
          :items="['default', 'comfortable', 'compact']"
          label="Row density"
          density="compact"
          class="b4-density-control" /></template
      ><template v-if="kind === 'basic'"
        ><SampleTable kind="projects" /><SampleTable
          kind="users"
          actions
          class="mt-8" /><SampleTable
          kind="customers"
          actions
          class="mt-8" /><SampleTable
          kind="invoices"
          actions
          class="mt-8" /><SampleTable
          kind="authors"
          actions
          class="mt-8" /></template
      ><SampleTable
        v-else-if="kind === 'dark'"
        kind="projects"
        dark
        full /><SampleTable
        v-else-if="kind === 'density'"
        kind="users"
        :density="density" /><SampleTable
        v-else-if="kind === 'fixed-header'"
        kind="customers"
        fixed
        :height="320" /><SampleTable
        v-else
        kind="authors"
        full
        actions
        :height="320" /></TableCard
  ></WorkspacePage>
</template>
