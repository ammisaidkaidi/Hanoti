<script setup>
import Contacts from "../apps/Contacts.vue";
</script>
<template>
  <Contacts
    title="Editable Table"
    heading="Editable Table"
    class="b4-page"
    data-batch="4"
  />
</template>
