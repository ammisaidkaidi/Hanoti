<script setup>
import { ref } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import TableCard from "../../components/tables/TableCard.vue";
import { tableDemos, tableStorageError } from "../../composables/useTableDemos";
import { required, confirmDemo, notify } from "../../composables/useFeedback";
const open = ref(false),
  form = ref(),
  draft = ref({}),
  page = ref(1),
  size = ref(10),
  search = ref("");
const headers = [
  { title: "Dessert (100g serving)", key: "name" },
  { title: "Calories", key: "calories" },
  { title: "Fat (g)", key: "fat" },
  { title: "Carbs (g)", key: "carbs" },
  { title: "Protein (g)", key: "protein" },
  { title: "Actions", key: "actions", sortable: false },
];
const numeric = [
  ["calories", "Calories"],
  ["fat", "Fat (g)"],
  ["carbs", "Carbs (g)"],
  ["protein", "Protein (g)"],
];
const numberRule = (v) =>
  (v !== "" && v !== null && Number.isFinite(Number(v)) && Number(v) >= 0) ||
  "Enter a non-negative number.";
function edit(item) {
  draft.value = item
    ? { ...item }
    : { name: "", calories: 0, fat: 0, carbs: 0, protein: 0 };
  open.value = true;
}
async function save() {
  if (!(await form.value.validate()).valid) return;
  const record = { ...draft.value, name: draft.value.name.trim() };
  for (const [key] of numeric) record[key] = Number(record[key]);
  if (record.id) {
    const i = tableDemos.desserts.findIndex((p) => p.id === record.id);
    if (i >= 0) tableDemos.desserts.splice(i, 1, record);
  } else
    tableDemos.desserts.push({
      ...record,
      id: Math.max(0, ...tableDemos.desserts.map((p) => p.id)) + 1,
    });
  open.value = false;
  notify("Dessert saved locally.");
}
async function remove(item) {
  if (
    await confirmDemo(
      "Delete " + item.name + "?",
      "This removes only the dessert record stored in this browser.",
    )
  ) {
    tableDemos.desserts = tableDemos.desserts.filter((p) => p.id !== item.id);
    page.value = Math.min(
      page.value,
      Math.max(
        1,
        Math.ceil(
          tableDemos.desserts.length /
            (size.value < 1 ? tableDemos.desserts.length || 1 : size.value),
        ),
      ),
    );
    notify("Dessert deleted locally.");
  }
}
</script>
<template>
  <WorkspacePage title="CRUD Table" class="b4-page" data-batch="4"
    ><TableCard title="Crud Table"
      ><div class="b4-crud-toolbar">
        <h3>My Crud Table</h3>
        <v-btn color="primary" @click="edit()">Add New Item</v-btn>
      </div>
      <v-text-field
        v-model="search"
        label="Search desserts"
        density="compact"
        class="my-4"
        @update:model-value="page = 1"
      /><v-data-table
        v-model:page="page"
        v-model:items-per-page="size"
        :headers="headers"
        :items="tableDemos.desserts"
        :search="search"
        :sort-by="[{ key: 'calories', order: 'asc' }]"
        :items-per-page-options="[5, 10, { value: -1, title: 'All' }]"
        :mobile="false"
        class="b4-data-table"
        aria-label="Dessert CRUD table"
        ><template #item.actions="{ item }"
          ><div class="b4-row-actions">
            <v-btn
              icon
              variant="text"
              size="32"
              color="primary"
              :aria-label="'Edit ' + item.name"
              @click="edit(item)"
              ><Icon name="edit" :size="17" /></v-btn
            ><v-btn
              icon
              variant="text"
              size="32"
              color="error"
              :aria-label="'Delete ' + item.name"
              @click="remove(item)"
              ><Icon name="trash" :size="17"
            /></v-btn></div></template
        ><template #no-data
          ><div class="pa-6">
            No desserts found. Add a new item or clear your search.
          </div></template
        ></v-data-table
      ><v-alert
        v-if="tableStorageError"
        type="warning"
        variant="tonal"
        class="mt-4"
        >{{ tableStorageError }}</v-alert
      ></TableCard
    ><v-dialog v-model="open" max-width="560"
      ><v-card class="dialog-body"
        ><div class="dialog-title">
          <h2>{{ draft.id ? "Edit Item" : "New Item" }}</h2>
          <v-btn
            icon
            variant="text"
            aria-label="Close dessert editor"
            @click="open = false"
            ><Icon name="close"
          /></v-btn>
        </div>
        <v-form ref="form" @submit.prevent="save"
          ><div class="b4-dessert-fields">
            <v-text-field
              v-model="draft.name"
              label="Dessert name"
              :rules="[
                required,
                (v) =>
                  String(v || '').length <= 100 ||
                  'Use 100 characters or fewer.',
              ]"
              hide-details="auto"
              class="b4-wide"
            /><v-text-field
              v-for="[key, label] in numeric"
              :key="key"
              v-model="draft[key]"
              :label="label"
              type="number"
              min="0"
              step="any"
              :rules="[numberRule]"
              hide-details="auto"
            />
          </div>
          <div class="dialog-actions">
            <v-btn variant="text" @click="open = false">Cancel</v-btn
            ><v-btn color="primary" type="submit">Save</v-btn>
          </div></v-form
        ></v-card
      ></v-dialog
    ></WorkspacePage
  >
</template>
