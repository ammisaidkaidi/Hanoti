<script setup>
import { ref } from "vue";
import { useRoute } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import TableCard from "../../components/tables/TableCard.vue";
import DataExample from "../../components/tables/DataExample.vue";
import { gpuRows } from "../../data/table-seed";
const kind = useRoute().path.split("/").at(-1);
const titles = {
  basic: "Basic Data Tables",
  header: "Data Table Headers",
  selection: "Data Tables Selection",
  sorting: "Data Table Sorting",
  pagination: "Data Table Pagination",
  filtering: "Data Table Filtering",
  grouping: "Data Tables Grouping",
  slots: "Data Table Slots",
};
const gpuSearch = ref("");
const gpuHeaders = [
  { title: "Name", key: "name" },
  { title: "Image", key: "image", sortable: false },
  { title: "Price", key: "price" },
  { title: "Rating", key: "rating" },
  { title: "Stock", key: "stock" },
];
</script>
<template>
  <WorkspacePage :title="titles[kind]" class="b4-page" data-batch="4"
    ><div class="b4-table-stack">
      <template v-if="kind === 'basic'"
        ><DataExample title="Basic Table" /><DataExample
          title="Selection"
          selection /><DataExample title="Density" dense /><DataExample
          title="Item"
          chips /><DataExample
          title="Expandable Rows"
          expand
          :page-size="10" /></template
      ><DataExample
        v-else-if="kind === 'header'"
        title="Column Slot"
        custom-headers
      /><template v-else-if="kind === 'selection'"
        ><DataExample title="Basic Selection" selection /><DataExample
          title="Selected Values"
          selection
          show-values /><DataExample
          title="Selectable Rows"
          selection
          selectable /><DataExample
          title="Select Strategies"
          selection
          strategy /></template
      ><template v-else-if="kind === 'sorting'"
        ><DataExample
          title="Basic Sorting"
          :sort="[{ key: 'name', order: 'desc' }]" /><DataExample
          title="Multi Sorting"
          multi
          :sort="[
            { key: 'project', order: 'asc' },
            { key: 'post', order: 'asc' },
          ]" /></template
      ><DataExample
        v-else-if="kind === 'pagination'"
        title="External Pagination"
        external
      /><template v-else-if="kind === 'filtering'"
        ><DataExample title="Basic Filter" filter="basic" /><DataExample
          title="Custom Filter"
          filter="upper"
        /><TableCard title="Filterable"
          ><div class="b4-gpu-toolbar">
            <h3>My Table</h3>
            <v-text-field
              v-model="gpuSearch"
              label="Search graphics cards"
              density="compact"
              clearable
              @update:model-value="gpuSearch = gpuSearch || ''"
            />
          </div>
          <v-data-table
            :headers="gpuHeaders"
            :items="gpuRows"
            :search="gpuSearch"
            :filter-keys="['name']"
            :items-per-page="10"
            :items-per-page-options="[5, 10]"
            :mobile="false"
            class="b4-data-table"
            aria-label="Graphics card table"
            ><template #item.image="{ item }"
              ><svg
                width="80"
                height="45"
                viewBox="0 0 120 64"
                role="img"
                :aria-label="item.name + ' illustration'"
              >
                <rect
                  x="8"
                  y="10"
                  width="104"
                  height="44"
                  rx="6"
                  fill="#29343d"
                />
                <rect x="15" y="52" width="48" height="6" fill="#dbc26c" />
                <circle
                  v-for="x in [39, 82]"
                  :key="x"
                  :cx="x"
                  cy="32"
                  r="17"
                  fill="#526174"
                />
                <circle
                  v-for="x in [39, 82]"
                  :key="'in' + x"
                  :cx="x"
                  cy="32"
                  r="10"
                  fill="#182436"
                />
                <circle
                  v-for="x in [39, 82]"
                  :key="'center' + x"
                  :cx="x"
                  cy="32"
                  r="4"
                  fill="#16cdc7"
                /></svg></template
            ><template #item.price="{ item }"
              >${{ item.price.toFixed(2) }}</template
            ><template #item.rating="{ item }"
              ><v-rating
                :model-value="item.rating"
                readonly
                color="warning"
                size="19"
                density="compact" /></template
            ><template #item.stock="{ item }"
              ><v-chip
                :color="item.stock ? 'success' : 'error'"
                size="small"
                rounded="sm"
                >{{ item.stock ? "IN STOCK" : "OUT OF STOCK" }}</v-chip
              ></template
            ></v-data-table
          >
          <p class="field-help mt-3">
            Only product names are searchable in this filter-key example. Images
            are generic graphics-card illustrations.
          </p></TableCard
        ></template
      ><DataExample
        v-else-if="kind === 'grouping'"
        title="Grouping"
        group
      /><DataExample v-else title="Item Slot" slot-row :page-size="10" /></div
  ></WorkspacePage>
</template>
