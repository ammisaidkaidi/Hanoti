<script setup>
import { ref, computed } from "vue";
import { useRoute } from "vue-router";
import { useTheme } from "vuetify";
import ApexChart from "vue3-apexcharts";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import TableCard from "../../components/tables/TableCard.vue";
import { chartExamples } from "../../data/chart-examples";
const kind = useRoute().path.split("/").at(-1),
  config = chartExamples[kind],
  theme = useTheme(),
  chart = ref(),
  showData = ref(false);
const candle = kind === "candlestick-chart";
const options = computed(() => ({
  chart: {
    id: "b4-" + kind,
    fontFamily: "Manrope, sans-serif",
    background: "transparent",
    animations: { enabled: false },
    toolbar: {
      show: candle,
      tools: {
        download: true,
        selection: true,
        zoom: true,
        zoomin: true,
        zoomout: true,
        pan: true,
        reset: true,
      },
    },
    zoom: { enabled: candle },
    foreColor: theme.current.value.dark ? "#acb9cb" : "#98a4ae",
    dropShadow: {
      enabled: !!config.gradient,
      top: 5,
      left: 0,
      blur: 3,
      opacity: 0.14,
    },
    redrawOnParentResize: true,
  },
  theme: { mode: theme.current.value.dark ? "dark" : "light" },
  labels: config.labels || [],
  colors: config.colors,
  stroke: {
    width: config.gradient ? 4 : candle ? 1 : config.type === "bar" ? 0 : 2,
    curve: config.gradient || config.type === "area" ? "smooth" : "straight",
  },
  fill: config.gradient
    ? {
        type: "gradient",
        gradient: {
          shade: "light",
          type: "horizontal",
          gradientToColors: ["#16cdc7"],
          stops: [0, 100],
          opacityFrom: 1,
          opacityTo: 1,
        },
      }
    : {
        type: config.type === "area" ? "gradient" : "solid",
        opacity: config.type === "area" ? 0.2 : 1,
      },
  dataLabels: {
    enabled: kind === "line-chart",
    style: { fontSize: "10px" },
    background: { enabled: false },
  },
  markers: { size: 0, hover: { size: 5 } },
  grid: {
    borderColor: theme.current.value.dark ? "#344254" : "#eef2f6",
    strokeDashArray: 0,
    padding: { left: 8, right: 18 },
  },
  legend: {
    show: !candle && !config.gradient,
    position: "bottom",
    fontSize: "12px",
    markers: { size: 5 },
  },
  xaxis: {
    type: config.datetime ? "datetime" : "category",
    ...(config.datetime ? {} : { categories: config.labels }),
    axisBorder: { show: false },
    axisTicks: { show: false },
    labels: { datetimeUTC: true, style: { fontSize: "11px" } },
    title: {
      text: config.xTitle || "",
      style: { fontSize: "11px", fontWeight: 400 },
    },
  },
  yaxis: {
    labels: {
      formatter: (value) =>
        candle ? Number(value).toFixed(2) : Math.round(value),
      style: { fontSize: "11px" },
    },
    title: {
      text: config.yTitle || "",
      style: { fontWeight: 400, fontSize: "11px" },
    },
  },
  plotOptions: {
    bar: { columnWidth: "38%", borderRadius: 2 },
    candlestick: {
      colors: { upward: "#635bff", downward: "#16cdc7" },
      wick: { useFillColor: true },
    },
  },
  tooltip: {
    theme: theme.current.value.dark ? "dark" : "light",
    x: config.datetime ? { format: "dd MMM yyyy HH:mm" } : { show: true },
  },
}));
const dataRows = computed(() =>
  candle
    ? config.series[0].data.map((d) => [
        new Date(d.x).toISOString().slice(0, 16).replace("T", " "),
        ...d.y,
      ])
    : config.series[0].data.map((d, i) => [
        config.datetime
          ? new Date(d.x).toISOString().slice(0, 10)
          : config.labels[i],
        ...config.series.map((s) =>
          typeof s.data[i] === "object" ? s.data[i].y : s.data[i],
        ),
      ]),
);
const headers = computed(() =>
  candle
    ? ["Time (UTC)", "Open", "High", "Low", "Close"]
    : [
        config.datetime ? "Date" : "Period",
        ...config.series.map((s) => s.name),
      ],
);
function download() {
  const csv = [headers.value, ...dataRows.value]
    .map((row) =>
      row.map((v) => '"' + String(v).replaceAll('"', '""') + '"').join(","),
    )
    .join("\n");
  const url = URL.createObjectURL(
    new Blob([csv], { type: "text/csv;charset=utf-8" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = kind + "-sample.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
</script>
<template>
  <WorkspacePage :title="config.title" class="b4-page" data-batch="4"
    ><TableCard :title="config.title"
      ><div
        class="b4-chart"
        :aria-label="config.title + ' sample visualization'"
      >
        <ApexChart
          ref="chart"
          :type="config.type"
          :height="390"
          width="100%"
          :options="options"
          :series="config.series"
        />
      </div>
      <div class="b4-chart-actions">
        <span class="muted text-caption">{{
          candle
            ? "Illustrative OHLC data · Not financial advice or a live market feed."
            : "Interactive sample series · Hover for values; click a legend to toggle its series."
        }}</span>
        <div class="button-samples">
          <v-btn
            v-if="candle"
            variant="text"
            size="small"
            @click="chart.resetSeries()"
            >Reset zoom</v-btn
          ><v-btn
            variant="text"
            color="primary"
            size="small"
            :aria-expanded="showData"
            @click="showData = !showData"
            >{{ showData ? "Hide data" : "View data" }}</v-btn
          ><v-btn variant="tonal" color="primary" size="small" @click="download"
            >Download CSV</v-btn
          >
        </div>
      </div>
      <v-table
        v-if="showData"
        class="b4-chart-data mt-5"
        :aria-label="config.title + ' data'"
        ><thead>
          <tr>
            <th v-for="h in headers" :key="h">{{ h }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(row, i) in dataRows" :key="i">
            <td v-for="(cell, n) in row" :key="n">{{ cell }}</td>
          </tr>
        </tbody></v-table
      ></TableCard
    ></WorkspacePage
  >
</template>
