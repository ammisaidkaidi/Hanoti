<script setup>
import { computed, reactive, ref, onBeforeUnmount, onMounted } from "vue";
import { onBeforeRouteLeave, useRoute, useRouter } from "vue-router";
import PageHeader from "../components/PageHeader.vue";
import SettingsField from "../components/SettingsField.vue";
import {
  useAccountSettings,
  defaultAvatar,
} from "../composables/useAccountSettings";
const route = useRoute(),
  router = useRouter();
const { draft, dirty, save, reset, sectionDirty } = useAccountSettings();
const tabs = [
  { value: "account", title: "Account", icon: "profile" },
  { value: "notification", title: "Notification", icon: "bell" },
  { value: "bills", title: "Bills", icon: "invoice" },
  { value: "security", title: "Security", icon: "lock" },
];
const tab = computed({
  get: () =>
    tabs.some((t) => t.value === route.query.tab) ? route.query.tab : "account",
  set: (value) =>
    router.replace({ query: value === "account" ? {} : { tab: value } }),
});
const forms = ref({}),
  upload = ref(null),
  uploadError = ref(""),
  saving = ref(false),
  snackbar = ref(false),
  message = ref(""),
  messageColor = ref("primary");
const passwords = reactive({ current: "", next: "", confirm: "" });
const passwordsDirty = computed(() => Object.values(passwords).some(Boolean));
const hasChanges = computed(() => dirty.value || passwordsDirty.value);
const required = (v) => !!String(v || "").trim() || "This field is required.";
const email = (v) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || "") || "Enter a valid email address.";
const phone = (v) =>
  /^[+()\d\s.-]{7,25}$/.test(v || "") || "Enter a valid phone number.";
const passwordRules = {
  current: [
    (v) => !passwordsDirty.value || !!v || "Enter your current password.",
  ],
  next: [
    (v) =>
      !passwordsDirty.value ||
      String(v).length >= 8 ||
      "Use at least 8 characters.",
    (v) =>
      !passwordsDirty.value ||
      v !== passwords.current ||
      "Choose a different password.",
  ],
  confirm: [
    (v) =>
      !passwordsDirty.value ||
      (!!v && v === passwords.next) ||
      "Passwords do not match.",
  ],
};
const locations = [
  "United States",
  "United Kingdom",
  "India",
  "Russia",
  "Algeria",
  "France",
  "Romania",
];
const currencies = [
  "US Dollar ($)",
  "United Kingdom (Pound)",
  "India (INR)",
  "Russia (Ruble)",
  "Algerian Dinar (DZD)",
  "Euro (€)",
];
const preferences = [
  {
    key: "newsletter",
    title: "Our newsletter",
    text: "We will always let you know about important changes",
    icon: "file",
  },
  {
    key: "confirmation",
    title: "Order Confirmation",
    text: "You will be notified when a customer orders any product",
    icon: "check",
  },
  {
    key: "status",
    title: "Order Status Changed",
    text: "You will be notified when a customer makes changes to an order",
    icon: "clock",
  },
  {
    key: "delivered",
    title: "Order Delivered",
    text: "You will be notified once an order is delivered",
    icon: "truck",
  },
  {
    key: "emailUpdates",
    title: "Email Notification",
    text: "Turn on email notifications to get updates through email",
    icon: "email",
  },
];
const zones = [
  { title: "(UTC +02:00) Athens, Bucharest", value: "Europe/Athens" },
  { title: "(UTC +00:00) London", value: "Europe/London" },
  { title: "(UTC +01:00) Algiers", value: "Africa/Algiers" },
  { title: "(UTC -05:00) New York", value: "America/New_York" },
  { title: "(UTC +05:30) Kolkata", value: "Asia/Kolkata" },
];
const plans = [
  { name: "Starter", visits: "50,000", price: "Free" },
  { name: "Professional", visits: "250,000", price: "$29 / month" },
  { name: "Executive", visits: "750,000", price: "$59 / month" },
];
const selectedPlan = computed(
  () => plans.find((p) => p.name === draft.bills.plan) || plans[2],
);
const planDialog = ref(false),
  planChoice = ref("Executive"),
  paymentDialog = ref(false),
  helpDialog = ref(false);
const setupDialog = ref(false),
  setupMode = ref("app"),
  setupValue = ref(""),
  setupError = ref("");
const setupTitle = computed(
  () =>
    ({
      app: "Authentication App",
      email: "Recovery email",
      sms: "SMS Recovery",
      twoFactor: "Two-factor Authentication",
    })[setupMode.value],
);
const deviceDetails = {
  iphone: {
    title: "iPhone 14",
    text: "London UK, Oct 23 at 1:15 AM",
    icon: "phone",
  },
  macbook: {
    title: "Macbook Air",
    text: "Gujarat India, Oct 24 at 3:15 AM",
    icon: "laptop",
  },
};
const confirmDialog = ref(false),
  confirmation = reactive({ title: "", text: "", action: null });
const leaveDialog = ref(false);
let resolveLeave = null;
const notify = (text, color = "primary") => {
  message.value = text;
  messageColor.value = color;
  snackbar.value = true;
};
function askConfirmation(title, text, action) {
  Object.assign(confirmation, { title, text, action });
  confirmDialog.value = true;
}
function confirmAction() {
  confirmation.action?.();
  confirmDialog.value = false;
}
function clearPasswords() {
  passwords.current = "";
  passwords.next = "";
  passwords.confirm = "";
}
async function saveTab() {
  const form = forms.value[tab.value];
  if (form) {
    const { valid } = await form.validate();
    if (!valid) {
      notify("Please correct the highlighted fields.", "error");
      return;
    }
  }
  saving.value = true;
  try {
    const checkedPassword = tab.value === "account" && passwordsDirty.value;
    save(tab.value);
    if (tab.value === "account") clearPasswords();
    notify(
      checkedPassword
        ? "Profile saved locally. Password format checked only; no real password was changed."
        : "Changes saved in this browser.",
    );
  } catch (error) {
    notify(error.message, "error");
  } finally {
    saving.value = false;
  }
}
function cancelChanges() {
  reset(tab.value);
  if (tab.value === "account") {
    clearPasswords();
    uploadError.value = "";
  }
  forms.value[tab.value]?.resetValidation();
  notify("Unsaved changes in this tab were discarded.");
}
function readUpload(event) {
  const file = event.target.files?.[0];
  event.target.value = "";
  if (!file) return;
  uploadError.value = "";
  if (!["image/jpeg", "image/png", "image/gif"].includes(file.type)) {
    uploadError.value = "Please choose a JPG, PNG, or GIF image.";
    return;
  }
  if (file.size > 800 * 1024) {
    uploadError.value = "The image must be 800 KB or smaller.";
    return;
  }
  const reader = new FileReader();
  reader.onerror = () => (uploadError.value = "This image could not be read.");
  reader.onload = () => {
    const image = new Image();
    image.onload = () => {
      draft.account.avatar = reader.result;
    };
    image.onerror = () =>
      (uploadError.value = "The file is not a valid image.");
    image.src = reader.result;
  };
  reader.readAsDataURL(file);
}
function openSetup(mode) {
  setupMode.value = mode;
  setupValue.value =
    mode === "email"
      ? draft.security.recoveryEmail
      : mode === "sms"
        ? draft.security.recoveryPhone
        : "";
  setupError.value = "";
  setupDialog.value = true;
}
function finishSetup() {
  if (setupMode.value === "email" && email(setupValue.value) !== true) {
    setupError.value = "Enter a valid recovery email.";
    return;
  }
  if (setupMode.value === "sms" && phone(setupValue.value) !== true) {
    setupError.value = "Enter a valid recovery phone number.";
    return;
  }
  if (setupMode.value === "app") draft.security.app = true;
  if (setupMode.value === "email")
    draft.security.recoveryEmail = setupValue.value;
  if (setupMode.value === "sms")
    draft.security.recoveryPhone = setupValue.value;
  if (setupMode.value === "twoFactor")
    draft.security.twoFactor = !draft.security.twoFactor;
  setupDialog.value = false;
  notify("Demo setting updated. Choose Save to keep it locally.");
}
function respondToLeave(leave) {
  leaveDialog.value = false;
  resolveLeave?.(leave);
  resolveLeave = null;
}
onBeforeRouteLeave(() => {
  if (!hasChanges.value) return true;
  leaveDialog.value = true;
  return new Promise((resolve) => {
    resolveLeave = resolve;
  });
});
function beforeUnload(e) {
  if (hasChanges.value) {
    e.preventDefault();
    e.returnValue = "";
  }
}
onMounted(() => window.addEventListener("beforeunload", beforeUnload));
onBeforeUnmount(() => {
  window.removeEventListener("beforeunload", beforeUnload);
  clearPasswords();
});
</script>
<template>
  <div class="account-page">
    <PageHeader title="Account Setting" />
    <v-card class="account-shell">
      <v-tabs
        v-model="tab"
        color="primary"
        height="70"
        class="account-tabs"
        aria-label="Account settings sections"
        ><v-tab v-for="item in tabs" :key="item.value" :value="item.value"
          ><Icon :name="item.icon" :size="19" />{{ item.title
          }}<span
            v-if="
              sectionDirty(item.value) ||
              (item.value === 'account' && passwordsDirty)
            "
            class="tab-dirty"
            aria-label="Unsaved changes"
          ></span></v-tab
      ></v-tabs>
      <div class="account-content">
        <v-form
          v-if="tab === 'account'"
          :ref="(el) => (forms.account = el)"
          @submit.prevent="saveTab"
        >
          <div class="account-top-grid">
            <v-card class="settings-panel profile-panel" variant="outlined"
              ><h2>Change Profile</h2>
              <p class="settings-description">
                Change your profile picture from here
              </p>
              <div class="profile-editor">
                <v-avatar size="120"
                  ><img
                    :src="draft.account.avatar"
                    alt="Profile preview"
                    width="120"
                    height="120"
                /></v-avatar>
                <div class="profile-actions">
                  <v-btn color="primary" @click="upload.click()">Upload</v-btn
                  ><v-btn
                    variant="outlined"
                    color="error"
                    @click="
                      draft.account.avatar = defaultAvatar;
                      uploadError = '';
                    "
                    >Reset</v-btn
                  >
                </div>
                <input
                  ref="upload"
                  type="file"
                  accept="image/jpeg,image/png,image/gif"
                  class="visually-hidden"
                  aria-label="Upload profile image"
                  @change="readUpload"
                />
                <p class="muted">Allowed JPG, GIF or PNG. Max size of 800K</p>
                <p v-if="uploadError" class="text-error mt-3" role="alert">
                  {{ uploadError }}
                </p>
              </div></v-card
            >
            <v-card class="settings-panel password-panel" variant="outlined"
              ><h2>Change Password</h2>
              <p class="settings-description">
                To change your password please confirm here
              </p>
              <div class="field-stack">
                <SettingsField
                  v-model="passwords.current"
                  id="current-password"
                  label="Current Password"
                  password
                  :rules="passwordRules.current"
                  placeholder="Enter current password"
                /><SettingsField
                  v-model="passwords.next"
                  id="new-password"
                  label="New Password"
                  password
                  :rules="passwordRules.next"
                  placeholder="At least 8 characters"
                /><SettingsField
                  v-model="passwords.confirm"
                  id="confirm-password"
                  label="Confirm Password"
                  password
                  :rules="passwordRules.confirm"
                  placeholder="Re-enter new password"
                />
              </div>
              <p class="demo-caption mt-3">
                Demo only. Passwords are checked, never saved or changed.
              </p></v-card
            >
          </div>
          <v-card class="settings-panel personal-panel" variant="outlined"
            ><h2>Personal Details</h2>
            <p class="settings-description">
              To change your personal details, edit and save from here
            </p>
            <div class="account-fields">
              <SettingsField
                v-model="draft.account.name"
                id="account-name"
                label="Your Name"
                :rules="[required]"
              /><SettingsField
                v-model="draft.account.store"
                id="account-store"
                label="Store Name"
                :rules="[required]"
              /><SettingsField
                v-model="draft.account.location"
                id="account-location"
                label="Location"
                :items="locations"
                :rules="[required]"
              /><SettingsField
                v-model="draft.account.currency"
                id="account-currency"
                label="Currency"
                :items="currencies"
                :rules="[required]"
              /><SettingsField
                v-model="draft.account.email"
                id="account-email"
                label="Email"
                type="email"
                :rules="[required, email]"
              /><SettingsField
                v-model="draft.account.phone"
                id="account-phone"
                label="Phone"
                type="tel"
                :rules="[required, phone]"
              /><SettingsField
                v-model="draft.account.address"
                id="account-address"
                label="Address"
                class="full-field"
                :rules="[required]"
              /></div
          ></v-card>
        </v-form>
        <v-form
          v-if="tab === 'notification'"
          :ref="(el) => (forms.notification = el)"
          @submit.prevent="saveTab"
          class="settings-narrow"
        >
          <v-card class="settings-panel" variant="outlined"
            ><h2>Notification Preferences</h2>
            <p class="settings-description">
              Select the notifications you would like to receive via email.
              Please note that you cannot opt out of receiving service messages,
              such as payment, security or legal notifications.
            </p>
            <SettingsField
              v-model="draft.notification.email"
              id="notification-email"
              label="Email Address*"
              type="email"
              :rules="[required, email]"
              hint="Required for notifications."
              class="mt-6" />
            <div class="preference-list">
              <div
                v-for="item in preferences"
                :key="item.key"
                class="preference-row"
              >
                <v-avatar rounded="lg" color="rail" size="48"
                  ><Icon :name="item.icon" :size="22"
                /></v-avatar>
                <div class="preference-copy">
                  <h3>{{ item.title }}</h3>
                  <p>{{ item.text }}</p>
                </div>
                <v-switch
                  v-model="draft.notification[item.key]"
                  color="primary"
                  hide-details
                  :aria-label="item.title"
                  class="preference-switch"
                />
              </div></div
          ></v-card>
          <v-card class="settings-panel" variant="outlined"
            ><h2>Date &amp; Time</h2>
            <p class="settings-description">
              Time zones and calendar display settings.
            </p>
            <div class="timezone-row">
              <v-avatar rounded="lg" color="rail" size="48"
                ><Icon name="clock" :size="22" /></v-avatar
              ><SettingsField
                v-model="draft.notification.timezone"
                id="timezone"
                label="Time zone"
                :items="zones"
              />
            </div>
            <p class="demo-caption mt-3">
              UTC offsets shown are standard-time labels; daylight saving may
              apply.
            </p></v-card
          >
          <v-card class="settings-panel" variant="outlined"
            ><h2>Ignore Tracking</h2>
            <div class="preference-row mt-6">
              <v-avatar rounded="lg" color="rail" size="48"
                ><Icon name="panel" :size="22"
              /></v-avatar>
              <div class="preference-copy">
                <h3>Ignore Browser Tracking</h3>
                <p>Browser Cookie</p>
              </div>
              <v-switch
                v-model="draft.notification.ignoreTracking"
                aria-label="Ignore Browser Tracking"
                color="primary"
                hide-details
                class="preference-switch"
              />
            </div>
            <p class="demo-caption mt-3">
              Preference preview only. This app does not send analytics or
              notification emails.
            </p></v-card
          >
        </v-form>
        <v-form
          v-if="tab === 'bills'"
          :ref="(el) => (forms.bills = el)"
          @submit.prevent="saveTab"
          class="settings-narrow"
        >
          <v-card class="settings-panel" variant="outlined"
            ><h2>Billing Information</h2>
            <div class="account-fields">
              <SettingsField
                v-model="draft.bills.business"
                id="billing-business"
                label="Business Name*"
                :rules="[required]"
              /><SettingsField
                v-model="draft.bills.sector"
                id="billing-sector"
                label="Business Sector*"
                :rules="[required]"
              /><SettingsField
                v-model="draft.bills.address"
                id="billing-address"
                label="Business Address*"
                :rules="[required]"
              /><SettingsField
                v-model="draft.bills.country"
                id="billing-country"
                label="Country*"
                :rules="[required]"
              /><SettingsField
                v-model="draft.bills.firstName"
                id="billing-firstname"
                label="First Name*"
                :rules="[required]"
              /><SettingsField
                v-model="draft.bills.lastName"
                id="billing-lastname"
                label="Last Name*"
                :rules="[required]"
              /></div
          ></v-card>
          <v-card class="settings-panel" variant="outlined"
            ><h2>
              Current Plan :
              <span
                :class="draft.bills.cancelled ? 'text-error' : 'text-success'"
                >{{
                  draft.bills.cancelled ? "Cancelled" : draft.bills.plan
                }}</span
              >
            </h2>
            <p class="settings-description">
              {{
                draft.bills.cancelled
                  ? "Your sample subscription is marked as cancelled."
                  : "Thanks for being a premium member and supporting our development."
              }}
            </p>
            <div class="plan-summary">
              <v-avatar color="lightprimary" rounded="lg" size="48"
                ><Icon name="package" :size="22"
              /></v-avatar>
              <div>
                <p class="muted">Current Plan</p>
                <h3>{{ selectedPlan.visits }} Monthly Visits</h3>
              </div>
              <v-spacer /><v-btn
                icon
                variant="text"
                size="32"
                aria-label="View plan choices"
                @click="
                  planChoice = draft.bills.plan;
                  planDialog = true;
                "
                ><Icon name="plus"
              /></v-btn>
            </div>
            <div class="d-flex ga-4 flex-wrap">
              <v-btn
                color="primary"
                @click="
                  planChoice = draft.bills.plan;
                  planDialog = true;
                "
                >Change Plan</v-btn
              ><v-btn
                color="error"
                variant="outlined"
                @click="
                  draft.bills.plan = 'Executive';
                  draft.bills.cancelled = false;
                "
                >Reset Plan</v-btn
              >
            </div></v-card
          >
          <v-card class="settings-panel" variant="outlined"
            ><h2>Payment Method</h2>
            <p class="settings-description">On 26 December, 2024</p>
            <div class="plan-summary">
              <v-avatar color="lightprimary" rounded="lg" size="48"
                ><Icon name="creditcard" :size="22"
              /></v-avatar>
              <div>
                <h3>Visa</h3>
                <p class="mt-1">*****2102</p>
              </div>
              <v-spacer /><v-btn
                icon
                variant="text"
                size="32"
                aria-label="Payment method details"
                @click="paymentDialog = true"
                ><Icon name="edit" :size="21"
              /></v-btn>
            </div>
            <p class="settings-description">
              If you update your payment method, it will only be displayed here
              after your next billing cycle.
            </p>
            <v-btn
              color="error"
              variant="tonal"
              class="mt-3"
              :disabled="draft.bills.cancelled"
              @click="
                askConfirmation(
                  'Cancel sample subscription?',
                  'This changes only the local demo. No real subscription or payment will be affected.',
                  () => (draft.bills.cancelled = true),
                )
              "
              >Cancel Subscription</v-btn
            >
            <p class="demo-caption mt-4">
              Demo billing information. No payment service is connected.
            </p></v-card
          >
        </v-form>
        <div v-if="tab === 'security'" class="security-grid">
          <v-card class="settings-panel security-methods" variant="outlined"
            ><h2>Two-factor Authentication</h2>
            <div class="security-intro">
              <p class="settings-description">
                Add an extra layer of protection to your account. Explore the
                setup options in this local demonstration.
              </p>
              <v-btn color="primary" @click="openSetup('twoFactor')">{{
                draft.security.twoFactor ? "Disable" : "Enable"
              }}</v-btn>
            </div>
            <v-chip
              v-if="draft.security.twoFactor"
              color="success"
              size="small"
              class="mb-4"
              >Enabled in demo only</v-chip
            >
            <div class="security-row">
              <div>
                <h3>Authentication App</h3>
                <p>
                  {{
                    draft.security.app
                      ? "Configured in this demo"
                      : "Google auth app"
                  }}
                </p>
              </div>
              <v-btn
                variant="tonal"
                color="primary"
                @click="openSetup('app')"
                >{{ draft.security.app ? "Manage" : "Setup" }}</v-btn
              >
            </div>
            <div class="security-row">
              <div>
                <h3>Another e-mail</h3>
                <p>
                  {{
                    draft.security.recoveryEmail ||
                    "E-mail to send verification link"
                  }}
                </p>
              </div>
              <v-btn
                variant="tonal"
                color="primary"
                @click="openSetup('email')"
                >{{ draft.security.recoveryEmail ? "Manage" : "Setup" }}</v-btn
              >
            </div>
            <div class="security-row">
              <div>
                <h3>SMS Recovery</h3>
                <p>
                  {{
                    draft.security.recoveryPhone ||
                    "Your phone number for account recovery"
                  }}
                </p>
              </div>
              <v-btn
                variant="tonal"
                color="primary"
                @click="openSetup('sms')"
                >{{ draft.security.recoveryPhone ? "Manage" : "Setup" }}</v-btn
              >
            </div>
            <p class="demo-caption mt-5">
              These controls do not activate real MFA, verify recovery details,
              or protect an account. A backend integration is required.
            </p></v-card
          >
          <v-card class="settings-panel devices-panel" variant="outlined"
            ><v-avatar color="lightprimary" rounded="lg" size="48" class="mb-4"
              ><Icon name="laptop" class="text-primary" :size="23"
            /></v-avatar>
            <h2>Devices</h2>
            <p class="settings-description">
              Review the sample devices associated with this account.
            </p>
            <v-btn
              color="primary"
              class="mt-4 signout-button"
              :disabled="!draft.security.devices.length"
              @click="
                askConfirmation(
                  'Sign out sample devices?',
                  'This will clear the demo device list only. No real sessions will be ended.',
                  () => (draft.security.devices = []),
                )
              "
              >Sign Out From All Devices</v-btn
            >
            <div class="device-list">
              <div
                v-for="id in draft.security.devices"
                :key="id"
                class="device-row"
              >
                <Icon :name="deviceDetails[id]?.icon || 'monitor'" :size="23" />
                <div>
                  <h3>{{ deviceDetails[id]?.title }}</h3>
                  <p>{{ deviceDetails[id]?.text }}</p>
                </div>
                <v-menu
                  ><template #activator="{ props }"
                    ><v-btn
                      v-bind="props"
                      icon
                      size="28"
                      variant="text"
                      :aria-label="'Options for ' + deviceDetails[id]?.title"
                      ><Icon name="more" :size="18" /></v-btn></template
                  ><v-list
                    ><v-list-item
                      title="Remove sample device"
                      @click="
                        askConfirmation(
                          'Remove this sample device?',
                          'Only the local device list will change.',
                          () =>
                            (draft.security.devices =
                              draft.security.devices.filter((d) => d !== id)),
                        )
                      " /></v-list
                ></v-menu>
              </div>
              <p v-if="!draft.security.devices.length" class="empty-devices">
                <Icon name="checks" :size="28" /><span
                  >No sample devices signed in</span
                >
              </p>
            </div>
            <v-btn
              block
              color="primary"
              variant="tonal"
              @click="helpDialog = true"
              >Need Help?</v-btn
            ></v-card
          >
        </div>
        <div class="settings-footer">
          <span class="save-caption">{{
            sectionDirty(tab) || (tab === "account" && passwordsDirty)
              ? "You have unsaved changes"
              : "Changes are stored in this browser only"
          }}</span
          ><v-btn color="primary" :loading="saving" @click="saveTab">Save</v-btn
          ><v-btn color="error" variant="tonal" @click="cancelChanges"
            >Cancel</v-btn
          >
        </div>
      </div>
    </v-card>
  </div>
  <v-snackbar
    v-model="snackbar"
    :color="messageColor"
    location="top right"
    :timeout="5000"
    >{{ message
    }}<template #actions
      ><v-btn
        icon
        size="small"
        variant="text"
        aria-label="Dismiss message"
        @click="snackbar = false"
        ><Icon name="close" /></v-btn></template
  ></v-snackbar>
  <v-dialog v-model="planDialog" max-width="630"
    ><v-card class="dialog-body"
      ><div class="dialog-title">
        <h2>Choose your plan</h2>
        <v-btn
          icon
          size="small"
          variant="text"
          aria-label="Close plan choices"
          @click="planDialog = false"
          ><Icon name="close"
        /></v-btn>
      </div>
      <p class="muted mb-5">
        Preview a subscription plan. This does not create a charge.
      </p>
      <div class="plan-options">
        <button
          v-for="plan in plans"
          :key="plan.name"
          :class="['plan-option', { chosen: planChoice === plan.name }]"
          :aria-pressed="planChoice === plan.name"
          @click="planChoice = plan.name"
        >
          <Icon name="package" :size="26" />
          <h3>{{ plan.name }}</h3>
          <strong>{{ plan.price }}</strong
          ><span>{{ plan.visits }} monthly visits</span
          ><Icon
            v-if="planChoice === plan.name"
            name="check"
            class="text-primary"
          />
        </button>
      </div>
      <div class="dialog-actions">
        <v-btn variant="text" @click="planDialog = false">Cancel</v-btn
        ><v-btn
          color="primary"
          @click="
            draft.bills.plan = planChoice;
            draft.bills.cancelled = false;
            planDialog = false;
          "
          >Use this demo plan</v-btn
        >
      </div></v-card
    ></v-dialog
  >
  <v-dialog v-model="paymentDialog"
    ><v-card class="dialog-body"
      ><v-avatar size="52" color="lightprimary" class="mb-4"
        ><Icon name="creditcard" class="text-primary" :size="26"
      /></v-avatar>
      <h2>Payment method preview</h2>
      <p class="muted mt-3">
        Visa ending in 2102 is sample data. This app does not collect or store
        payment card numbers. Connect a payment provider’s secure hosted form
        before enabling payment updates.
      </p>
      <v-btn color="primary" class="mt-6" @click="paymentDialog = false"
        >Got it</v-btn
      ></v-card
    ></v-dialog
  >
  <v-dialog v-model="setupDialog"
    ><v-card class="dialog-body"
      ><div class="dialog-title">
        <h2>{{ setupTitle }}</h2>
        <v-btn
          icon
          size="small"
          variant="text"
          aria-label="Close security setup"
          @click="setupDialog = false"
          ><Icon name="close"
        /></v-btn>
      </div>
      <v-alert type="info" variant="tonal" class="mb-5" density="compact"
        >Demo setup only. No codes, emails, or SMS messages are sent.</v-alert
      ><template v-if="setupMode === 'app'"
        ><div class="auth-app-preview">
          <v-avatar size="64" rounded="lg" color="lightprimary"
            ><Icon name="shield" :size="32" class="text-primary"
          /></v-avatar>
          <div>
            <h3>Authenticator app</h3>
            <p class="muted">
              A real setup requires a server-generated secret and verified
              time-based code.
            </p>
          </div>
        </div></template
      ><SettingsField
        v-if="setupMode === 'email'"
        v-model="setupValue"
        id="recovery-email"
        label="Recovery email address"
        type="email"
      /><SettingsField
        v-if="setupMode === 'sms'"
        v-model="setupValue"
        id="recovery-phone"
        label="Recovery phone number"
        type="tel"
      />
      <p v-if="setupMode === 'twoFactor'" class="muted">
        {{ draft.security.twoFactor ? "Disable" : "Enable" }} the two-factor
        setting in the local preview. This does not change real account
        security.
      </p>
      <p v-if="setupError" class="text-error mt-2" role="alert">
        {{ setupError }}
      </p>
      <div class="dialog-actions">
        <v-btn variant="text" @click="setupDialog = false">Cancel</v-btn
        ><v-btn color="primary" @click="finishSetup">{{
          setupMode === "app"
            ? "Mark as configured"
            : setupMode === "twoFactor"
              ? "Confirm demo setting"
              : "Use for demo"
        }}</v-btn>
      </div></v-card
    ></v-dialog
  >
  <v-dialog v-model="confirmDialog"
    ><v-card class="dialog-body"
      ><h2>{{ confirmation.title }}</h2>
      <p class="muted mt-3">{{ confirmation.text }}</p>
      <div class="dialog-actions">
        <v-btn variant="text" @click="confirmDialog = false"
          >Keep current setting</v-btn
        ><v-btn color="error" @click="confirmAction">Confirm</v-btn>
      </div></v-card
    ></v-dialog
  >
  <v-dialog :model-value="leaveDialog" persistent
    ><v-card class="dialog-body"
      ><h2>Leave without saving?</h2>
      <p class="muted mt-3">
        Your unsaved account changes will be discarded. Stay here to save them
        first.
      </p>
      <div class="dialog-actions">
        <v-btn variant="text" @click="respondToLeave(false)">Stay here</v-btn
        ><v-btn color="error" @click="respondToLeave(true)"
          >Discard and leave</v-btn
        >
      </div></v-card
    ></v-dialog
  >
  <v-dialog v-model="helpDialog"
    ><v-card class="dialog-body"
      ><h2>Keep your account secure</h2>
      <p class="muted mt-3">
        Use a unique password, enable authenticator-based two-factor
        authentication, and regularly review active sessions.
      </p>
      <p class="muted mt-3">
        This is a front-end preview. Real authentication and device management
        must be implemented by your backend.
      </p>
      <v-btn color="primary" class="mt-6" @click="helpDialog = false"
        >Understood</v-btn
      ></v-card
    ></v-dialog
  >
</template>
