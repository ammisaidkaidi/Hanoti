<script setup>
import { computed } from "vue";
import { useRoute } from "vue-router";
import PageHeader from "../components/PageHeader.vue";
import { routeCatalog } from "../data/navigation";
const route = useRoute();
const related = computed(() =>
  routeCatalog
    .filter(
      (p) => p.category === route.meta.category && p.path !== route.meta.path,
    )
    .slice(0, 5),
);
</script>
<template>
  <div class="queued-page">
    <PageHeader
      :title="route.meta.label || route.meta.title"
      :category="route.meta.category"
    /><v-card class="queued-content"
      ><v-avatar color="lightprimary" rounded="xl" size="76"
        ><Icon
          :name="route.meta.icon"
          :size="36"
          class="text-primary" /></v-avatar
      ><v-chip size="small" color="primary" variant="tonal" class="mt-6 mb-3"
        >Mapped · awaiting rebuild</v-chip
      >
      <h2>{{ route.meta.title }}</h2>
      <p class="queued-description">
        This route is connected to your app, but its page has not been recreated
        yet. It is part of the next stages of the full MatDash rebuild.
      </p>
      <code class="queued-path">{{ route.path }}</code>
      <div class="queued-actions">
        <v-btn color="primary" to="/pages/account-settings"
          >Open Account Settings</v-btn
        ><v-btn variant="outlined" color="primary" to="/pages/route-directory"
          >View all routes</v-btn
        >
      </div>
      <div class="queued-note">
        <Icon name="info" :size="18" /><span
          >This is a clearly marked placeholder, not the completed
          {{ route.meta.label }} page.</span
        >
      </div></v-card
    ><v-card v-if="related.length" class="related-routes"
      ><h3>More in {{ route.meta.category }}</h3>
      <div>
        <v-btn
          v-for="page in related"
          :key="page.path"
          :to="page.path"
          variant="tonal"
          color="primary"
          size="small"
          >{{ page.label }}<Icon name="right" :size="14" class="ml-1"
        /></v-btn></div
    ></v-card>
  </div>
</template>
