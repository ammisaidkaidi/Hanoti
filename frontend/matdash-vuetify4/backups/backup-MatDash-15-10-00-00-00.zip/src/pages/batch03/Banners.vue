<script setup>
import { ref } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { asset, avatar } from "../../data/app-seed";
import { pageDemos } from "../../composables/usePageDemos";
import { notify } from "../../composables/useFeedback";
const acknowledged = ref(false),
  retried = ref(false);
function download() {
  const url = URL.createObjectURL(
    new Blob(
      [
        "Date,Description,Amount\n2026-10-14,Sample income,6235\n2026-10-14,Sample expense,-345\n",
      ],
      { type: "text/csv" },
    ),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = "demo-transactions.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
</script>
<template>
  <WorkspacePage title="Banner Widgets" data-batch="3"
    ><div class="b3-banner-layout">
      <div class="example-stack">
        <v-card color="primary" class="b3-wide-banner"
          ><img :src="asset('welcome-bg2-')" alt="" />
          <div>
            <h2>Welcome back David!</h2>
            <p>
              You have earned 54% more than last month which is great thing.
            </p>
            <v-btn to="/dashboards/dashboard2" color="error">Check</v-btn>
          </div></v-card
        ><v-card color="lightsecondary" class="b3-wide-banner"
          ><img :src="asset('track-bg-')" alt="Transaction illustration" />
          <div>
            <h2>Track your every Transaction Easily</h2>
            <p>
              Track and record your every income and expense easily to control
              your balance
            </p>
            <v-btn color="secondary" @click="download">Download</v-btn>
          </div></v-card
        >
        <div class="b3-two">
          <v-card class="b3-banner-small"
            ><img :src="asset('maintenance-')" alt="Maintenance illustration" />
            <h2>
              {{
                retried ? "Demo check complete" : "Oops something went wrong!"
              }}
            </h2>
            <p>
              {{
                retried
                  ? "This demonstration has reset. No server request was made."
                  : "Trying again to bypass these temporary errors."
              }}
            </p>
            <v-btn color="error" @click="retried = !retried">{{
              retried ? "Reset example" : "Retry"
            }}</v-btn></v-card
          ><v-card class="b3-banner-small"
            ><img
              :src="asset('empty-shopping-cart-')"
              alt="Empty shopping cart"
            />
            <h2>Oop, Your cart is empty!</h2>
            <p>Get back to shopping and get rewards from it.</p>
            <v-btn color="primary" to="/ecommerce/products"
              >Go For Shopping</v-btn
            ></v-card
          >
        </div>
      </div>
      <div class="example-stack">
        <v-card class="b3-banner-small"
          ><p>LEVEL UP</p>
          <img :src="asset('gold-')" alt="Gold achievement medal" />
          <h2>
            {{
              acknowledged
                ? "Ready for your next task"
                : "You reach all Notifications"
            }}
          </h2>
          <p>Congratulations,<br />Tap to continue next task.</p>
          <v-btn
            color="primary"
            @click="
              acknowledged = true;
              notify('Achievement acknowledged locally.');
            "
            >{{ acknowledged ? "Got it!" : "Yes, Got It!" }}</v-btn
          ></v-card
        ><v-card class="b3-banner-small"
          ><h2>Mutual Friend Revealed</h2>
          <v-avatar size="120" class="my-5"
            ><img :src="avatar(3)" alt="Tommoie Henderson"
          /></v-avatar>
          <h3>Tommoie Henderson</h3>
          <p>
            {{
              pageDemos.bannerFriend === "pending"
                ? "Accept the request and type a message"
                : pageDemos.bannerFriend === "accepted"
                  ? "Request accepted locally."
                  : "Request removed locally."
            }}
          </p>
          <div class="button-samples justify-center">
            <v-btn
              v-if="pageDemos.bannerFriend === 'pending'"
              color="primary"
              @click="pageDemos.bannerFriend = 'accepted'"
              >Accept</v-btn
            ><v-btn
              v-if="pageDemos.bannerFriend === 'pending'"
              color="error"
              variant="tonal"
              @click="pageDemos.bannerFriend = 'removed'"
              >Remove</v-btn
            ><v-btn
              v-else
              variant="text"
              @click="pageDemos.bannerFriend = 'pending'"
              >Reset request</v-btn
            >
          </div></v-card
        >
      </div>
    </div></WorkspacePage
  >
</template>
