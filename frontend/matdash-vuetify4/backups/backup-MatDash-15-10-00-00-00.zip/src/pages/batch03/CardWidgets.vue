<script setup>
import { ref } from "vue";
import { VSlider } from "vuetify/components";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import Activities from "../../components/batch03/Activities.vue";
import { articles, avatar, asset } from "../../data/app-seed";
import { demo, addToCart, money } from "../../composables/useDemoStore";
import { pageDemos, toggleFollow } from "../../composables/usePageDemos";
import { notify, confirmDemo } from "../../composables/useFeedback";
const sound = ref(pageDemos.sound),
  chat = ref(pageDemos.chat),
  detail = ref(null);
const people = ["Andrew Grant", "Leo Pratt", "Charles Nunez", "Lora Powers"];
const gateways = [
  ["Paypal", "Big Brands", "+$6,235", "primary"],
  ["Wallet", "Bill payment", "−$345", "secondary"],
  ["Credit Card", "Money reversed", "+$2,235", "warning"],
  ["Refund", "Bill Payment", "−$32", "error"],
];
async function gift(name) {
  if (
    await confirmDemo(
      "Preview gift for " + name,
      "This $50 gift is a sample interaction. No payment or gift is sent.",
    )
  )
    notify("Demo gift preview confirmed. No charge was made.");
}
</script>
<template>
  <WorkspacePage title="Cards Widgets" data-batch="3"
    ><div class="b3-three">
      <v-card v-for="a in articles.slice(5, 8)" :key="a.id" class="b3-blog-card"
        ><router-link :to="'/apps/blog/' + a.slug"
          ><img :src="a.image" :alt="a.title" />
          <div class="pa-5">
            <v-chip size="small" color="primary">{{ a.category }}</v-chip>
            <h2 class="my-4">{{ a.title }}</h2>
            <div class="article-meta">
              <span><Icon name="eye" :size="15" />{{ a.views }}</span
              ><span>3 comments</span><span>2 min read</span>
            </div>
          </div></router-link
        ></v-card
      >
    </div>
    <div class="b3-four my-6">
      <v-card
        v-for="p in demo.products.slice(2, 6)"
        :key="p.id"
        class="b3-widget-product"
        ><router-link :to="'/ecommerce/product/detail/' + p.id"
          ><img :src="p.image" :alt="p.name"
        /></router-link>
        <div class="pa-4">
          <h3>{{ p.name }}</h3>
          <p class="my-2">
            {{ money(p.price) }}
            <del class="muted">{{ money(p.oldPrice) }}</del>
          </p>
          <v-rating
            :model-value="p.rating"
            color="warning"
            size="17"
            readonly
            density="compact"
          /><v-btn
            color="primary"
            icon
            size="32"
            class="b3-cart-button"
            :aria-label="'Add ' + p.name + ' to cart'"
            @click="
              addToCart(p.id);
              notify('Added to your local cart.');
            "
            ><Icon name="cart" :size="17"
          /></v-btn></div
      ></v-card>
    </div>
    <div class="b3-three">
      <v-card
        v-for="([track, artist], i) in [
          ['Uptown Funk', 'Jon Bon Jovi'],
          ['Blank Space', 'Madonna'],
          ['Lean On', 'Jennifer Lopez'],
        ]"
        :key="track"
        class="b3-music-card"
        ><div>
          <h3>{{ track }}</h3>
          <p class="muted text-caption">{{ artist }}</p>
          <v-btn
            variant="text"
            size="small"
            @click="
              detail = {
                title: track,
                text:
                  'Illustrative music card for ' +
                  artist +
                  '. No audio file is bundled.',
              }
            "
            >Track details</v-btn
          >
        </div>
        <img :src="asset('blog-img' + (i + 1) + '-')" :alt="track + ' artwork'"
      /></v-card>
    </div>
    <div class="b3-three my-6">
      <v-card
        v-for="(name, i) in people.slice(0, 3)"
        :key="name"
        class="b3-follow-card"
        ><v-avatar size="40"><img :src="avatar(i + 2)" :alt="name" /></v-avatar>
        <div>
          <h3>{{ name }}</h3>
          <small class="muted">{{
            ["El Salvador", "Bulgaria", "Nepal"][i]
          }}</small>
        </div>
        <v-btn size="small" color="primary" @click="toggleFollow(100 + i)">{{
          pageDemos.following.includes(100 + i) ? "Followed" : "Follow"
        }}</v-btn></v-card
      >
    </div>
    <div class="b3-four">
      <v-card v-for="(name, i) in people" :key="name" class="b3-person"
        ><v-avatar size="66"><img :src="avatar(i + 2)" :alt="name" /></v-avatar>
        <h3 class="mt-3">{{ name }}</h3>
        <p class="muted text-caption my-3">3 mutual friends</p>
        <v-btn
          block
          color="primary"
          variant="tonal"
          size="small"
          @click="
            pageDemos.widgetFriends.includes(name)
              ? pageDemos.widgetFriends.splice(
                  pageDemos.widgetFriends.indexOf(name),
                  1,
                )
              : pageDemos.widgetFriends.push(name)
          "
          >{{
            pageDemos.widgetFriends.includes(name)
              ? "Friend added"
              : "Add Friend"
          }}</v-btn
        ><v-btn
          variant="text"
          color="error"
          size="small"
          class="mt-2"
          @click="
            pageDemos.widgetFriends = pageDemos.widgetFriends.filter(
              (n) => n !== name,
            );
            notify('Local request removed.');
          "
          >Remove</v-btn
        ></v-card
      >
    </div>
    <div class="b3-three my-6">
      <v-card
        v-for="(name, i) in people.slice(0, 3)"
        :key="name"
        class="b3-person"
        ><v-avatar size="65"><img :src="avatar(i + 2)" :alt="name" /></v-avatar>
        <h3 class="mt-3">{{ name }}</h3>
        <p class="muted mt-2">
          {{
            [
              "Technology Director",
              "Telecom Analyst",
              "Environmental Specialist",
            ][i]
          }}
        </p>
        <v-btn class="mt-3" variant="text" to="/pages/social-media-contacts"
          >View contacts</v-btn
        ></v-card
      >
    </div>
    <div class="b3-three">
      <v-card class="workspace-card"
        ><h2>Settings</h2>
        <h3 class="mt-5">Sound</h3>
        <v-slider
          v-model="sound"
          aria-label="Sound volume"
          color="primary"
          hide-details
          :step="1"
        />
        <p>{{ sound }}%</p>
        <v-switch v-model="chat" color="secondary" label="Chat" hide-details />
        <p class="muted text-caption">
          Turn on chat during call · Demo preference
        </p>
        <div class="demo-form-actions">
          <v-btn
            variant="text"
            @click="
              sound = pageDemos.sound;
              chat = pageDemos.chat;
            "
            >Cancel</v-btn
          ><v-btn
            color="primary"
            @click="
              pageDemos.sound = sound;
              pageDemos.chat = chat;
              notify('Widget settings saved locally.');
            "
            >Save</v-btn
          >
        </div></v-card
      ><v-card
        v-for="(name, i) in people.slice(0, 2)"
        :key="name"
        class="workspace-card"
        ><h3 class="mb-4">{{ name }}</h3>
        <img
          :src="asset('s' + (i + 1) + '-')"
          :alt="'Sample gift for ' + name"
          class="b3-gift-image"
        /><v-btn block color="primary" class="mt-4" @click="gift(name)"
          >Gift To Friend ($50.00)</v-btn
        ></v-card
      >
    </div>
    <div class="b3-three mt-6">
      <v-card class="workspace-card"
        ><h2>Payment Gateways</h2>
        <p class="muted text-caption mb-5">Platform For Income</p>
        <div
          v-for="[name, caption, value, color] in gateways"
          :key="name"
          class="b3-gateway"
        >
          <v-avatar :color="color" variant="tonal" rounded="lg" size="40"
            ><Icon name="creditcard" :size="19"
          /></v-avatar>
          <div>
            <h3>{{ name }}</h3>
            <small class="muted">{{ caption }}</small>
          </div>
          <strong>{{ value }}</strong>
        </div>
        <v-btn
          color="primary"
          block
          class="mt-5"
          @click="
            detail = {
              title: 'Sample transactions',
              text: gateways.map((g) => g[0] + ': ' + g[2]).join(' · '),
            }
          "
          >View All Transactions</v-btn
        ></v-card
      ><v-card class="workspace-card"
        ><h2>Upcoming Activity</h2>
        <p class="muted text-caption mb-5">In New year</p>
        <div
          v-for="(task, i) in [
            'Trip to singapore',
            'Archived Data',
            'Meeting with client',
            'Screening Task Team',
            'Send envelope to John',
          ]"
          :key="task"
          class="b3-upcoming"
        >
          <v-avatar size="34" color="secondary" variant="tonal"
            ><Icon name="calendar" :size="16"
          /></v-avatar>
          <div>
            <router-link to="/apps/calendar">{{ task }}</router-link>
            <p class="muted text-caption">
              {{ i === 2 ? "pending" : i === 4 ? "done" : "working on" }} ·
              {{ 5 + i * 5 }} mins
            </p>
          </div>
        </div></v-card
      ><Activities />
    </div>
    <v-dialog :model-value="!!detail" @update:model-value="detail = null"
      ><v-card v-if="detail" class="dialog-body"
        ><h2>{{ detail.title }}</h2>
        <p class="my-5">{{ detail.text }}</p>
        <v-btn color="primary" @click="detail = null">Close</v-btn></v-card
      ></v-dialog
    ></WorkspacePage
  >
</template>
