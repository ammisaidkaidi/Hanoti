<script setup>
import { ref, computed } from "vue";
import { useRoute } from "vue-router";
import FrontLayout from "../../components/batch03/FrontLayout.vue";
import { articles, asset, avatar } from "../../data/app-seed";
const route = useRoute(),
  list = route.path.endsWith("/posts"),
  query = ref("");
const all = [
  ...articles.slice(2),
  {
    id: 10,
    title: "COVID outbreak deepens as more lockdowns loom in China",
    category: "Health",
    image: asset("blog-img7-"),
    slug: "covid-outbreak-deepens-as-more-lockdowns-loom-in-china",
    author: "Robert Murray",
    avatar: avatar(3),
    date: "2026-10-10",
    views: 8262,
  },
  ...articles.slice(0, 2),
];
const filtered = computed(() =>
  all.filter((a) =>
    `${a.title} ${a.category}`
      .toLowerCase()
      .includes(query.value.toLowerCase()),
  ),
);
const article = computed(() => all.find((a) => a.slug === route.params.slug));
</script>
<template>
  <FrontLayout
    ><div class="b3-blog-hero front-container">
      <h1>{{ list ? "Latest blog & news" : "Our most recent articles" }}</h1>
      <p>
        <router-link to="/front-page/homepage">MATDASH</router-link>
        <span>•</span> {{ list ? "BLOG PAGE" : "BLOG DETAILS" }}
      </p>
    </div>
    <div class="front-container b3-blog-body">
      <template v-if="list"
        ><v-text-field
          v-model="query"
          label="Search articles"
          density="compact"
          class="b3-blog-search mb-7"
          ><template #prepend-inner><Icon name="search" :size="18" /></template
        ></v-text-field>
        <div class="b3-three">
          <v-card v-for="a in filtered" :key="a.id" class="b3-blog-card"
            ><router-link :to="'/front-page/blog/' + a.slug"
              ><div class="b3-blog-image">
                <img :src="a.image" :alt="a.title" loading="lazy" /><v-chip
                  size="small"
                  variant="flat"
                  >2 min read</v-chip
                >
              </div>
              <div class="pa-6">
                <v-avatar size="42" class="b3-blog-avatar"
                  ><img :src="a.avatar" :alt="a.author" /></v-avatar
                ><v-chip color="primary" size="small" class="mt-3">{{
                  a.category
                }}</v-chip>
                <h2 class="mt-4 mb-6">{{ a.title }}</h2>
                <div class="article-meta">
                  <span><Icon name="eye" :size="15" />{{ a.views }}</span
                  ><span><Icon name="chats" :size="15" />3</span
                  ><time>{{ a.date }}</time>
                </div>
              </div></router-link
            ></v-card
          >
        </div>
        <v-card v-if="!filtered.length" class="workspace-empty"
          >No articles match your search.</v-card
        ></template
      >
      <article v-else-if="article" class="b3-front-article">
        <img
          :src="article.image"
          :alt="article.title"
          class="b3-article-cover"
        />
        <div class="b3-article-heading">
          <v-avatar size="50"
            ><img :src="article.avatar" :alt="article.author" /></v-avatar
          ><v-chip size="small" color="primary" class="ml-4">{{
            article.category
          }}</v-chip>
          <h2>{{ article.title }}</h2>
          <div class="article-meta">
            <span><Icon name="eye" :size="17" />{{ article.views }}</span
            ><span><Icon name="chats" :size="17" />3</span
            ><time>{{ article.date }}</time>
          </div>
        </div>
        <v-divider />
        <div class="article-body">
          <h2>Title of the paragraph</h2>
          <p>
            Thoughtful design makes technology feel more approachable. From the
            products we use every day to the services that help us stay
            connected, the best experiences are clear, useful, and built around
            people.
          </p>
          <p>
            Finding the right product means looking beyond the headline.
            Consider the details, compare the features that matter to you, and
            take the time to understand how it fits into your everyday routine.
          </p>
          <p><strong>This is strong text.</strong></p>
          <p><em>This is italic text.</em></p>
          <h2>Unordered list.</h2>
          <ul>
            <li>Focus on the features that matter most.</li>
            <li>Compare quality, usability, and long-term value.</li>
            <li>Look for thoughtful details and dependable support.</li>
          </ul>
          <h2>Ordered list.</h2>
          <ol>
            <li>Explore your options and collect inspiration.</li>
            <li>Review the details and compare your shortlist.</li>
            <li>Make a considered choice that works for you.</li>
          </ol>
          <h2>Quotes</h2>
          <blockquote>
            Life is short, Smile while you still have teeth!
          </blockquote>
          <p class="text-caption muted">
            Illustrative article copy for this front-end recreation.
          </p>
          <v-btn to="/front-page/blog/posts" color="primary" variant="tonal"
            >Back to articles</v-btn
          >
        </div>
      </article>
      <v-card v-else class="workspace-empty"
        ><h2>Article not found</h2>
        <v-btn to="/front-page/blog/posts" color="primary" class="mt-4"
          >Browse articles</v-btn
        ></v-card
      >
    </div></FrontLayout
  >
</template>
