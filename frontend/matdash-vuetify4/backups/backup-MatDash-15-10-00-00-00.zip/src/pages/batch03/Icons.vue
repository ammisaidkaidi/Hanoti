<script setup>
import { ref, computed, onMounted, watch } from "vue";
import { useRoute } from "vue-router";
import { VPagination } from "vuetify/components";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { notify } from "../../composables/useFeedback";
const set = useRoute().path.endsWith("solar") ? "solar" : "tabler";
const data = ref(null),
  error = ref(""),
  query = ref(""),
  page = ref(1),
  selected = ref(null),
  copied = ref(false);
const names = computed(() =>
  Object.keys(data.value?.icons || {}).filter((n) =>
    n.includes(query.value.toLowerCase().trim()),
  ),
);
const shown = computed(() =>
  names.value.slice((page.value - 1) * 60, page.value * 60),
);
watch(query, () => (page.value = 1));
async function load() {
  error.value = "";
  try {
    const response = await fetch("/icons/" + set + ".json");
    if (!response.ok) throw Error("Unable to load local icons.");
    data.value = await response.json();
  } catch (e) {
    error.value = e.message;
  }
}
onMounted(load);
function svg(name) {
  const icon = data.value.icons[name];
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${icon.width || data.value.width || 24} ${icon.height || data.value.height || 24}" width="24" height="24"><metadata>${data.value.attribution.name} by ${data.value.attribution.author.name}; ${data.value.attribution.license.title}; ${data.value.attribution.license.url}</metadata>${icon.body}</svg>`;
}
async function copy() {
  try {
    await navigator.clipboard.writeText(set + ":" + selected.value);
    copied.value = true;
    notify("Icon name copied.");
  } catch {
    notify(
      "Clipboard access blocked. Select and copy the icon name below.",
      "warning",
    );
  }
}
function download() {
  const url = URL.createObjectURL(
    new Blob([svg(selected.value)], { type: "image/svg+xml" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = set + "-" + selected.value + ".svg";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
</script>
<template>
  <WorkspacePage
    :title="set === 'solar' ? 'Solar Icons' : 'Tabler Icons'"
    data-batch="3"
    ><v-card class="workspace-card"
      ><div class="b3-list-heading mt-0">
        <div>
          <h2>{{ set === "solar" ? "Solar" : "Tabler" }} icon library</h2>
          <p class="muted text-caption mt-2">
            Locally bundled SVGs · No external embed
          </p>
        </div>
        <v-text-field v-model="query" label="Filter icons" density="compact" />
      </div>
      <p v-if="data" class="text-caption mb-6">
        {{ data.attribution.author.name }} ·
        <a
          :href="data.attribution.license.url"
          target="_blank"
          rel="noopener noreferrer"
          >{{ data.attribution.license.title }}</a
        >
        · {{ names.length.toLocaleString() }} matching icons
      </p>
      <v-progress-linear
        v-if="!data && !error"
        indeterminate
        color="primary" /><v-alert v-if="error" type="error" variant="tonal"
        >{{ error }} <v-btn @click="load">Retry</v-btn></v-alert
      >
      <div class="b3-icon-grid">
        <button
          v-for="name in shown"
          :key="name"
          :aria-label="name"
          @click="
            selected = name;
            copied = false;
          "
        >
          <span v-html="svg(name)" /><small>{{ name }}</small>
        </button>
      </div>
      <p v-if="data && !shown.length" class="workspace-empty">
        No icons match your search.
      </p>
      <v-pagination
        v-if="names.length > 60"
        v-model="page"
        :length="Math.ceil(names.length / 60)"
        :total-visible="5"
        color="primary"
        class="mt-6" /></v-card
    ><v-dialog :model-value="!!selected" @update:model-value="selected = null"
      ><v-card v-if="selected" class="dialog-body"
        ><div class="b3-icon-preview" v-html="svg(selected)" />
        <h2 class="my-5">{{ selected }}</h2>
        <v-text-field
          :model-value="set + ':' + selected"
          readonly
          label="Icon name"
        />
        <p class="text-caption muted mt-4">
          {{ data.attribution.author.name }} ·
          {{ data.attribution.license.title }}. Retain required attribution when
          using this icon.
        </p>
        <div class="dialog-actions">
          <v-btn variant="text" @click="selected = null">Close</v-btn
          ><v-btn variant="tonal" color="primary" @click="copy">{{
            copied ? "Copied" : "Copy name"
          }}</v-btn
          ><v-btn color="primary" @click="download">Download SVG</v-btn>
        </div></v-card
      ></v-dialog
    ></WorkspacePage
  >
</template>
