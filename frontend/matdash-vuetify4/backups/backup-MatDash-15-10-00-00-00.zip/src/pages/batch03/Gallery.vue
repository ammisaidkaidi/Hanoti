<script setup>
import { useRoute } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import ProfileHeader from "../../components/batch03/ProfileHeader.vue";
import GalleryGrid from "../../components/batch03/GalleryGrid.vue";
const profile = useRoute().path.includes("/profile/");
</script>
<template>
  <WorkspacePage
    :title="profile ? 'Gallery' : 'Gallery Lightbox'"
    data-batch="3"
    ><ProfileHeader v-if="profile" /><GalleryGrid :searchable="profile"
  /></WorkspacePage>
</template>
