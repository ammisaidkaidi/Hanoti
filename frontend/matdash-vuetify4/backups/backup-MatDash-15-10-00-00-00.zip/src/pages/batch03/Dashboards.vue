<script setup>
import { ref } from "vue";
import { useRoute } from "vue-router";
import MiniChart from "../../components/batch03/MiniChart.vue";
import ProductRevenue from "../../components/batch03/ProductRevenue.vue";
import Activities from "../../components/batch03/Activities.vue";
import Calendar from "../apps/Calendar.vue";
import { asset, avatar } from "../../data/app-seed";
const third = useRoute().path.endsWith("dashboard3");
const selected = ref(null);
const forecast = [
  { name: "2025", data: [1.4, 2.5, 1.7, 3.1, 2.6, 2.3, 2.1, 2.4, 2.2] },
  {
    name: "2024",
    data: [-2.3, -1.4, -2.6, -1.9, -2.8, -1.6, -2.4, -1.4, -1.8],
  },
];
const stats = [
  ["Total Orders", "16,689", "package", "primary"],
  ["Return Item", "148", "back", "warning"],
  ["Annual Budget", "$156K", "creditcard", "secondary"],
  ["Cancel Orders", "64", "close", "error"],
  ["Total Income", "$36,715", "invoice", "success"],
];
</script>
<template>
  <section class="b3-dashboard" data-page-ready="true" data-batch="3">
    <h1 class="b3-sr-only">{{ third ? "Dashboard3" : "Dashboard2" }}</h1>
    <div v-if="third" class="b3-stat-strip">
      <v-card
        v-for="[title, value, icon, color] in stats"
        :key="title"
        class="b3-stat-tile"
        ><v-avatar :color="color" variant="tonal" rounded="lg"
          ><Icon :name="icon"
        /></v-avatar>
        <p>{{ title }}</p>
        <h2>{{ value }}</h2>
        <v-btn variant="text" size="small" @click="selected = { title, value }"
          >View Details</v-btn
        ></v-card
      >
    </div>
    <div v-else class="b3-dash-welcome">
      <v-card class="b3-welcome-banner" color="primary"
        ><img :src="asset('welcome-bg2-')" alt="" /><v-chip
          variant="tonal"
          size="small"
          >This month +15% Profit</v-chip
        >
        <h1>Hey, David McMichael</h1>
        <p>Aenean vel libero id metus sollicitudin</p></v-card
      ><v-card color="lighterror" class="pa-6"
        ><p>Subscriptions</p>
        <h2 class="mt-2">78,298 <small>−12%</small></h2>
        <MiniChart
          type="bar"
          spark
          :height="85"
          :colors="['#ff6692']" /></v-card
      ><v-card color="lightsecondary" class="pa-6"
        ><p>Users</p>
        <h2 class="mt-2">14,872 <small>+6.4%</small></h2>
        <MiniChart spark :height="85" :colors="['#16cdc7']"
      /></v-card>
    </div>
    <div class="b3-dash-main">
      <v-card class="workspace-card"
        ><h2>Revenue Forecast</h2>
        <p class="muted text-caption mt-1">Overview of Profit</p>
        <MiniChart
          type="bar"
          :series="forecast"
          :labels="[
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'July',
            'Aug',
            'Sep',
          ]"
          :colors="['#635bff', '#ff6692']"
          :height="300"
        />
        <div class="b3-financial-totals">
          <div
            v-for="[name, value] in [
              ['Total', '$96,640'],
              ['Profit', '$48,820'],
              ['Earnings', '$58,820'],
            ]"
            :key="name"
          >
            <span class="muted">{{ name }}</span
            ><strong>{{ value }}</strong>
          </div>
        </div></v-card
      ><v-card class="workspace-card"
        ><h2>Annual Profit</h2>
        <div class="d-flex justify-space-between mt-5">
          <span>Conversion Rate</span><strong>18.4%</strong>
        </div>
        <MiniChart spark :height="110" />
        <div
          v-for="[name, detail, value, change] in [
            ['Added to Cart', '5 clicks', '$21,120.70', '+13.2%'],
            ['Reached to Checkout', '12 clicks', '$16,100.00', '−7.4%'],
            ['Added to Cart', '24 views', '$6,400.50', '+9.3%'],
          ]"
          :key="value"
          class="b3-profit-row"
        >
          <div>
            <small class="muted">{{ name }} · {{ detail }}</small>
            <h3>{{ value }}</h3>
          </div>
          <span
            :class="change.startsWith('+') ? 'text-success' : 'text-error'"
            >{{ change }}</span
          >
        </div></v-card
      >
    </div>
    <div v-if="third" class="b3-three">
      <v-card class="workspace-card"
        ><h2>Your Performance</h2>
        <p class="muted text-caption">Last check on 25 february</p>
        <div class="b3-performance">
          <div>
            <p>64 new orders</p>
            <small>Processing</small>
            <p>4 orders</p>
            <small>On hold</small>
            <p>6 orders</p>
            <small>Delivered</small>
          </div>
          <MiniChart
            type="donut"
            :height="190"
            spark
            :series="[64, 4, 6]"
            :labels="['Processing', 'On hold', 'Delivered']"
          /></div></v-card
      ><v-card class="workspace-card"
        ><h2>
          Customers <span class="text-success text-caption">+26.5%</span>
        </h2>
        <p class="muted text-caption">Last 7 days</p>
        <MiniChart :height="155" spark />
        <div class="b3-financial-totals">
          <div><span>April 07 – April 14</span><strong>6,380</strong></div>
          <div><span>Last Week</span><strong>4,298</strong></div>
        </div></v-card
      ><v-card class="workspace-card"
        ><h2>Sales Overview</h2>
        <p class="muted text-caption">Last 7 days</p>
        <MiniChart
          type="donut"
          :height="220"
          :labels="['Profit', 'Expenses', 'Revenue']"
      /></v-card>
    </div>
    <div v-else class="b3-dash-main">
      <div class="b3-two">
        <v-card class="workspace-card"
          ><v-avatar color="secondary" variant="tonal" rounded="lg"
            ><Icon name="profile"
          /></v-avatar>
          <h3 class="my-4">New Customers</h3>
          <div class="d-flex justify-space-between mb-3">
            <span>New Goals</span><strong>83%</strong>
          </div>
          <v-progress-linear
            :model-value="83"
            color="secondary"
            rounded
            height="6" /></v-card
        ><v-card class="workspace-card"
          ><h3>Total Income</h3>
          <h2 class="mt-4">$680 <small class="text-success">+18%</small></h2>
          <MiniChart spark :height="80" :colors="['#ff6692']"
        /></v-card>
      </div>
      <v-card class="workspace-card"
        ><h2>Weekly Schedules</h2>
        <div
          v-for="(day, i) in ['Sun', 'Mon', 'Tue']"
          :key="day"
          class="b3-schedule"
        >
          <span>{{ day }}</span
          ><router-link
            to="/apps/calendar"
            :style="{
              marginLeft: i * 12 + '%',
              background: ['#635bff', '#29343d', '#ff6692'][i],
            }"
            >Meeting with Sunil</router-link
          >
        </div>
        <v-btn to="/apps/calendar" variant="text" size="small"
          >Open calendar</v-btn
        ></v-card
      >
    </div>
    <div class="b3-dash-main">
      <ProductRevenue /><v-card
        v-if="third"
        color="lightprimary"
        class="workspace-card"
        ><h2>Total settlements</h2>
        <h3>$122,580</h3>
        <MiniChart spark :height="210" />
        <div class="b3-financial-totals">
          <div><span>Total balance</span><strong>$122,580</strong></div>
          <div><span>Withdrawals</span><strong>$31,640</strong></div>
        </div></v-card
      ><v-card v-else class="workspace-card"
        ><h2>Sales from Locations</h2>
        <p class="muted text-caption">Regional distribution</p>
        <div class="b3-location-visual"><Icon name="globe" :size="125" /></div>
        <div
          v-for="[place, n, color] in [
            ['LA', 28, 'primary'],
            ['NY', 21, 'secondary'],
            ['KA', 18, 'warning'],
            ['AZ', 12, 'error'],
          ]"
          :key="place"
          class="b3-location-row"
        >
          <span>{{ place }}</span
          ><v-progress-linear
            :model-value="n * 2"
            :color="color"
            height="5"
            rounded
          /><span>{{ n }}%</span>
        </div></v-card
      >
    </div>
    <Calendar v-if="third" embedded />
    <div v-else class="b3-three">
      <v-card class="workspace-card"
        ><h2>Weekly Stats</h2>
        <p class="muted text-caption">Overview of Profit</p>
        <MiniChart type="bar" :height="210" />
        <div class="b3-financial-totals">
          <div><span>Sales</span><strong>$36,850</strong></div>
          <div><span>Expenses</span><strong>$4,720</strong></div>
        </div></v-card
      ><Activities /><v-card class="b3-story-card"
        ><img :src="asset('blog-img4-')" alt="Abstract design inspiration" />
        <div class="pa-6">
          <h3>Figma tips and tricks with Stephan</h3>
          <p class="muted my-3">
            Explore a fresh perspective on design and the details that make a
            difference.
          </p>
          <div class="b3-avatar-stack">
            <v-avatar v-for="n in [2, 3, 4, 5]" :key="n" size="30"
              ><img :src="avatar(n)" alt="Sample reader" /></v-avatar
            ><span>+12</span>
          </div>
          <v-btn
            to="/apps/blog/posts"
            variant="text"
            color="primary"
            class="mt-3"
            >Read articles</v-btn
          >
        </div></v-card
      >
    </div>
    <p class="workspace-note">
      Interactive sample analytics · No live financial services.
    </p>
    <v-dialog :model-value="!!selected" @update:model-value="selected = null"
      ><v-card v-if="selected" class="dialog-body"
        ><h2>{{ selected.title }}</h2>
        <h3 class="my-4">{{ selected.value }}</h3>
        <p>
          Illustrative dashboard metric. Explore the related local records
          below.
        </p>
        <div class="dialog-actions">
          <v-btn @click="selected = null">Close</v-btn
          ><v-btn color="primary" to="/apps/invoice">View invoices</v-btn>
        </div></v-card
      ></v-dialog
    >
  </section>
</template>
