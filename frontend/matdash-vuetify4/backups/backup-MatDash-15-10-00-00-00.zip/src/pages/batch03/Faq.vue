<script setup>
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import FaqList from "../../components/batch03/FaqList.vue";
import { faq } from "../../data/batch03";
import { avatar } from "../../data/app-seed";
</script>
<template>
  <WorkspacePage title="FAQ" data-batch="3"
    ><div class="b3-centered-heading">
      <h2>Frequently asked questions</h2>
      <p>Get to know more about ready-to-use admin dashboard templates</p>
    </div>
    <div class="b3-faq-wrap"><FaqList :items="faq" /></div>
    <v-card color="lightprimary" class="b3-question-card"
      ><div class="b3-avatar-stack">
        <v-avatar v-for="n in [2, 3, 4]" :key="n" size="40"
          ><img :src="avatar(n)" alt="Sample team member"
        /></v-avatar>
      </div>
      <h2>Still have questions</h2>
      <p>
        Can't find the answer you're looking for? Please chat to our friendly
        team.
      </p>
      <v-btn to="/apps/chats" color="primary">Chat With Us</v-btn></v-card
    ></WorkspacePage
  >
</template>
