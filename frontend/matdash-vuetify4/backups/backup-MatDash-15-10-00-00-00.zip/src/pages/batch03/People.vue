<script setup>
import { ref, computed } from "vue";
import { useRoute } from "vue-router";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import ProfileHeader from "../../components/batch03/ProfileHeader.vue";
import { followers, friends, social } from "../../data/batch03";
import { pageDemos, toggleFollow } from "../../composables/usePageDemos";
import { notify } from "../../composables/useFeedback";
const path = useRoute().path;
const isFollowers = path.endsWith("followers"),
  isSocial = path.includes("social-media");
const title = isSocial
  ? "Social Media Contacts"
  : isFollowers
    ? "Followers"
    : "Friends";
const query = ref(""),
  selected = ref(null);
const people = computed(() =>
  (isSocial ? social : isFollowers ? followers : friends).filter((p) =>
    `${p.name} ${p.place || p.job}`
      .toLowerCase()
      .includes(query.value.toLowerCase()),
  ),
);
</script>
<template>
  <WorkspacePage :title="title" data-batch="3"
    ><ProfileHeader v-if="!isSocial" />
    <div class="b3-list-heading">
      <h2>
        {{ title }}
        <v-chip color="secondary" size="small">{{ people.length }}</v-chip>
      </h2>
      <v-text-field v-model="query" :label="'Search ' + title" density="compact"
        ><template #prepend-inner><Icon name="search" :size="17" /></template
      ></v-text-field>
    </div>
    <div :class="['b3-people-grid', { 'b3-followers': isFollowers }]">
      <v-card
        v-for="p in people"
        :key="p.id"
        :class="['b3-person', { compact: isFollowers }]"
        ><div class="b3-person-main">
          <button
            :aria-label="'View ' + p.name"
            class="b3-avatar-button"
            @click="selected = p"
          >
            <v-avatar :size="isFollowers ? 48 : 82"
              ><img :src="p.avatar" :alt="p.name"
            /></v-avatar>
          </button>
          <div>
            <h3>
              <button class="text-button" @click="selected = p">
                {{ p.name }}
              </button>
            </h3>
            <p class="muted text-caption mt-1">{{ p.place || p.job }}</p>
          </div>
        </div>
        <v-btn
          v-if="isFollowers"
          :variant="pageDemos.following.includes(p.id) ? 'flat' : 'outlined'"
          color="primary"
          size="small"
          :aria-label="
            (pageDemos.following.includes(p.id) ? 'Unfollow ' : 'Follow ') +
            p.name
          "
          @click="toggleFollow(p.id)"
          >{{
            pageDemos.following.includes(p.id) ? "Followed" : "Follow"
          }}</v-btn
        >
        <div v-else class="b3-social-buttons">
          <v-btn
            v-for="[icon, label] in [
              ['user', 'Profile'],
              ['chats', 'Message'],
              ['heart', 'Connect'],
              ['email', 'Email'],
            ]"
            :key="label"
            icon
            size="30"
            variant="text"
            :color="label === 'Connect' ? 'error' : 'primary'"
            :aria-label="label + ' ' + p.name"
            @click="selected = p"
            ><Icon :name="icon" :size="16"
          /></v-btn></div
      ></v-card>
    </div>
    <v-card v-if="!people.length" class="workspace-empty"
      >No matching people.</v-card
    ><v-dialog :model-value="!!selected" @update:model-value="selected = null"
      ><v-card v-if="selected" class="dialog-body"
        ><div class="person-cell">
          <v-avatar size="70"
            ><img :src="selected.avatar" :alt="selected.name"
          /></v-avatar>
          <div>
            <h2>{{ selected.name }}</h2>
            <p class="muted">{{ selected.place || selected.job }}</p>
          </div>
        </div>
        <p class="my-5">
          Sample community profile. Connections and messages in this recreation
          are local demonstrations.
        </p>
        <div class="dialog-actions">
          <v-btn variant="text" @click="selected = null">Close</v-btn
          ><v-btn
            color="primary"
            @click="
              notify(
                'Demo connection request noted locally. No notification was sent.',
              );
              selected = null;
            "
            >Connect</v-btn
          ><v-btn to="/apps/chats" variant="tonal" color="primary"
            >Open demo chats</v-btn
          >
        </div></v-card
      ></v-dialog
    ></WorkspacePage
  >
</template>
