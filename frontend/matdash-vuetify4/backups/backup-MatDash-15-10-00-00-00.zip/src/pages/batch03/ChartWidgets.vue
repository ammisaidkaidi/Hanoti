<script setup>
import { ref, computed } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import MiniChart from "../../components/batch03/MiniChart.vue";
const trade = ref("Buy"),
  month = ref("March 2023");
const income = computed(() => [
  {
    name: trade.value === "Buy" ? "Buy sample" : "Sell sample",
    data:
      trade.value === "Buy"
        ? [40, 65, 55, 42, 61, 52, 72]
        : [60, 40, 70, 32, 55, 36, 48],
  },
]);
</script>
<template>
  <WorkspacePage title="Charts Widgets" data-batch="3"
    ><div class="b3-four">
      <v-card
        v-for="[title, value, type, color] in [
          ['Followers', '2,545', 'area', '#635bff'],
          ['Views', '15,480', 'bar', '#16cdc7'],
          ['Earned', '2,545', 'area', '#635bff'],
          ['Total Earning', '$78,298', 'bar', '#16cdc7'],
        ]"
        :key="title"
        class="workspace-card"
        ><h2>{{ value }}</h2>
        <p class="muted">
          {{ title }} <span class="text-success text-caption">+1.20%</span>
        </p>
        <MiniChart :type="type" :colors="[color]" :height="90" spark
      /></v-card>
    </div>
    <v-card class="workspace-card my-6"
      ><div class="d-flex justify-space-between">
        <h2>Current Value</h2>
        <v-btn-toggle
          v-model="trade"
          mandatory
          density="compact"
          color="primary"
          ><v-btn value="Buy">Buy</v-btn
          ><v-btn value="Sell">Sell</v-btn></v-btn-toggle
        >
      </div>
      <div class="b3-three">
        <div>
          <MiniChart type="bar" :series="income" :height="210" spark />
          <p>Income</p>
          <h2>{{ trade === "Buy" ? "$25,260" : "$21,740" }}</h2>
          <span class="text-success">+1.25%</span>
        </div>
        <div>
          <MiniChart type="bar" :height="210" :colors="['#16cdc7']" spark />
          <p>Expense</p>
          <h2>$12,260</h2>
          <span class="text-success">+4.25%</span>
        </div>
        <div>
          <MiniChart type="donut" :height="210" :series="[65, 35]" spark />
          <p>Current Year</p>
          <h2>$98,260</h2>
          <span class="text-success">+2.5%</span>
        </div>
      </div>
      <p class="text-caption muted mt-4">
        Buy/Sell changes the sample chart, not a financial order.
      </p></v-card
    >
    <div class="b3-three">
      <div class="example-stack">
        <v-card class="workspace-card"
          ><h2>Yearly Breakup</h2>
          <h3 class="mt-4">$36,358</h3>
          <MiniChart
            type="donut"
            :height="180"
            :series="[64, 36]"
            :labels="['2024', '2025']"
          />
          <p class="text-success">
            +9% <span class="muted">last year</span>
          </p></v-card
        ><v-card class="workspace-card"
          ><h2>Monthly Earnings</h2>
          <h3 class="my-4">
            $6,820 <span class="text-success text-caption">+9%</span>
          </h3>
          <MiniChart spark :height="130" /></v-card
        ><v-card class="workspace-card"
          ><h2>Most Visited</h2>
          <v-select
            v-model="month"
            :items="['March 2023', 'April 2023', 'May 2023']"
            aria-label="Visits month"
            density="compact"
            class="my-4" /><MiniChart
            type="bar"
            :series="[
              {
                name: 'San Francisco',
                data:
                  month === 'March 2023'
                    ? [40, 55, 42, 66, 51, 47]
                    : [52, 38, 68, 47, 75, 61],
              },
              { name: 'Diego', data: [28, 40, 22, 40, 26, 35] },
            ]"
            :height="230"
            :labels="['01', '02', '03', '04', '05', '06']"
        /></v-card>
      </div>
      <div class="example-stack">
        <v-card class="workspace-card"
          ><h2>Yearly Sales</h2>
          <p class="muted">Total Sales</p>
          <MiniChart type="bar" :height="320" />
          <div class="b3-financial-totals">
            <div><span>Salary</span><strong>$36,358</strong></div>
            <div><span>Expense</span><strong>$5,296</strong></div>
          </div></v-card
        ><v-card class="workspace-card"
          ><h2>Page Impressions</h2>
          <h3 class="mt-4">$456,120</h3>
          <MiniChart type="bar" spark :height="130" :colors="['#16cdc7']" />
          <p class="muted">
            Change Yesterday <span class="text-success">+9%</span>
          </p></v-card
        >
        <div class="b3-two">
          <v-card class="workspace-card"
            ><h3>Customers</h3>
            <p>36,358</p>
            <MiniChart spark :height="90" :colors="['#16cdc7']" /></v-card
          ><v-card class="workspace-card"
            ><h3>Projects</h3>
            <p>78,298</p>
            <MiniChart type="bar" spark :height="90"
          /></v-card>
        </div>
      </div>
      <div class="example-stack">
        <v-card class="workspace-card"
          ><h2>Revenue Updates</h2>
          <p class="muted">Overview of Profit</p>
          <MiniChart
            type="bar"
            :height="330"
            :series="[
              { name: 'Footwear', data: [3, 4, 2, 3, 2, 4] },
              { name: 'Fashionwear', data: [-2, -3, -1, -2, -3, -2] },
            ]"
            :labels="['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June']" /></v-card
        ><v-card class="workspace-card"
          ><h2>Sales Overview</h2>
          <p class="muted">Every month</p>
          <MiniChart
            type="donut"
            :height="300"
            :series="[60, 40]"
            :labels="['Profit', 'Expense']"
          />
          <h3 class="text-center">$500,458</h3>
          <div class="b3-financial-totals mt-5">
            <div><span>Profit</span><strong>$23,450</strong></div>
            <div><span>Expense</span><strong>$23,450</strong></div>
          </div></v-card
        >
      </div>
    </div></WorkspacePage
  >
</template>
