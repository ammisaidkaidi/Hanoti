<script setup>
import { ref, computed, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { VPagination } from "vuetify/components";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
const route = useRoute(),
  router = useRouter();
const query = ref(String(route.query.q || "Angular Js")),
  page = ref(1);
const titles = [
  "AngularJs",
  "AngularJs — Superheroic JavaScript MVW Framework",
  "AngularJS Tutorial - W3Schools",
  "Introduction to AngularJS - W3Schools",
  "AngularJS Tutorial",
  "Angular 2: One framework",
];
const records = [
  ...Array.from({ length: 24 }, (_, i) => ({
    id: i,
    title:
      titles[i % 6] +
      (i > 5
        ? " · " + ["Guide", "Examples", "Components"][Math.floor(i / 6) - 1]
        : ""),
    url: i % 2 ? "https://www.w3schools.com/angular/" : "https://angular.dev/",
    text: "Explore framework concepts, reusable components, application structure, and practical examples for your next project.",
  })),
  ...[
    "Vue 3 documentation",
    "Vue Router guide",
    "Vuetify components",
    "Vue forms and validation",
    "Vue dashboard layouts",
    "Vue state management",
  ].map((title, i) => ({
    id: 24 + i,
    title,
    url: "https://vuejs.org/guide/introduction.html",
    text: "Learn to build responsive Vue applications with components and reactive state.",
  })),
];
const normalize = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
const results = computed(() =>
  records.filter((r) => normalize(r.title).includes(normalize(query.value))),
);
const shown = computed(() =>
  results.value.slice((page.value - 1) * 6, page.value * 6),
);
watch(query, () => {
  page.value = 1;
  router.replace({ query: { q: query.value } });
});
</script>
<template>
  <WorkspacePage title="Search Results" data-batch="3"
    ><v-card class="workspace-card"
      ><v-text-field
        v-model="query"
        label="Search sample results"
        density="comfortable"
        class="mb-6"
        ><template #prepend-inner><Icon name="search" :size="20" /></template
      ></v-text-field>
      <h2>Search Result For “{{ query }}”</h2>
      <p class="muted text-caption mt-1">
        {{ results.length }} local sample results · Not a live web search
      </p>
      <article
        v-for="result in shown"
        :key="result.id"
        class="b3-search-result"
      >
        <a :href="result.url" target="_blank" rel="noopener noreferrer"
          ><h3>{{ result.title }}</h3>
          <span>{{ result.url }}</span></a
        >
        <p class="muted">{{ result.text }}</p>
      </article>
      <p v-if="!shown.length" class="workspace-empty">
        No matching results. Try Angular or Vue.
      </p>
      <v-pagination
        v-if="results.length > 6"
        v-model="page"
        :length="Math.ceil(results.length / 6)"
        :total-visible="4"
        color="primary"
        class="b3-pagination" /></v-card
  ></WorkspacePage>
</template>
