<script setup>
import { ref, computed } from "vue";
import { useRoute } from "vue-router";
import FrontLayout from "../../components/batch03/FrontLayout.vue";
import FaqList from "../../components/batch03/FaqList.vue";
import { asset, avatar } from "../../data/app-seed";
import { frontFaq } from "../../data/batch03";
const about = useRoute().path.endsWith("about-us"),
  tab = ref("Team Scheduling"),
  slide = ref(0),
  plan = ref(null);
const team = [
  ["Alex Martinez", "CEO & Co-Founder"],
  ["Jordan Nguyen", "CTO & Co-Founder"],
  ["Taylor Roberts", "Product Manager"],
  ["Morgan Patel", "Lead Developer"],
];
const testimonials = ["Jenny Wilson", "Josh Cui", "Eminson Mendoza"];
const feature = computed(
  () =>
    ({
      "Team Scheduling": [
        "Defend your focus",
        "Combine teammate schedules",
        "Factor in availability for required attendees, and skip checking for conflicts for optional attendees.",
      ],
      Payments: [
        "Make every detail count",
        "Keep payments organized",
        "Bring clear records and intuitive workflows together. Payment controls in this recreation are demonstrations only.",
      ],
      Embedding: [
        "Build into your workflow",
        "Keep your tools together",
        "Reuse components and compose responsive screens for the way your team works.",
      ],
      Workflows: [
        "Create space for good work",
        "Turn plans into progress",
        "Organize the steps that matter and keep your team aligned with one clear view.",
      ],
    })[tab.value],
);
const pricing = [
  ["Single Use", 49, "One Project"],
  ["Multiple Use", 89, "Unlimited Project"],
  ["Extended Use", 299, "One Project"],
  ["Unlimited Use", 499, "Unlimited Project"],
];
</script>
<template>
  <FrontLayout
    ><section :class="['b3-marketing-hero', { about }]">
      <div class="front-container b3-hero-grid">
        <div>
          <p class="b3-eyebrow">DESIGNED FOR YOUR NEXT BIG IDEA</p>
          <h1>
            {{
              about
                ? "Get to know MatDash Dashboard Template"
                : "A feature-packed dashboard built for developers’ needs."
            }}
          </h1>
          <template v-if="!about"
            ><div class="b3-hero-social">
              <div class="b3-avatar-stack">
                <v-avatar v-for="n in [3, 2, 1]" :key="n" size="42"
                  ><img :src="avatar(n)" alt="Sample developer"
                /></v-avatar>
              </div>
              <p>
                <strong>52,589+</strong><br />developers & agencies using our
                templates
              </p>
            </div>
            <v-btn to="/auth/login" color="primary" size="large">Log In</v-btn>
            <p class="text-caption muted mt-4">
              Illustrative reference figures, not metrics for this recreation.
            </p></template
          >
          <div v-else class="button-samples mt-6">
            <v-btn to="/auth/register" color="primary">Create An Account</v-btn
            ><v-btn to="/front-page/contact-us" variant="outlined"
              >View Open Positions</v-btn
            >
          </div>
        </div>
        <p v-if="about" class="b3-about-intro">
          Do you need a highly customizable and developer friendly premium Vue
          admin template packed with numerous features? MatDash brings flexible
          layouts and reusable components together, with a thoughtful foundation
          for your next application.
        </p>
        <img
          v-else
          :src="asset('main-banner-')"
          alt="MatDash dashboard previews"
          class="b3-hero-image"
        />
      </div>
    </section>
    <section class="b3-marketing-section front-container">
      <div v-if="!about" class="b3-feature-intro">
        <div>
          <h2>Over 45,000 clients<br />and counting.</h2>
          <p class="muted my-5">
            Build with reusable components and thoughtful details. Focus on the
            experience you want to create.
          </p>
          <v-btn to="/front-page/contact-us" color="primary" variant="outlined"
            >Request a Callback</v-btn
          >
        </div>
        <div class="b3-two">
          <article
            v-for="[icon, title] in [
              ['user', 'Expert Advisor'],
              ['chats', 'Effective Support'],
              ['creditcard', 'Low Fees'],
              ['invoice', 'Loan Facility'],
            ]"
            :key="title"
            class="b3-feature-tile"
          >
            <v-avatar color="primary" variant="tonal" rounded="lg"
              ><Icon :name="icon"
            /></v-avatar>
            <h3>{{ title }}</h3>
            <p class="muted">
              Clear guidance and thoughtful tools for your next project.
            </p>
          </article>
        </div>
      </div>
      <template v-else
        ><h2 class="text-center mb-8">The hassle-free setup process</h2>
        <div class="b3-four">
          <v-card
            v-for="([icon, title], i) in [
              ['chats', 'Effective Support'],
              ['user', 'Expert Advisor'],
              ['creditcard', 'Low Fees'],
              ['invoice', 'Loan Facility'],
            ]"
            :key="title"
            :color="
              ['lightprimary', 'lighterror', 'lightsecondary', 'canvas'][i]
            "
            class="pa-6"
            ><Icon :name="icon" :size="28" />
            <h3 class="my-4">{{ title }}</h3>
            <p>
              Thoughtful components to help you build with confidence.
            </p></v-card
          >
        </div></template
      >
    </section>
    <section v-if="!about" class="b3-feature-section">
      <div class="front-container">
        <v-tabs v-model="tab" color="primary" align-tabs="center"
          ><v-tab
            v-for="name in [
              'Team Scheduling',
              'Payments',
              'Embedding',
              'Workflows',
            ]"
            :key="name"
            :value="name"
            >{{ name }}</v-tab
          ></v-tabs
        >
        <div class="b3-feature-detail">
          <img
            :src="asset('feature-image-')"
            alt="Scheduling and workflow preview"
          />
          <div>
            <p class="b3-eyebrow">{{ tab }}</p>
            <h2>{{ feature[0] }}</h2>
            <h3 class="mt-6">{{ feature[1] }}</h3>
            <p class="muted my-4">{{ feature[2] }}</p>
            <p class="my-4">✓ Factor in outside colleagues</p>
            <p class="my-4">✓ Round robin pooling</p>
            <v-btn color="primary" to="/front-page/about-us">Learn More</v-btn>
          </div>
        </div>
      </div>
    </section>
    <section v-else class="front-container b3-marketing-section">
      <h2 class="mb-8">A unique story in every number</h2>
      <div class="b3-three">
        <div
          v-for="[n, caption] in [
            ['2019', 'When we founded Modernize'],
            ['300k+', 'Customers on Modernize'],
            ['25k+', 'Dashboards built using MatDash'],
          ]"
          :key="n"
        >
          <strong class="b3-big-number">{{ n }}</strong>
          <p class="muted">{{ caption }}</p>
        </div>
      </div>
      <p class="text-caption muted mt-6">
        Statistics shown as reference-template sample content.
      </p>
    </section>
    <section class="b3-team-section">
      <div class="front-container">
        <div class="b3-section-heading">
          <h2>Meet our team</h2>
          <p>
            Our robust analytics offer rich insights into the<br />information
            buyers want, informing where teams.
          </p>
        </div>
        <div class="b3-four">
          <article v-for="([name, job], i) in team" :key="name">
            <img :src="asset('leader' + (i + 1) + '-')" :alt="name" />
            <h3>{{ name }}</h3>
            <p>{{ job }}</p>
          </article>
        </div>
      </div>
    </section>
    <div v-if="!about" class="b3-contact-band">
      <p>Save valuable time and effort spent searching for a solution.</p>
      <v-btn to="/front-page/contact-us" variant="outlined"
        >Contact us now</v-btn
      >
    </div>
    <section class="front-container b3-marketing-section">
      <div class="b3-testimonials">
        <div>
          <h2>Words from customers.</h2>
          <p class="muted mt-4">Pellentesque varius semper odio non pretium.</p>
          <div class="button-samples mt-6">
            <v-btn
              icon
              variant="tonal"
              aria-label="Previous testimonial"
              @click="slide = (slide + 2) % 3"
              ><Icon name="back" /></v-btn
            ><v-btn
              icon
              variant="tonal"
              aria-label="Next testimonial"
              @click="slide = (slide + 1) % 3"
              ><Icon name="right"
            /></v-btn>
          </div>
        </div>
        <div aria-live="polite">
          <v-rating :model-value="5" readonly color="warning" size="22" />
          <blockquote>
            This template is great, UI-rich and up-to-date. Although it is
            pretty much complete, I suggest to improve a bit of documentation.
            Thanks &amp; Highly recommended!
          </blockquote>
          <div class="person-cell mt-5">
            <v-avatar size="48"
              ><img :src="avatar(slide + 1)" :alt="testimonials[slide]"
            /></v-avatar>
            <div>
              <h3>{{ testimonials[slide] }}</h3>
              <p class="muted">CEO &amp; Head of Comp Inc.</p>
            </div>
          </div>
          <p class="text-caption muted mt-4">
            Sample testimonial reproduced from the reference ·
            {{ slide + 1 }} of 3
          </p>
        </div>
      </div>
      <div class="b3-feature-chips">
        <v-chip
          v-for="(name, i) in [
            '6 Theme Colors',
            'Authguard',
            '65+ Page Templates',
            '45+ UI Components',
            'Vuetify',
            '3400+ Font Icons',
            'Axios',
            'i18n Vue',
            'Vue3 Carousel',
            'Easy to Customize',
            'Lots of Chart Options',
            'Lots of Table Examples',
            'Regular Updates',
            'Detailed Documentation',
            'Calendar Design',
            'Dedicated Support',
          ]"
          :key="name"
          :color="
            ['primary', 'secondary', 'error', 'success', 'warning'][i % 5]
          "
          variant="tonal"
          >{{ name }}</v-chip
        >
      </div>
      <p class="text-caption text-center muted">
        Reference feature labels; see the Route Directory for this recreation’s
        actual implementation status.
      </p>
    </section>
    <section class="front-container b3-marketing-section b3-license-section">
      <div class="b3-centered-heading">
        <h2>Fair pricing for everyone.</h2>
        <p>
          Choose the layout that fits your project. These are illustrative
          template license cards.
        </p>
      </div>
      <div class="b3-four">
        <v-card
          v-for="[name, price, projects] in pricing"
          :key="name"
          class="b3-license-card"
          variant="outlined"
          ><h3>
            {{ name }}
            <v-chip v-if="price === 299" color="primary" size="x-small"
              >Popular</v-chip
            >
          </h3>
          <p class="muted my-4">
            {{
              projects === "One Project"
                ? "Use for a single end product."
                : "Use for multiple end products."
            }}
          </p>
          <h2>${{ price }}</h2>
          <small class="muted">/one time pay</small>
          <ul>
            <li
              v-for="text in [
                'Full source code',
                'Documentation',
                'Use in SaaS app',
                projects,
                'One Year Technical Support',
              ]"
              :key="text"
            >
              <Icon name="check" :size="15" />{{ text }}
            </li>
          </ul>
          <v-btn color="primary" block @click="plan = name"
            >Purchase Now</v-btn
          ></v-card
        >
      </div>
      <p class="text-center text-caption muted mt-6">
        Demo pricing only. No purchases, vendor licenses, or support contracts
        are sold here.
      </p>
    </section>
    <section class="front-container b3-marketing-section">
      <h2 class="text-center mb-8">Frequently asked questions</h2>
      <div class="b3-front-faq"><FaqList :items="frontFaq" /></div>
      <p class="text-center mt-7">
        Still have a question?
        <router-link to="/front-page/contact-us">Contact us</router-link> or
        <router-link to="/apps/tickets">open demo tickets</router-link>.
      </p>
    </section>
    <v-dialog :model-value="!!plan" @update:model-value="plan = null"
      ><v-card v-if="plan" class="dialog-body"
        ><h2>{{ plan }} — demo preview</h2>
        <p class="my-5">
          No purchase will be made. This recreation does not sell commercial
          template licenses. Review the original vendor’s current pricing and
          rights before any purchase.
        </p>
        <v-btn color="primary" @click="plan = null">Got it</v-btn></v-card
      ></v-dialog
    ></FrontLayout
  >
</template>
