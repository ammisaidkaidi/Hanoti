<script setup>
import { ref } from "vue";
import { VTreeview } from "vuetify/components";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const active = ref([]);
let id = 0;
function node(title, children) {
  return { id: ++id, title, ...(children ? { children } : {}) };
}
const items = [
  node("Applications :", [
    node("Calendar : app"),
    node("Chrome : app"),
    node("Webstorm : app"),
  ]),
  node("Documents :", [
    node("vuetify :", [
      node("src :", [node("index : ts"), node("bootstrap : ts")]),
    ]),
    node("material2 :", [
      node("src :", [
        node("v-btn : ts"),
        node("v-card : ts"),
        node("v-window : ts"),
      ]),
    ]),
  ]),
  node("Downloads :", [
    node("October : pdf"),
    node("November : pdf"),
    node("Tutorial : html"),
  ]),
  node("Videos :", [
    node("Tutorials :", [
      node("Basic layouts : mp4"),
      node("Advanced techniques : mp4"),
      node("All about app : dir"),
    ]),
    node("Intro : mov"),
    node("Conference introduction : avi"),
  ]),
];
function find(nodes, key) {
  for (const n of nodes) {
    if (n.id === key) return n.title;
    const child = n.children && find(n.children, key);
    if (child) return child;
  }
}
</script>
<template>
  <FormPage title="Treeview" data-batch="3"
    ><div class="example-grid">
      <ExampleCard title="Basic"
        ><v-treeview
          :items="items"
          item-value="id"
          density="compact" /></ExampleCard
      ><ExampleCard title="Activatable"
        ><v-treeview
          v-model:activated="active"
          :items="items"
          item-value="id"
          activatable
          color="primary"
          density="compact"
        />
        <p v-if="active.length" class="text-primary text-caption mt-3">
          Selected: {{ find(items, active[0]) }}
        </p></ExampleCard
      ><ExampleCard title="Color"
        ><v-treeview
          :items="items"
          item-value="id"
          activatable
          color="secondary"
          base-color="secondary"
          density="compact" /></ExampleCard
      ><ExampleCard title="Density"
        ><v-treeview
          :items="items"
          item-value="id"
          density="comfortable" /></ExampleCard
      ><ExampleCard title="Open all" wide
        ><v-treeview :items="items" item-value="id" open-all density="compact"
      /></ExampleCard></div
  ></FormPage>
</template>
