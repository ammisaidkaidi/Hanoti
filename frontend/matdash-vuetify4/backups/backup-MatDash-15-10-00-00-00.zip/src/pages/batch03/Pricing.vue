<script setup>
import { ref } from "vue";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import { asset } from "../../data/app-seed";
import { pageDemos } from "../../composables/usePageDemos";
import { confirmDemo, notify } from "../../composables/useFeedback";
const yearly = ref(pageDemos.billing === "Yearly");
const plans = [
  { name: "Silver", price: 0, members: 3, storage: 50, features: 2 },
  { name: "Bronze", price: 10.99, members: 5, storage: 80, features: 3 },
  { name: "Gold", price: 22.99, members: 15, storage: 150, features: 5 },
];
async function choose(p) {
  if (
    await confirmDemo(
      "Choose " + p.name + "?",
      "This saves a demo plan preference in this browser. No subscription is created and no payment is collected.",
    )
  ) {
    pageDemos.plan = p.name;
    pageDemos.billing = yearly.value ? "Yearly" : "Monthly";
    notify(p.name + " demo plan selected. No charge was made.", "success");
  }
}
</script>
<template>
  <WorkspacePage title="Pricing" data-batch="3"
    ><div class="b3-centered-heading">
      <h2>
        Flexible Plans Tailored to Fit Your<br />Community's Unique Needs!
      </h2>
      <div class="b3-billing">
        <span>Monthly</span
        ><v-switch
          v-model="yearly"
          aria-label="Yearly billing"
          color="primary"
          hide-details
          inset
        /><span>Yearly</span>
      </div>
      <p v-if="yearly" class="text-primary">
        Annual sample pricing includes two months free.
      </p>
    </div>
    <div class="b3-pricing-grid">
      <v-card v-for="p in plans" :key="p.name" class="b3-price-card"
        ><div class="d-flex justify-space-between">
          <strong>{{ p.name.toUpperCase() }}</strong
          ><v-chip v-if="p.name === 'Bronze'" color="warning" size="small"
            >POPULAR</v-chip
          >
        </div>
        <img
          :src="asset(p.name.toLowerCase() + '-')"
          :alt="p.name + ' medal'"
        />
        <h2>
          {{
            p.price
              ? "$" + (yearly ? p.price * 10 : p.price).toFixed(2)
              : "Free"
          }}<small v-if="p.price">/{{ yearly ? "yr" : "mo" }}</small>
        </h2>
        <ul>
          <li
            v-for="(label, i) in [
              p.members + ' Members',
              p.name === 'Silver' ? 'Single Device' : 'Multiple Device',
              p.storage + 'GB Storage',
              'Monthly Backups',
              'Permissions & workflows',
            ]"
            :key="label"
            :class="{ muted: i >= p.features }"
          >
            <Icon
              :name="i < p.features ? 'check' : 'close'"
              :size="17"
              :class="i < p.features ? 'text-primary' : ''"
            />{{ label }}
          </li>
        </ul>
        <v-btn color="primary" block @click="choose(p)"
          >Choose {{ p.name }}</v-btn
        >
        <p
          v-if="pageDemos.plan === p.name"
          class="text-caption text-primary mt-3"
        >
          Current local preference · {{ pageDemos.billing }}
        </p></v-card
      >
    </div></WorkspacePage
  >
</template>
