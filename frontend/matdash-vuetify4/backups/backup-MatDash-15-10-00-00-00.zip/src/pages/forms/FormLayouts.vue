<script setup>
import { ref } from "vue";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import DemoForm from "../../components/forms/DemoForm.vue";
import { countries } from "../../data/form-fields";
const success = ref("Success value"),
  error = ref(""),
  errorText = ref("");
const ordinary = [
  {
    key: "email",
    label: "Email",
    type: "email",
    placeholder: "Enter email",
    required: true,
    hint: "We'll never share your email with anyone else.",
  },
  {
    key: "password",
    label: "Password",
    type: "password",
    placeholder: "Enter password",
    required: true,
  },
];
const defaultFields = [
  { key: "text", label: "Default Text", required: true },
  { key: "email", label: "Email", type: "email", required: true },
  { key: "password", label: "Password", type: "password", required: true },
  {
    key: "readonly",
    label: "Read Only",
    value: "This field is read only",
    readonly: true,
  },
  {
    key: "choice",
    label: "Select",
    items: ["One", "Two", "Three"],
    required: true,
  },
];
const header = [
  { section: "Person Info" },
  { key: "firstname", label: "First Name", required: true },
  { key: "lastname", label: "Last Name", required: true },
  {
    key: "gender",
    label: "Select Gender",
    items: ["Female", "Male", "Other", "Prefer not to say"],
  },
  { key: "birth", label: "Date of Birth", type: "date" },
  {
    key: "membership",
    label: "Membership",
    kind: "radio",
    options: ["Free", "Paid"],
    value: "Free",
    wide: true,
  },
  { section: "Address" },
  { key: "street", label: "Street", required: true, wide: true },
  { key: "city", label: "City", required: true },
  { key: "postcode", label: "Post Code", required: true },
  { key: "state", label: "State", required: true },
  { key: "country", label: "Country", items: countries, required: true },
];
const iconFields = [
  { key: "username", label: "Username", icon: "user", required: true },
  {
    key: "email",
    label: "Email",
    type: "email",
    icon: "email",
    required: true,
  },
  {
    key: "password",
    label: "Password",
    type: "password",
    icon: "lock",
    required: true,
  },
  {
    key: "confirm",
    label: "Confirm Password",
    type: "password",
    icon: "lock",
    confirm: true,
    required: true,
  },
];
</script>
<template>
  <FormPage title="Form Layouts" bare
    ><div class="example-stack">
      <ExampleCard title="Ordinary Form" class="standalone-example"
        ><DemoForm
          :fields="ordinary"
          remember
          form-name="Ordinary form" /></ExampleCard
      ><ExampleCard title="Input Variants" class="standalone-example"
        ><div class="control-stack">
          <v-text-field
            v-model="success"
            label="Success Input"
            color="success"
            base-color="success"
            hide-details
          /><v-text-field
            v-model="error"
            label="Error Input"
            error
            hide-details
          /><v-text-field
            v-model="errorText"
            label="Input with Error text"
            error-messages="Incorrect entry."
            hide-details="auto"
          /></div></ExampleCard
      ><ExampleCard title="Default Form" class="standalone-example"
        ><DemoForm
          :fields="defaultFields"
          remember
          form-name="Default form" /></ExampleCard
      ><ExampleCard title="Basic Header Form" class="standalone-example"
        ><DemoForm
          :fields="header"
          :columns="2"
          cancel
          form-name="Basic header form" /></ExampleCard
      ><ExampleCard title="Disabled Form" class="standalone-example"
        ><DemoForm
          :fields="[{ key: 'name', label: 'Name' }, ...ordinary]"
          disabled
          form-name="Disabled form"
      /></ExampleCard>
      <div class="example-grid">
        <ExampleCard title="Form with Left Icon" class="standalone-example"
          ><DemoForm
            :fields="iconFields"
            icons
            remember
            cancel
            form-name="Left icon form" /></ExampleCard
        ><ExampleCard title="Form with Right Icon" class="standalone-example"
          ><DemoForm
            :fields="iconFields"
            icons
            right-icons
            remember
            cancel
            form-name="Right icon form"
        /></ExampleCard>
      </div></div
  ></FormPage>
</template>
