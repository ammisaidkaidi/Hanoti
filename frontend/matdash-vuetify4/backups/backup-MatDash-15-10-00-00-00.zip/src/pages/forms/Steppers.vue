<script setup>
import { reactive, ref } from "vue";
import {
  VStepper,
  VStepperHeader,
  VStepperItem,
  VStepperWindow,
  VStepperWindowItem,
} from "vuetify/components";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { notify } from "../../composables/useFeedback";
const steps = [
  "Select campaign settings",
  "Create an ad group",
  "Create an ad",
];
const values = reactive({
  locked: 2,
  editable: 3,
  alternate: 1,
  optional: 1,
  error: 1,
  linear: [1, 2, 3],
});
const active = ref(1),
  completed = ref(false);
const titles = ["Step One", "Step Two", "Step Three"];
function next() {
  if (active.value < 3) active.value++;
  else {
    completed.value = true;
    notify("All three demo steps completed.");
  }
}
</script>
<template>
  <FormPage title="Stepper"
    ><div class="example-stack">
      <ExampleCard title="Non editable steps"
        ><v-stepper
          v-model="values.locked"
          hide-actions
          flat
          class="demo-stepper"
          ><v-stepper-header
            ><template v-for="(title, i) in steps" :key="title"
              ><v-stepper-item
                :title="title"
                :value="i + 1"
                :complete="values.locked > i + 1"
                color="primary" /><v-divider
                v-if="
                  i < 2
                " /></template></v-stepper-header></v-stepper></ExampleCard
      ><ExampleCard title="Editable steps"
        ><v-stepper
          v-model="values.editable"
          hide-actions
          flat
          non-linear
          class="demo-stepper"
          ><v-stepper-header
            ><template v-for="(title, i) in steps" :key="title"
              ><v-stepper-item
                :title="title"
                :value="i + 1"
                :complete="values.editable > i + 1"
                editable
                color="primary" /><v-divider
                v-if="
                  i < 2
                " /></template></v-stepper-header></v-stepper></ExampleCard
      ><ExampleCard title="Alternate label"
        ><v-stepper
          v-model="values.alternate"
          alt-labels
          hide-actions
          flat
          non-linear
          class="demo-stepper"
          ><v-stepper-header
            ><template
              v-for="(title, i) in [
                'Ad unit details',
                'Ad sizes',
                'Ad templates',
              ]"
              :key="title"
              ><v-stepper-item
                :title="title"
                :value="i + 1"
                editable
                color="primary" /><v-divider
                v-if="
                  i < 2
                " /></template></v-stepper-header></v-stepper></ExampleCard
      ><ExampleCard title="Linear steppers"
        ><div class="control-stack">
          <v-stepper
            v-for="(_, index) in values.linear"
            :key="index"
            v-model="values.linear[index]"
            hide-actions
            flat
            class="demo-stepper"
            ><v-stepper-header
              ><template v-for="(title, i) in steps" :key="title"
                ><v-stepper-item
                  :title="title"
                  :value="i + 1"
                  :complete="values.linear[index] > i + 1"
                  color="primary" /><v-divider
                  v-if="i < 2" /></template></v-stepper-header
          ></v-stepper></div></ExampleCard
      ><ExampleCard title="Optional steps"
        ><v-stepper
          v-model="values.optional"
          hide-actions
          flat
          non-linear
          class="demo-stepper"
          ><v-stepper-header
            ><template v-for="(title, i) in steps" :key="title"
              ><v-stepper-item
                :title="title"
                :subtitle="i === 1 ? 'Optional' : undefined"
                :value="i + 1"
                editable
                color="primary" /><v-divider
                v-if="
                  i < 2
                " /></template></v-stepper-header></v-stepper></ExampleCard
      ><ExampleCard title="Alternative label with errors"
        ><v-stepper
          v-model="values.error"
          alt-labels
          hide-actions
          flat
          non-linear
          class="demo-stepper"
          ><v-stepper-header
            ><template
              v-for="(title, i) in [
                'Ad type',
                'Ad style',
                'Custom channels',
                'Get code',
              ]"
              :key="title"
              ><v-stepper-item
                :title="title"
                :value="i + 1"
                :error="i === 2"
                :subtitle="i === 2 ? 'Alert message' : undefined"
                editable
                color="primary" /><v-divider
                v-if="
                  i < 3
                " /></template></v-stepper-header></v-stepper></ExampleCard
      ><ExampleCard title="Items steps"
        ><v-stepper
          v-model="active"
          hide-actions
          flat
          class="demo-stepper interactive-stepper"
          ><v-stepper-header
            ><template v-for="n in 3" :key="n"
              ><v-stepper-item
                :title="'Step ' + n"
                :value="n"
                :complete="active > n || completed"
                color="primary" /><v-divider
                v-if="n < 3" /></template></v-stepper-header
          ><v-stepper-window
            ><v-stepper-window-item v-for="n in 3" :key="n" :value="n"
              ><h2>{{ titles[n - 1] }}</h2>
              <p class="muted mt-4">
                {{
                  [
                    "Start with the details that define your project. A stepper keeps each stage focused and easy to follow.",
                    "Review the options and organize your work into clear, manageable steps.",
                    "Everything is ready. Finish this demonstration or go back to review an earlier step.",
                  ][n - 1]
                }}
              </p></v-stepper-window-item
            ></v-stepper-window
          ></v-stepper
        ><v-alert
          v-if="completed"
          type="success"
          variant="tonal"
          density="compact"
          class="mt-4"
          >Demo completed. No data was submitted.</v-alert
        >
        <div class="stepper-buttons">
          <v-btn
            :disabled="active === 1"
            variant="text"
            @click="
              active--;
              completed = false;
            "
            >Previous</v-btn
          ><v-btn
            v-if="completed"
            color="primary"
            @click="
              active = 1;
              completed = false;
            "
            >Start again</v-btn
          ><v-btn v-else color="primary" @click="next">{{
            active === 3 ? "Finish" : "Next"
          }}</v-btn>
        </div></ExampleCard
      >
    </div></FormPage
  >
</template>
