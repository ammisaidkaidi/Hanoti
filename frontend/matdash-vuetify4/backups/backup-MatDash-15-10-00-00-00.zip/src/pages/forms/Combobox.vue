<script setup>
import { reactive } from "vue";
import { VCombobox } from "vuetify/components";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const activities = ["Programming", "Design", "Vue", "Vuetify"];
const initial = () => ({
  density: ["foo", "foo", "foo"],
  multiple: ["Vuetify", "Programming"],
  chips: ["Vuetify", "Programming"],
  custom: ["Vuetify", "Programming"],
  readonly: ["Vuetify", "Programming"],
});
const model = reactive(initial());
</script>
<template>
  <FormPage title="Combobox"
    ><div class="example-stack">
      <ExampleCard title="Density"
        ><div class="control-stack">
          <v-combobox
            v-for="(density, i) in ['default', 'comfortable', 'compact']"
            :key="density"
            v-model="model.density[i]"
            :items="['foo', 'bar', 'fizz', 'buzz']"
            :label="density[0].toUpperCase() + density.slice(1)"
            :density="density"
            variant="filled"
            hide-details
            color="primary"
          /></div></ExampleCard
      ><ExampleCard title="Multiple"
        ><div class="control-stack">
          <v-combobox
            v-model="model.multiple"
            :items="activities"
            label="Select a favorite activity or create a new one"
            multiple
            variant="filled"
            hide-details
            color="primary"
            :return-object="false"
          /><v-combobox
            v-model="model.chips"
            :items="activities"
            label="I use chips"
            multiple
            chips
            closable-chips
            variant="filled"
            hide-details
            color="primary"
            :return-object="false"
          /><v-combobox
            v-model="model.custom"
            :items="activities"
            label="I use a scoped slot"
            multiple
            chips
            closable-chips
            variant="filled"
            hide-details
            color="primary"
            :return-object="false"
            ><template #chip="{ props, item }"
              ><v-chip v-bind="props" size="small"
                ><v-avatar color="primary" start size="20">{{
                  String(item.title).charAt(0)
                }}</v-avatar
                >{{ item.title }}</v-chip
              ></template
            ></v-combobox
          ><v-combobox
            v-model="model.readonly"
            :items="activities"
            label="I'm readonly"
            multiple
            chips
            readonly
            variant="filled"
            hide-details
          /></div
      ></ExampleCard>
    </div>
    <div class="example-footer">
      <span>Type a new activity and press Enter to add it.</span
      ><v-btn
        variant="text"
        color="primary"
        @click="Object.assign(model, initial())"
        >Reset examples</v-btn
      >
    </div></FormPage
  >
</template>
