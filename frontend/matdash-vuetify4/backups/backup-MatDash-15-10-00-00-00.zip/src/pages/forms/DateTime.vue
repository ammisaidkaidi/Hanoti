<script setup>
import { ref } from "vue";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const date = ref(""),
  time = ref("");
</script>
<template>
  <FormPage title="Date Picker" heading="Date Time"
    ><div class="example-grid">
      <ExampleCard title="Date Picker"
        ><v-text-field
          v-model="date"
          type="date"
          aria-label="Date Picker"
          variant="outlined"
          hide-details
          density="comfortable" /></ExampleCard
      ><ExampleCard title="Time Picker"
        ><v-text-field
          v-model="time"
          type="time"
          aria-label="Time Picker"
          variant="outlined"
          hide-details
          density="comfortable"
      /></ExampleCard>
    </div>
    <div v-if="date || time" class="example-footer" aria-live="polite">
      <span>Selected: {{ date || "No date" }} · {{ time || "No time" }}</span
      ><v-btn
        variant="text"
        color="primary"
        @click="
          date = '';
          time = '';
        "
        >Clear selection</v-btn
      >
    </div></FormPage
  >
</template>
