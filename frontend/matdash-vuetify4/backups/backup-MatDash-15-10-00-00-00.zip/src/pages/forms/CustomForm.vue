<script setup>
import { reactive, ref } from "vue";
import { VSlider, VRangeSlider } from "vuetify/components";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { required } from "../../composables/useFeedback";
const model = reactive({
  name: "",
  company: "",
  industry: "",
  select: "One",
  time: "",
  date: "",
  gender: "Male",
  check: [true, false],
  range: [750, 950],
  volume: 60,
  switches: [true, false],
});
const open = ref(false),
  newName = ref(""),
  entries = ref([]),
  form = ref(null);
async function add() {
  if ((await form.value.validate()).valid) {
    entries.value.push(newName.value.trim());
    newName.value = "";
    open.value = false;
  }
}
</script>
<template>
  <FormPage title="Form Layouts" heading="Custom Form"
    ><div class="custom-field-grid">
      <div class="control-stack">
        <div class="demo-field">
          <label for="custom-name">Name</label
          ><v-text-field
            id="custom-name"
            v-model="model.name"
            placeholder="Enter Text"
            density="comfortable"
          />
        </div>
        <div class="demo-field">
          <label for="custom-company">Company Name</label
          ><v-text-field
            id="custom-company"
            v-model="model.company"
            placeholder="Enter Text"
            density="comfortable"
          />
        </div>
        <div class="demo-field">
          <label for="custom-industry">Industry Type</label
          ><v-text-field
            id="custom-industry"
            v-model="model.industry"
            placeholder="Enter Text"
            density="comfortable"
          />
        </div>
      </div>
      <div class="control-stack">
        <div class="demo-field">
          <label for="custom-select">Select Dropdown</label
          ><v-select
            id="custom-select"
            v-model="model.select"
            :items="['One', 'Two', 'Three']"
            density="comfortable"
          />
        </div>
        <div class="demo-field">
          <label for="custom-time">Time</label
          ><v-text-field
            id="custom-time"
            v-model="model.time"
            type="time"
            density="comfortable"
          />
        </div>
        <div class="demo-field">
          <label for="custom-date">Date</label
          ><v-text-field
            id="custom-date"
            v-model="model.date"
            type="date"
            density="comfortable"
          />
        </div>
      </div>
      <div class="control-stack">
        <ExampleCard title="Lorem ipsum dolor sit amet"
          ><v-radio-group v-model="model.gender" hide-details
            ><v-radio label="Male" value="Male" color="primary" /><v-radio
              label="Female"
              value="Female"
              color="primary" /><v-radio
              label="Disabled"
              disabled /></v-radio-group
        ></ExampleCard>
        <div>
          <h4>Industry Type</h4>
          <v-checkbox
            v-for="(_, i) in model.check"
            :key="i"
            v-model="model.check[i]"
            label="Enter text"
            :aria-label="'Industry checkbox ' + (i + 1)"
            color="primary"
            hide-details
          /><v-checkbox label="Disabled" disabled hide-details />
        </div>
      </div>
    </div>
    <div class="custom-field-grid mt-8">
      <div>
        <h4 class="mb-6">Slider</h4>
        <v-range-slider
          v-model="model.range"
          :min="0"
          :max="1500"
          :step="10"
          color="primary"
          aria-label="Custom price range"
          hide-details
        />
        <div class="range-fields">
          <v-text-field
            v-model.number="model.range[0]"
            type="number"
            :min="0"
            :max="model.range[1]"
            aria-label="Minimum price"
            density="compact"
          /><v-text-field
            v-model.number="model.range[1]"
            type="number"
            :min="model.range[0]"
            :max="1500"
            aria-label="Maximum price"
            density="compact"
          />
        </div>
      </div>
      <div>
        <h4 class="mb-6">Volume</h4>
        <v-slider
          v-model="model.volume"
          aria-label="Volume"
          color="secondary"
          hide-details
          ><template #prepend><Icon name="sliders" :size="18" /></template
        ></v-slider>
      </div>
      <div>
        <h4>Switch</h4>
        <v-switch
          v-for="(_, i) in model.switches"
          :key="i"
          v-model="model.switches[i]"
          label="Enter text"
          :aria-label="'Custom switch ' + (i + 1)"
          color="primary"
          hide-details
        />
        <div class="controls-row">
          <v-switch label="Disabled" disabled hide-details /><v-switch
            label="Disabled"
            disabled
            :model-value="true"
            color="primary"
            hide-details
          />
        </div>
      </div>
    </div>
    <div class="button-samples mt-8">
      <v-btn
        v-for="color in ['primary', 'secondary', 'warning', 'error', 'success']"
        :key="color"
        :color="color"
        @click="open = true"
        ><Icon name="plus" :size="17" class="mr-1" />Add New</v-btn
      >
    </div>
    <v-list v-if="entries.length" aria-label="Added entries" class="mt-4"
      ><v-list-item v-for="(entry, i) in entries" :key="i" :title="entry"
        ><template #append
          ><v-btn
            icon
            variant="text"
            size="small"
            :aria-label="'Remove ' + entry"
            @click="entries.splice(i, 1)"
            ><Icon
              name="trash"
              :size="18" /></v-btn></template></v-list-item></v-list></FormPage
  ><v-dialog v-model="open" max-width="440"
    ><v-card class="pa-6"
      ><h2 class="mb-5">Add new entry</h2>
      <v-form ref="form" @submit.prevent="add"
        ><v-text-field
          v-model="newName"
          label="Entry name"
          :rules="[required]"
          hide-details="auto"
          autofocus
        />
        <div class="demo-form-actions">
          <v-btn color="primary" type="submit">Add entry</v-btn
          ><v-btn variant="text" @click="open = false">Cancel</v-btn>
        </div></v-form
      ></v-card
    ></v-dialog
  >
</template>
