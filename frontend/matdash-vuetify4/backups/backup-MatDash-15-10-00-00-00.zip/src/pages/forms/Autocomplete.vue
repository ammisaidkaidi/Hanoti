<script setup>
import { ref } from "vue";
import { VAutocomplete } from "vuetify/components";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const films = [
  "The Shawshank Redemption",
  "The Godfather",
  "The Dark Knight",
  "Pulp Fiction",
  "Forrest Gump",
  "Fight Club",
  "Inception",
  "Interstellar",
];
const addresses = [
  "demo@company.com",
  "design@company.com",
  "support@company.com",
  "hello@matdash.com",
];
const film = ref("The Dark Knight"),
  caption = ref("demo@company.com"),
  iconEmail = ref("demo@company.com"),
  multi = ref(["The Dark Knight", "Fight Club"]);
</script>
<template>
  <FormPage title="Autocomplete"
    ><div class="example-grid three">
      <ExampleCard title="Combo Box"
        ><v-autocomplete
          v-model="film"
          :items="films"
          aria-label="Favorite film"
          variant="outlined"
          density="comfortable"
          hide-details
          clearable
          color="primary"
          no-data-text="No matching films" /></ExampleCard
      ><ExampleCard title="With Caption"
        ><div class="control-stack">
          <v-autocomplete
            v-model="caption"
            :items="addresses"
            label="Email Address"
            variant="outlined"
            density="comfortable"
            hide-details
          /><v-autocomplete
            v-model="iconEmail"
            :items="addresses"
            label="Email Address with icon"
            variant="outlined"
            density="comfortable"
            hide-details
            ><template #prepend-inner><Icon name="email" :size="18" /></template
          ></v-autocomplete></div></ExampleCard
      ><ExampleCard title="Combo with Multiple Options"
        ><v-autocomplete
          v-model="multi"
          :items="films"
          multiple
          chips
          closable-chips
          label="Outlined"
          variant="outlined"
          hide-details
          color="primary"
      /></ExampleCard></div
  ></FormPage>
</template>
