<script setup>
import { reactive } from "vue";
import { VSlider, VRangeSlider } from "vuetify/components";
import { mdiVolumeHigh, mdiVolumeLow } from "@mdi/js";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const model = reactive({
  basic: 50,
  volume: 30,
  steps: 40,
  ticks: 40,
  tickSize: 40,
  custom: [30, 50, 70, 80],
  fruit: 0,
  mood: 50,
  vertical: [20, 30, 50, 60, 45],
  range: [25, 75],
});
const fruitTicks = { 0: "Figs", 1: "Lemon", 2: "Pear", 3: "Apple" };
</script>
<template>
  <FormPage title="Slider"
    ><div class="example-grid three">
      <ExampleCard title="Default"
        ><v-slider
          v-model="model.basic"
          aria-label="Default slider"
          color="primary"
          hide-details /></ExampleCard
      ><ExampleCard title="Icon"
        ><v-slider
          v-model="model.volume"
          aria-label="Volume slider"
          color="primary"
          :prepend-icon="mdiVolumeLow"
          :append-icon="mdiVolumeHigh"
          hide-details /></ExampleCard
      ><ExampleCard title="Disabled"
        ><v-slider
          :model-value="40"
          aria-label="Disabled slider"
          disabled
          hide-details /></ExampleCard
      ><ExampleCard title="Steps"
        ><v-slider
          v-model="model.steps"
          aria-label="Stepped slider"
          :step="10"
          color="primary"
          thumb-label="always"
          hide-details /></ExampleCard
      ><ExampleCard title="Ticks"
        ><v-slider
          v-model="model.ticks"
          aria-label="Ticks slider"
          :step="10"
          color="primary"
          show-ticks="always"
          thumb-label="always"
          hide-details /></ExampleCard
      ><ExampleCard title="Tick Size"
        ><v-slider
          v-model="model.tickSize"
          aria-label="Large ticks slider"
          :step="10"
          :tick-size="4"
          color="primary"
          show-ticks="always"
          thumb-label="always"
          hide-details
      /></ExampleCard>
    </div>
    <div class="example-grid mt-6">
      <ExampleCard title="Custom"
        ><div class="control-stack">
          <v-slider
            v-for="(_, i) in model.custom"
            :key="i"
            v-model="model.custom[i]"
            :aria-label="'Custom slider ' + (i + 1)"
            :color="i === 1 ? 'secondary' : 'primary'"
            :thumb-color="i === 3 ? 'secondary' : undefined"
            :track-color="i > 1 ? 'secondary' : undefined"
            :thumb-size="i === 0 ? 22 : undefined"
            hide-details
          /><v-slider
            v-model="model.fruit"
            aria-label="Fruit slider"
            :min="0"
            :max="3"
            :step="1"
            :ticks="fruitTicks"
            show-ticks="always"
            color="primary"
            hide-details
          /><v-slider
            v-model="model.mood"
            aria-label="Mood slider"
            color="primary"
            thumb-label="always"
            hide-details
            ><template #thumb-label="{ modelValue }">{{
              modelValue < 30 ? "🙁" : modelValue < 70 ? "😐" : "😊"
            }}</template></v-slider
          ><v-range-slider
            v-model="model.range"
            aria-label="Range slider"
            color="primary"
            thumb-label
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="Vertical"
        ><div class="vertical-sliders">
          <v-slider
            v-for="(_, i) in model.vertical"
            :key="i"
            v-model="model.vertical[i]"
            :aria-label="'Vertical slider ' + (i + 1)"
            direction="vertical"
            :disabled="i === 4"
            color="primary"
            thumb-label
            hide-details
          /></div
      ></ExampleCard></div
  ></FormPage>
</template>
