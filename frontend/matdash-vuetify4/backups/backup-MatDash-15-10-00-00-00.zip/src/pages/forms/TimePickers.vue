<script setup>
import { reactive } from "vue";
import { VTimePicker } from "vuetify/components";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const times = reactive({
  basic: null,
  format: null,
  scroll: null,
  seconds: null,
  primary: null,
  secondary: null,
  start: "09:00",
  end: "17:00",
});
</script>
<template>
  <FormPage title="Time Picker"
    ><div class="example-grid">
      <ExampleCard title="Default"
        ><v-time-picker
          v-model="times.basic"
          color="primary"
          title="SELECT TIME"
          class="demo-time-picker"
        />
        <p class="picker-value">
          {{ times.basic || "Choose a time" }}
        </p></ExampleCard
      ><ExampleCard title="Format"
        ><v-time-picker
          v-model="times.format"
          format="24hr"
          color="primary"
          title="SELECT TIME"
          class="demo-time-picker"
        />
        <p class="picker-value">
          24-hour format · {{ times.format || "Not selected" }}
        </p></ExampleCard
      ><ExampleCard title="Scrollable"
        ><v-time-picker
          v-model="times.scroll"
          scrollable
          color="primary"
          title="SELECT TIME"
          class="demo-time-picker" /></ExampleCard
      ><ExampleCard title="Use seconds"
        ><v-time-picker
          v-model="times.seconds"
          use-seconds
          color="primary"
          title="SELECT TIME"
          class="demo-time-picker" /></ExampleCard
      ><ExampleCard title="Colors" wide
        ><div class="picker-pair">
          <v-time-picker
            v-model="times.primary"
            color="primary"
            title="PRIMARY"
            class="demo-time-picker"
          /><v-time-picker
            v-model="times.secondary"
            color="secondary"
            title="SECONDARY"
            class="demo-time-picker"
          /></div></ExampleCard
      ><ExampleCard title="Range" wide
        ><div class="picker-pair">
          <div>
            <v-time-picker
              v-model="times.start"
              :max="times.end"
              format="24hr"
              color="primary"
              title="START TIME"
              class="demo-time-picker"
            /><v-text-field
              v-model="times.start"
              type="time"
              label="Start time"
              :max="times.end"
              class="mt-3"
              hide-details
            />
          </div>
          <div>
            <v-time-picker
              v-model="times.end"
              :min="times.start"
              format="24hr"
              color="secondary"
              title="END TIME"
              class="demo-time-picker"
            /><v-text-field
              v-model="times.end"
              type="time"
              label="End time"
              :min="times.start"
              class="mt-3"
              hide-details
            />
          </div>
        </div>
        <p class="picker-value">{{ times.start }} – {{ times.end }}</p>
        <v-alert
          v-if="times.start && times.end && times.end < times.start"
          type="error"
          variant="tonal"
          density="compact"
          class="mt-3"
          >End time must be after start time.</v-alert
        ></ExampleCard
      >
    </div></FormPage
  >
</template>
