<script setup>
import { reactive, computed } from "vue";
import { VFileInput } from "vuetify/components";
import { mdiCamera } from "@mdi/js";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const files = reactive({
  accept: null,
  chips: [],
  counter: [],
  density: null,
  multiple: [],
  icon: null,
  avatar: null,
  selection: [],
});
const normalize = (v) => (v ? (Array.isArray(v) ? v : [v]) : []);
const avatarRules = [
  (v) =>
    normalize(v).every((f) => f.size <= 2 * 1024 * 1024) ||
    "Avatar must be 2 MB or smaller.",
  (v) =>
    normalize(v).every((f) =>
      ["image/jpeg", "image/png", "image/gif"].includes(f.type),
    ) || "Choose a JPG, PNG, or GIF image.",
];
const selectedCount = computed(() =>
  Object.values(files).reduce((sum, list) => sum + normalize(list).length, 0),
);
</script>
<template>
  <FormPage title="File Inputs"
    ><div class="example-grid">
      <ExampleCard title="Accept"
        ><v-file-input
          v-model="files.accept"
          label="File input"
          accept="image/*"
          variant="outlined"
          hide-details
          clearable /></ExampleCard
      ><ExampleCard title="Chips"
        ><v-file-input
          v-model="files.chips"
          label="File input w/ chips"
          multiple
          chips
          variant="outlined"
          hide-details
          clearable /></ExampleCard
      ><ExampleCard title="Counter"
        ><v-file-input
          v-model="files.counter"
          label="File input with counter"
          multiple
          counter
          show-size
          variant="outlined"
          hide-details="auto" /></ExampleCard
      ><ExampleCard title="Density"
        ><v-file-input
          v-model="files.density"
          label="Compact file input"
          density="compact"
          variant="outlined"
          hide-details /></ExampleCard
      ><ExampleCard title="Multiple"
        ><v-file-input
          v-model="files.multiple"
          label="Multiple files"
          multiple
          variant="outlined"
          hide-details /></ExampleCard
      ><ExampleCard title="Prepend Icon"
        ><v-file-input
          v-model="files.icon"
          label="File with camera icon"
          accept="image/*"
          :prepend-icon="mdiCamera"
          variant="outlined"
          hide-details /></ExampleCard
      ><ExampleCard title="Validation"
        ><v-file-input
          v-model="files.avatar"
          label="Avatar"
          accept="image/jpeg,image/png,image/gif"
          :rules="avatarRules"
          validate-on="input"
          :prepend-icon="mdiCamera"
          variant="outlined"
          show-size
          hide-details="auto" /></ExampleCard
      ><ExampleCard title="Complex selection slots"
        ><v-file-input
          v-model="files.selection"
          label="Custom selection files"
          multiple
          show-size
          variant="outlined"
          hide-details
          ><template #selection="{ fileNames, totalBytesReadable }"
            ><div class="file-selection">
              <v-chip
                v-for="name in fileNames.slice(0, 2)"
                :key="name"
                size="small"
                color="primary"
                >{{ name }}</v-chip
              ><span v-if="fileNames.length > 2"
                >+{{ fileNames.length - 2 }} files</span
              ><small>{{ totalBytesReadable }}</small>
            </div></template
          ></v-file-input
        ></ExampleCard
      >
    </div>
    <div class="example-footer">
      <span
        >{{ selectedCount }} files selected · Files remain in memory and are not
        uploaded.</span
      ><v-btn
        variant="text"
        color="primary"
        @click="
          Object.keys(files).forEach(
            (k) => (files[k] = Array.isArray(files[k]) ? [] : null),
          )
        "
        >Clear all files</v-btn
      >
    </div></FormPage
  >
</template>
