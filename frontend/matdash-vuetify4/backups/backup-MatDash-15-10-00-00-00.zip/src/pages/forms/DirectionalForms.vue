<script setup>
import { useRoute } from "vue-router";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import DemoForm from "../../components/forms/DemoForm.vue";
import FormExtras from "../../components/forms/FormExtras.vue";
import {
  basicFields,
  accountFields,
  personalFields,
} from "../../data/form-fields";
const horizontal = useRoute().path.endsWith("form-horizontal");
const multi = [
  { section: "Account Details" },
  { key: "username", label: "Username", required: true },
  { key: "password", label: "Password", type: "password", required: true },
  { key: "email", label: "Email", type: "email", required: true },
  {
    key: "confirm",
    label: "Confirm Password",
    type: "password",
    required: true,
    confirm: true,
  },
  { section: "Personal Info" },
  ...personalFields,
];
</script>
<template>
  <FormPage :title="horizontal ? 'Horizontal Form' : 'Vertical Form'" bare
    ><div class="example-grid directional-grid">
      <ExampleCard title="Basic Layout" class="standalone-example"
        ><DemoForm
          :fields="basicFields"
          :horizontal="horizontal"
          submit-label="Send"
          form-name="Basic layout form" /></ExampleCard
      ><ExampleCard title="Basic with Icons" class="standalone-example"
        ><DemoForm
          :fields="basicFields"
          :horizontal="horizontal"
          icons
          submit-label="Send"
          form-name="Basic layout with icons" /></ExampleCard
      ><template v-if="horizontal"
        ><ExampleCard title="Form Separator" class="standalone-example"
          ><DemoForm
            :fields="accountFields"
            horizontal
            cancel
            form-name="Separated horizontal form" /></ExampleCard
        ><ExampleCard title="Form Label Alignment" class="standalone-example"
          ><DemoForm
            :fields="accountFields"
            horizontal
            align-right
            cancel
            form-name="Right-aligned labels" /></ExampleCard></template
      ><ExampleCard
        v-else
        title="Multi Column with Form Separator"
        class="standalone-example"
        wide
        ><DemoForm
          :fields="multi"
          :columns="2"
          cancel
          form-name="Multi-column form"
      /></ExampleCard>
      <div class="wide example-stack">
        <FormExtras :horizontal="horizontal" />
      </div></div
  ></FormPage>
</template>
