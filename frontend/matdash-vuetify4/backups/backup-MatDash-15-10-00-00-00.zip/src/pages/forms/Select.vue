<script setup>
import { reactive } from "vue";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const items = [
  "California",
  "Colorado",
  "Florida",
  "Georgia",
  "Texas",
  "Wyoming",
];
const model = reactive({
  basic: null,
  read: "California",
  multiple: [],
  chips: [],
  densities: [null, null, null],
});
</script>
<template>
  <FormPage title="Select"
    ><div class="example-grid">
      <ExampleCard title="Basic"
        ><v-select
          v-model="model.basic"
          :items="items"
          label="Select Item"
          density="comfortable"
          clearable /></ExampleCard
      ><ExampleCard title="Read only"
        ><v-select
          v-model="model.read"
          :items="items"
          label="Read only item"
          density="comfortable"
          readonly /></ExampleCard
      ><ExampleCard title="Multiple"
        ><v-select
          v-model="model.multiple"
          :items="items"
          label="Select Multiple"
          multiple
          hint="Pick your favorite states"
          persistent-hint
          hide-details="auto"
          density="comfortable" /></ExampleCard
      ><ExampleCard title="Chips"
        ><v-select
          v-model="model.chips"
          :items="items"
          label="Select regions"
          multiple
          chips
          closable-chips
          hint="What are the target regions"
          persistent-hint
          hide-details="auto"
          density="comfortable" /></ExampleCard
      ><ExampleCard title="Density" wide
        ><div class="control-stack">
          <v-select
            v-for="(d, i) in ['compact', 'comfortable', 'default']"
            :key="d"
            v-model="model.densities[i]"
            :items="items"
            :label="d[0].toUpperCase() + d.slice(1)"
            :density="d"
          /></div
      ></ExampleCard></div
  ></FormPage>
</template>
