<script setup>
import { reactive, ref } from "vue";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { required, validEmail, notify } from "../../composables/useFeedback";
const signup = reactive({
    name: "",
    email: "",
    password: "",
    confirm: "",
    remember: false,
  }),
  login = reactive({ email: "", password: "", remember: false }),
  leave = reactive({ email: "", password: "" });
const signupForm = ref(),
  loginForm = ref(),
  ageForm = ref(),
  leaveForm = ref();
const age = ref(null),
  checks = ref([]),
  drink = ref(null),
  checkError = ref(false),
  radioError = ref(true);
const passwordRule = (v) =>
  String(v || "").length >= 8 || "Use at least 8 characters.";
async function submit(form, model) {
  if ((await form.validate()).valid) {
    if (model?.password !== undefined) model.password = "";
    if (model?.confirm !== undefined) model.confirm = "";
    form.resetValidation();
    notify("Validation passed. Nothing was sent or saved.", "success");
  }
}
function submitChoices(radio) {
  if (radio) {
    radioError.value = !drink.value;
    if (!radioError.value) notify("Drink selected: " + drink.value, "success");
  } else {
    checkError.value = !checks.value.length;
    if (!checkError.value)
      notify("Drinks selected: " + checks.value.join(", "), "success");
  }
}
</script>
<template>
  <FormPage title="Form Validation" bare
    ><div class="example-grid">
      <ExampleCard
        title="Sign up validation"
        class="standalone-example validation-auth"
        ><img
          src="/assets/logo-Dq6uoD-m.svg"
          alt="MatDash"
          class="validation-logo"
        /><v-form
          ref="signupForm"
          @submit.prevent="submit(signupForm, signup)"
          aria-label="Sign up validation"
          ><div class="control-stack">
            <v-text-field
              v-model="signup.name"
              label="Name"
              :rules="[required]"
              hide-details="auto"
            /><v-text-field
              v-model="signup.email"
              label="Email"
              type="email"
              :rules="[required, validEmail]"
              hide-details="auto"
            /><v-text-field
              v-model="signup.password"
              label="Password"
              type="password"
              autocomplete="new-password"
              :rules="[required, passwordRule]"
              hide-details="auto"
            /><v-text-field
              v-model="signup.confirm"
              label="Confirm Password"
              type="password"
              autocomplete="new-password"
              :rules="[
                required,
                (v) => v === signup.password || 'Passwords do not match.',
              ]"
              hide-details="auto"
            />
          </div>
          <div class="validation-options">
            <v-checkbox
              v-model="signup.remember"
              label="Remember this Device"
              color="primary"
              hide-details
              density="compact"
            /><router-link to="/auth/forgot-password"
              >Forgot password?</router-link
            >
          </div>
          <v-btn type="submit" block color="primary">Submit</v-btn></v-form
        ></ExampleCard
      ><ExampleCard
        title="Login validation"
        class="standalone-example validation-auth"
        ><img
          src="/assets/logo-Dq6uoD-m.svg"
          alt="MatDash"
          class="validation-logo"
        /><v-form
          ref="loginForm"
          @submit.prevent="submit(loginForm, login)"
          aria-label="Login validation"
          ><div class="control-stack">
            <v-text-field
              v-model="login.email"
              label="Email"
              type="email"
              :rules="[required, validEmail]"
              hide-details="auto"
            /><v-text-field
              v-model="login.password"
              label="Password"
              type="password"
              autocomplete="off"
              :rules="[required, passwordRule]"
              hide-details="auto"
            />
          </div>
          <div class="validation-options">
            <v-checkbox
              v-model="login.remember"
              label="Remember this Device"
              color="primary"
              hide-details
              density="compact"
            /><router-link to="/auth/forgot-password"
              >Forgot password?</router-link
            >
          </div>
          <v-btn type="submit" block color="primary">Submit</v-btn></v-form
        ></ExampleCard
      ><ExampleCard title="Select" class="standalone-example"
        ><v-form
          ref="ageForm"
          @submit.prevent="submit(ageForm)"
          aria-label="Age validation"
          ><v-select
            v-model="age"
            :items="['Under 18', '18–25', '26–35', '36–50', 'Over 50']"
            label="Age"
            :rules="[required]"
            hide-details="auto"
            clearable
          /><v-btn type="submit" color="primary" class="mt-6"
            >Submit</v-btn
          ></v-form
        ></ExampleCard
      ><ExampleCard title="On Leave" class="standalone-example"
        ><v-form
          ref="leaveForm"
          @submit.prevent="submit(leaveForm, leave)"
          validate-on="blur"
          aria-label="On leave validation"
          ><div class="control-stack">
            <v-text-field
              v-model="leave.email"
              label="Email"
              type="email"
              :rules="[required, validEmail]"
              hide-details="auto"
            /><v-text-field
              v-model="leave.password"
              label="Password"
              type="password"
              autocomplete="off"
              :rules="[required, passwordRule]"
              hide-details="auto"
            />
          </div>
          <v-btn type="submit" color="primary" class="mt-6"
            >Submit</v-btn
          ></v-form
        ></ExampleCard
      ><ExampleCard title="Checkboxes" class="standalone-example"
        ><v-form
          @submit.prevent="submitChoices(false)"
          aria-label="Checkbox validation"
          ><p class="mb-2">{{ checks.join(", ") || "None" }}</p>
          <v-checkbox
            v-for="item in ['Tea', 'Coffee']"
            :key="item"
            v-model="checks"
            :value="item"
            :label="item"
            color="primary"
            hide-details
            @update:model-value="checkError = false"
          />
          <p v-if="checkError" class="text-error text-caption" role="alert">
            You have to choose at least one Drink
          </p>
          <v-btn type="submit" color="primary" class="mt-6"
            >Submit</v-btn
          ></v-form
        ></ExampleCard
      ><ExampleCard title="Radio" class="standalone-example"
        ><v-form
          @submit.prevent="submitChoices(true)"
          aria-label="Radio validation"
          ><p class="mb-2">{{ drink || "None" }}</p>
          <v-radio-group
            v-model="drink"
            :error-messages="radioError ? 'You have to choose one Drink' : ''"
            hide-details="auto"
            @update:model-value="radioError = false"
            ><v-radio
              v-for="item in ['Tea', 'Coffee']"
              :key="item"
              :value="item"
              :label="item"
              color="primary" /></v-radio-group
          ><v-btn type="submit" color="primary" class="mt-6"
            >Submit</v-btn
          ></v-form
        ></ExampleCard
      >
    </div></FormPage
  >
</template>
