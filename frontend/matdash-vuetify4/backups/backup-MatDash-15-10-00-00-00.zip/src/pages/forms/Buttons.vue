<script setup>
import { ref } from "vue";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { notify } from "../../composables/useFeedback";
const colors = ["primary", "secondary", "error", "warning", "success"];
const sizes = [
  ["x-small", "Extra Small"],
  ["small", "Small"],
  ["default", "Normal"],
  ["large", "Large"],
  ["x-large", "Extra Large"],
];
const iconNames = ["heart", "star", "send", "trash", "download"];
const groups = ref([0, 0, 0, 0]);
const clicked = (label) => notify(label + " button clicked.");
</script>
<template>
  <FormPage title="Buttons"
    ><div class="example-grid">
      <ExampleCard title="Base" wide
        ><div class="button-samples spread">
          <v-btn
            v-for="[variant, label] in [
              ['elevated', 'Elevates (Default)'],
              ['flat', 'Flat'],
              ['tonal', 'Tonal'],
              ['outlined', 'Outlined'],
              ['text', 'Text'],
              ['plain', 'Plain'],
            ]"
            :key="variant"
            :variant="variant"
            :color="variant === 'elevated' ? undefined : 'primary'"
            :elevation="variant === 'elevated' ? 2 : 0"
            @click="clicked(label)"
            >{{ label }}</v-btn
          >
        </div></ExampleCard
      ><ExampleCard title="Colors"
        ><div class="button-samples">
          <v-btn
            v-for="color in colors"
            :key="color"
            :color="color"
            @click="clicked(color)"
            >{{ color[0].toUpperCase() + color.slice(1) }}</v-btn
          >
        </div></ExampleCard
      ><ExampleCard title="Size"
        ><div class="button-samples">
          <v-btn
            v-for="[size, label] in sizes"
            :key="size"
            :size="size"
            color="primary"
            @click="clicked(label)"
            >{{ label }}</v-btn
          >
        </div></ExampleCard
      ><ExampleCard title="Outlined"
        ><div class="button-samples">
          <v-btn variant="outlined" color="primary" @click="clicked('Primary')"
            >Primary</v-btn
          ><v-btn
            variant="outlined"
            color="secondary"
            @click="clicked('Secondary')"
            >Secondary</v-btn
          ><v-btn variant="outlined" disabled>Disabled</v-btn
          ><v-btn
            variant="outlined"
            color="info"
            to="/forms/form-elements/combobox"
            >Link</v-btn
          >
        </div></ExampleCard
      ><ExampleCard title="Outlined Icon"
        ><div class="button-samples">
          <v-btn variant="outlined" color="error" @click="clicked('Left Icon')"
            ><Icon name="trash" :size="17" class="mr-2" />Left Icon</v-btn
          ><v-btn
            variant="outlined"
            color="secondary"
            @click="clicked('Right Icon')"
            >Right Icon<Icon name="send" :size="17" class="ml-2"
          /></v-btn></div></ExampleCard
      ><ExampleCard title="Outline Size"
        ><div class="button-samples">
          <v-btn
            v-for="[size, label] in sizes"
            :key="size"
            :size="size"
            variant="outlined"
            color="primary"
            @click="clicked(label)"
            >{{ label }}</v-btn
          >
        </div></ExampleCard
      ><ExampleCard title="Text Color"
        ><div class="button-samples">
          <v-btn
            v-for="color in colors"
            :key="color"
            :color="color"
            variant="text"
            @click="clicked(color)"
            >{{ color }}</v-btn
          >
        </div></ExampleCard
      ><ExampleCard
        v-for="outlined in [false, true]"
        :key="String(outlined)"
        :title="outlined ? 'Outlined Icon Color' : 'Icon Color'"
        ><div class="button-samples">
          <v-btn
            v-for="(color, i) in colors"
            :key="color"
            :color="color"
            :variant="outlined ? 'outlined' : 'flat'"
            icon
            size="42"
            :aria-label="
              (outlined ? 'Outlined ' : '') + iconNames[i] + ' button'
            "
            @click="clicked(iconNames[i])"
            ><Icon :name="iconNames[i]" :size="20"
          /></v-btn></div></ExampleCard
      ><ExampleCard
        v-for="outlined in [false, true]"
        :key="'sizes' + outlined"
        :title="outlined ? 'Outlined Icon Size' : 'Icon Size'"
        ><div class="button-samples">
          <v-btn
            v-for="([size, label], i) in sizes"
            :key="size"
            :size="size"
            :variant="outlined ? 'outlined' : 'flat'"
            color="primary"
            icon
            :aria-label="(outlined ? 'Outlined ' : '') + label + ' icon'"
            @click="clicked(label)"
            ><Icon name="heart" :size="14 + i * 3"
          /></v-btn></div></ExampleCard
      ><ExampleCard title="Button Group" wide
        ><div class="button-group-examples">
          <div
            v-for="(variant, i) in ['flat', 'text', 'plain', 'outlined']"
            :key="variant"
          >
            <h4>
              {{
                i === 0
                  ? "Default"
                  : variant[0].toUpperCase() + variant.slice(1)
              }}
            </h4>
            <v-btn-toggle
              v-model="groups[i]"
              mandatory
              color="primary"
              :variant="variant"
              divided
              ><v-btn
                v-for="(name, j) in ['Left', 'Center', 'Right']"
                :key="name"
                :value="j"
                :aria-label="variant + ' ' + name"
                >{{ name }}</v-btn
              ></v-btn-toggle
            >
          </div>
        </div></ExampleCard
      >
    </div></FormPage
  >
</template>
