<script setup>
import { reactive } from "vue";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { required, validEmail } from "../../composables/useFeedback";
const model = reactive({
  error: "",
  errors: "",
  loading: "",
  amount: 0,
  main: "",
  email: "",
});
</script>
<template>
  <FormPage title="Custom Inputs"
    ><div class="example-grid">
      <ExampleCard title="Error"
        ><v-text-field
          v-model="model.error"
          label="Input"
          variant="plain"
          :error-messages="['Fatal error']"
          hide-details="auto" /></ExampleCard
      ><ExampleCard title="Multiple Error"
        ><v-text-field
          v-model="model.errors"
          label="Input with multiple errors"
          variant="plain"
          :error-messages="['Fatal error', 'Another error']"
          :max-errors="2"
          hide-details="auto" /></ExampleCard
      ><ExampleCard title="Loading"
        ><v-text-field
          v-model="model.loading"
          aria-label="Loading input"
          variant="underlined"
          loading="success"
          color="success"
          hide-details /></ExampleCard
      ><ExampleCard title="Append and Prepend"
        ><v-text-field
          v-model.number="model.amount"
          aria-label="Amount"
          type="number"
          variant="underlined"
          hide-details
          ><template #prepend
            ><v-btn
              icon
              size="28"
              variant="text"
              color="secondary"
              aria-label="Decrease amount"
              @click="model.amount--"
              >−</v-btn
            ></template
          ><template #append
            ><v-btn
              icon
              size="28"
              variant="text"
              color="primary"
              aria-label="Increase amount"
              @click="model.amount++"
              >+</v-btn
            ></template
          ></v-text-field
        ></ExampleCard
      ><ExampleCard title="Hide Details"
        ><v-text-field
          v-model="model.main"
          label="Main input"
          hide-details
          density="comfortable" /></ExampleCard
      ><ExampleCard title="Rules"
        ><v-text-field
          v-model="model.email"
          label="Enter Email"
          type="email"
          :rules="[required, validEmail]"
          validate-on="blur"
          hide-details="auto"
          density="comfortable"
      /></ExampleCard></div
  ></FormPage>
</template>
