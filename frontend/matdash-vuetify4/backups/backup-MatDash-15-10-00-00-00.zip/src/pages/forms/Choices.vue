<script setup>
import { reactive } from "vue";
import { useRoute } from "vue-router";
import FormPage from "../../components/forms/FormPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const kind = useRoute().path.split("/").at(-1);
const colors = ["primary", "secondary", "success", "error", "warning"];
const state = reactive({
  custom: [true, false, null],
  colors: [true, true, true, true, true],
  labels: [true, false, false, false],
  checked: true,
  unchecked: false,
  default: [true, false, true, false],
  inset: [true, false, true, false],
  withLabel: true,
  colorSwitch: [true, true, true, true, true],
  insetColors: [true, true, true, true, true],
  radio: ["one", "Primary", "primary", "primary", "Option 1", "Option 1"],
});
</script>
<template>
  <FormPage
    :title="
      kind === 'checkbox' ? 'Checkboxes' : kind === 'radio' ? 'Radio' : 'Switch'
    "
    :heading="kind === 'checkbox' ? 'Checkbox' : undefined"
    ><div v-if="kind === 'checkbox'" class="example-grid">
      <ExampleCard title="Custom"
        ><div class="controls-row spread">
          <v-checkbox
            v-for="(_, i) in state.custom"
            :key="i"
            v-model="state.custom[i]"
            :indeterminate="state.custom[i] === null"
            :aria-label="
              ['Custom checked', 'Custom unchecked', 'Custom indeterminate'][i]
            "
            color="primary"
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="Colors"
        ><div class="controls-row">
          <v-checkbox
            v-for="(color, i) in colors"
            :key="color"
            v-model="state.colors[i]"
            :color="color"
            :aria-label="color + ' checkbox'"
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="Default"
        ><div class="controls-row">
          <v-checkbox
            v-for="(label, i) in ['Primary', 'Secondary', 'Success', 'Warning']"
            :key="label"
            v-model="state.labels[i]"
            :label="label"
            :color="label.toLowerCase()"
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="States"
        ><div class="controls-row">
          <v-checkbox
            v-model="state.checked"
            label="Checked"
            color="primary"
            hide-details
          /><v-checkbox
            v-model="state.unchecked"
            label="Unchecked"
            disabled
            hide-details
          /></div
      ></ExampleCard>
    </div>
    <div v-else-if="kind === 'radio'" class="example-grid">
      <ExampleCard title="Default"
        ><v-radio-group v-model="state.radio[0]" inline hide-details
          ><v-radio
            v-for="v in ['one', 'two', 'three']"
            :key="v"
            :value="v"
            :aria-label="'Radio ' + v"
            color="primary" /></v-radio-group></ExampleCard
      ><ExampleCard title="Label"
        ><v-radio-group v-model="state.radio[1]" inline hide-details
          ><v-radio
            v-for="v in ['Primary', 'Secondary', 'Success', 'Warning']"
            :key="v"
            :value="v"
            :label="v"
            :color="v.toLowerCase()" /></v-radio-group></ExampleCard
      ><ExampleCard title="Colors"
        ><v-radio-group v-model="state.radio[2]" inline hide-details
          ><v-radio
            v-for="v in colors.slice(0, 4)"
            :key="v"
            :value="v"
            :aria-label="v + ' radio'"
            :color="v" /></v-radio-group></ExampleCard
      ><ExampleCard title="Colors with Label"
        ><v-radio-group v-model="state.radio[3]" inline hide-details
          ><v-radio
            v-for="v in colors.slice(0, 4)"
            :key="v"
            :value="v"
            :label="v"
            :color="v" /></v-radio-group></ExampleCard
      ><ExampleCard title="Default Direction"
        ><v-radio-group v-model="state.radio[4]" hide-details
          ><v-radio
            v-for="n in 2"
            :key="n"
            :value="'Option ' + n"
            :label="'Option ' + n"
            color="primary" /></v-radio-group></ExampleCard
      ><ExampleCard title="Inline Direction"
        ><v-radio-group v-model="state.radio[5]" inline hide-details
          ><v-radio
            v-for="n in 8"
            :key="n"
            :value="'Option ' + n"
            :label="'Option ' + n"
            color="primary" /></v-radio-group
      ></ExampleCard>
    </div>
    <div v-else class="example-grid">
      <ExampleCard title="Default"
        ><div class="controls-row">
          <v-switch
            v-for="(_, i) in state.default"
            :key="i"
            v-model="state.default[i]"
            :disabled="i > 1"
            :aria-label="'Default switch ' + (i + 1)"
            color="primary"
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="Inset"
        ><div class="controls-row">
          <v-switch
            v-for="(_, i) in state.inset"
            :key="i"
            v-model="state.inset[i]"
            :disabled="i > 1"
            :aria-label="'Inset switch ' + (i + 1)"
            color="primary"
            inset
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="With Label"
        ><v-switch
          v-model="state.withLabel"
          label="Label"
          color="primary"
          hide-details /><v-switch
          label="Disabled"
          disabled
          hide-details /></ExampleCard
      ><ExampleCard
        title="States"
        description="Loading indicators are static examples; no request is running."
        ><v-switch
          :model-value="true"
          label="on loading"
          loading="warning"
          disabled
          color="primary"
          hide-details /><v-switch
          :model-value="false"
          label="off loading"
          loading="warning"
          disabled
          hide-details /></ExampleCard
      ><ExampleCard title="Colors"
        ><div class="controls-row">
          <v-switch
            v-for="(color, i) in colors"
            :key="color"
            v-model="state.colorSwitch[i]"
            :color="color"
            :aria-label="color + ' switch'"
            hide-details
          /></div></ExampleCard
      ><ExampleCard title="Inset Colors"
        ><div class="controls-row">
          <v-switch
            v-for="(color, i) in colors"
            :key="color"
            v-model="state.insetColors[i]"
            :color="color"
            :aria-label="color + ' inset switch'"
            inset
            hide-details
          /></div
      ></ExampleCard></div
  ></FormPage>
</template>
