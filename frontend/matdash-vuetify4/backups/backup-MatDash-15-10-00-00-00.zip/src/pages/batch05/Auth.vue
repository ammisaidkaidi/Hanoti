<script setup>
import { ref, reactive, computed, nextTick, onBeforeUnmount } from "vue";
import { useRoute, useRouter } from "vue-router";
import { asset } from "../../data/app-seed";
import { required, validEmail, notify } from "../../composables/useFeedback";
import { beginDemoSession } from "../../composables/useDemoAuth";
const route = useRoute(),
  router = useRouter();
const boxed = route.path.endsWith("2"),
  mode = route.path.includes("register")
    ? "register"
    : route.path.includes("forgot-password")
      ? "forgot"
      : "login";
const form = ref(),
  reveal = ref(false),
  remember = ref(false),
  success = ref(false),
  error = ref(""),
  slide = ref(0);
const values = reactive({
  name: "",
  email: mode === "login" ? "demo@matdash.local" : "",
  password: mode === "login" ? "Demo123!" : "",
});
const suffix = boxed ? "2" : "";
const loginPath = "/auth/login" + suffix;
const title = computed(() =>
  mode === "forgot"
    ? "Forgot your password?"
    : boxed
      ? mode === "login"
        ? "Let’s get you signed in"
        : "Let’s get you signed up"
      : mode === "login"
        ? "Sign in"
        : "Sign Up",
);
const slides = [
  [
    "Feature Rich 1D Charts",
    "Visualize sample data with clear, interactive charts.",
    "login-side-",
  ],
  [
    "Thoughtful Page Layouts",
    "Reusable layouts give your next application a strong starting point.",
    "main-banner-",
  ],
  [
    "Beautiful UI Components",
    "Explore forms, tables, and components built with Vuetify 4.",
    "feature-image-",
  ],
];
const passwordRule = (v) =>
  String(v || "").length >= 8 || "Use at least 8 characters.";
async function submit() {
  error.value = "";
  success.value = false;
  if (!(await form.value.validate()).valid) return;
  if (mode === "login") {
    if (
      values.email !== "demo@matdash.local" ||
      values.password !== "Demo123!"
    ) {
      error.value =
        "Use the displayed demo credentials. No account lookup was performed.";
      return;
    }
    const stored = beginDemoSession(remember.value);
    values.password = "";
    notify(
      stored
        ? "Demo session started. No real authentication was performed."
        : "Demo session started in memory. Browser storage is unavailable.",
    );
    await router.push("/dashboards/dashboard1");
  } else {
    success.value = true;
    values.password = "";
    if (mode === "forgot") values.email = "";
    await nextTick();
    form.value.resetValidation();
  }
}
onBeforeUnmount(() => {
  values.password = "";
  values.email = "";
  values.name = "";
});
</script>
<template>
  <section
    :class="['b5-auth-page', boxed ? 'b5-auth-boxed' : 'b5-auth-side']"
    data-page-ready="true"
    data-batch="5"
  >
    <div class="b5-auth-frame">
      <div class="b5-auth-form-panel">
        <router-link
          to="/front-page/homepage"
          aria-label="MatDash homepage"
          class="b5-auth-brand"
          ><img src="/assets/logo-Dq6uoD-m.svg" alt="MatDash"
        /></router-link>
        <h1>{{ title }}</h1>
        <p v-if="mode === 'forgot'" class="b5-auth-description">
          Enter the email address associated with your account to preview
          password-reset validation. This demo does not send email or reset a
          password.
        </p>
        <p v-else-if="!boxed" class="b5-auth-subtitle">Your Admin Dashboard</p>
        <template v-if="mode !== 'forgot'"
          ><div class="b5-social-auth">
            <v-btn
              v-for="provider in boxed
                ? ['Facebook', 'Google']
                : ['Google', 'Facebook']"
              :key="provider"
              variant="outlined"
              @click="
                notify(
                  provider + ' authentication is not connected in this demo.',
                  'info',
                )
              "
              ><span :class="['b5-provider', provider.toLowerCase()]">{{
                provider === "Google" ? "G" : "f"
              }}</span
              >{{ boxed ? "Sign in with " : "" }}{{ provider }}</v-btn
            >
          </div>
          <div class="b5-auth-divider">
            <span>{{
              boxed
                ? "Or sign " + (mode === "login" ? "in" : "up") + " with email"
                : "or sign in with"
            }}</span>
          </div></template
        ><v-form
          ref="form"
          @submit.prevent="submit"
          :aria-label="mode + ' demo form'"
          ><div class="b5-auth-fields">
            <div v-if="mode === 'register'">
              <label for="auth-name">Name</label
              ><v-text-field
                id="auth-name"
                v-model="values.name"
                :rules="[required]"
                autocomplete="off"
                density="comfortable"
                hide-details="auto"
              />
            </div>
            <div>
              <label for="auth-email">{{
                mode === "login"
                  ? "Username"
                  : mode === "register"
                    ? "Email Address"
                    : "Email Address"
              }}</label
              ><v-text-field
                id="auth-email"
                v-model="values.email"
                :type="mode === 'login' ? 'text' : 'email'"
                :rules="mode === 'login' ? [required] : [required, validEmail]"
                autocomplete="off"
                density="comfortable"
                hide-details="auto"
              />
            </div>
            <div v-if="mode !== 'forgot'">
              <div class="b5-password-label">
                <label for="auth-password">Password</label
                ><router-link
                  v-if="boxed && mode === 'login'"
                  :to="'/auth/forgot-password' + suffix"
                  >Forgot Password ?</router-link
                >
              </div>
              <v-text-field
                id="auth-password"
                v-model="values.password"
                :type="reveal ? 'text' : 'password'"
                :rules="[required, passwordRule]"
                autocomplete="off"
                density="comfortable"
                hide-details="auto"
                ><template #append-inner
                  ><v-btn
                    icon
                    size="28"
                    variant="text"
                    :aria-label="reveal ? 'Hide password' : 'Show password'"
                    @click="reveal = !reveal"
                    ><Icon
                      :name="reveal ? 'eyeoff' : 'eye'"
                      :size="17" /></v-btn></template
              ></v-text-field>
            </div>
          </div>
          <div v-if="mode === 'login'" class="b5-auth-options">
            <v-checkbox
              v-model="remember"
              :label="boxed ? 'Keep me logged in' : 'Remember this Device'"
              color="primary"
              density="compact"
              hide-details
            /><router-link v-if="!boxed" :to="'/auth/forgot-password' + suffix"
              >Forgot Password ?</router-link
            >
          </div>
          <v-alert
            v-if="error"
            type="error"
            variant="tonal"
            density="compact"
            class="my-4"
            role="alert"
            >{{ error }}</v-alert
          ><v-alert
            v-if="success"
            type="success"
            variant="tonal"
            density="compact"
            class="my-4"
            role="status"
            >{{
              mode === "forgot"
                ? "Email format validated. No reset email was sent and no password was changed."
                : "Registration validated locally. No account was created; the password was cleared."
            }}</v-alert
          ><v-btn
            type="submit"
            :color="boxed || mode === 'forgot' ? '#0b263c' : 'primary'"
            block
            size="large"
            class="b5-auth-submit"
            >{{
              mode === "login"
                ? "Sign In"
                : mode === "register"
                  ? "Sign Up"
                  : "Forgot Password"
            }}</v-btn
          ><v-btn
            v-if="mode === 'forgot'"
            :to="loginPath"
            color="primary"
            variant="tonal"
            block
            size="large"
            class="mt-4"
            >Back To Login</v-btn
          ></v-form
        >
        <p v-if="mode !== 'forgot'" class="b5-auth-switch">
          {{
            mode === "login"
              ? "Don’t have an account yet?"
              : "Already have an Account?"
          }}
          <router-link
            :to="mode === 'login' ? '/auth/register' + suffix : loginPath"
            >{{
              mode === "login"
                ? boxed
                  ? "Sign Up Now"
                  : "Create an account"
                : boxed
                  ? "Sign In Now"
                  : "Sign in"
            }}</router-link
          >
        </p>
        <div class="b5-auth-notice">
          <strong>Local demo only</strong>
          <p v-if="mode === 'login'">
            Username: <code>demo@matdash.local</code><br />Password:
            <code>Demo123!</code>
          </p>
          <p>
            {{
              mode === "login"
                ? "Only the demo-session flag can be remembered; credentials are never stored."
                : "Use sample information. No account, email, or password service is connected."
            }}
          </p>
        </div>
      </div>
      <aside v-if="boxed" class="b5-auth-features">
        <img :src="asset(slides[slide][2])" :alt="slides[slide][0]" />
        <h2>{{ slides[slide][0] }}</h2>
        <p>{{ slides[slide][1] }}</p>
        <v-btn to="/front-page/homepage" color="primary">Learn More</v-btn>
        <div class="b5-carousel-dots">
          <button
            v-for="(_, i) in slides"
            :key="i"
            :class="{ active: slide === i }"
            :aria-label="'Feature slide ' + (i + 1)"
            :aria-pressed="slide === i"
            @click="slide = i"
          />
        </div>
      </aside>
      <aside v-else class="b5-auth-welcome">
        <div>
          <h2>Welcome to<br />MatDash</h2>
          <p>
            MatDash helps developers to build organized and well coded
            dashboards full of beautiful and rich modules.
          </p>
          <v-btn to="/front-page/homepage" color="primary">Learn More</v-btn>
        </div>
        <svg viewBox="0 0 400 350" aria-hidden="true">
          <path
            d="M55 270L190 40M205 285L285 147M320 290L333 267"
            stroke="currentColor"
            stroke-width="75"
            stroke-linecap="round"
          />
        </svg>
      </aside>
    </div>
  </section>
</template>
