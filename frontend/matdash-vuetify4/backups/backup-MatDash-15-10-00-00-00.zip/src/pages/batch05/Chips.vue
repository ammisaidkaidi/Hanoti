<script setup>
import { ref } from "vue";
import { mdiCheck } from "@mdi/js";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { avatar } from "../../data/app-seed";
const colors = ["primary", "secondary", "warning", "success", "error", "info"],
  hidden = ref([]);
const rows = [undefined, "primary", "secondary", "success", "warning", "error"];
function remove(id) {
  hidden.value.push(id);
}
</script>
<template>
  <UiPage title="Chip"
    ><div class="example-grid">
      <ExampleCard
        v-for="variant in ['tonal', 'outlined']"
        :key="variant"
        :title="variant === 'tonal' ? 'Filled' : 'Outlined'"
        wide
        ><div class="b5-chip-row">
          <template v-for="(color, i) in rows" :key="i"
            ><v-chip :color="color" :variant="variant"
              ><template #prepend
                ><v-avatar
                  v-if="i === 1 || i === 3"
                  start
                  :image="avatar(i + 1)"
                  size="20" /><Icon
                  v-else
                  name="user"
                  :size="15"
                  class="mr-1" /></template
              >{{
                color === "primary"
                  ? "Primary"
                  : color === "secondary"
                    ? "Secondary"
                    : "Default"
              }}
              Filled</v-chip
            ><v-chip
              v-if="!hidden.includes(variant + i)"
              :color="color"
              :variant="variant"
              closable
              :close-label="'Delete ' + variant + ' chip ' + (i + 1)"
              @click:close="remove(variant + i)"
              >{{
                color === "primary"
                  ? "Primary"
                  : color === "secondary"
                    ? "Secondary"
                    : "Default"
              }}
              Deletable</v-chip
            ></template
          >
        </div></ExampleCard
      ><ExampleCard
        v-for="outlined in [false, true]"
        :key="String(outlined)"
        :title="outlined ? 'Custom Outlined Icon' : 'Custom Icon'"
        ><div class="b5-chip-row">
          <v-chip
            v-for="color in ['primary', 'secondary']"
            :key="color"
            :color="color"
            :variant="outlined ? 'outlined' : 'tonal'"
            :append-icon="mdiCheck"
            ><template #prepend
              ><Icon name="shield" :size="16" class="mr-1" /></template
            >Custom Icon</v-chip
          >
        </div></ExampleCard
      ><ExampleCard title="Disabled"
        ><div class="b5-chip-row">
          <v-chip
            v-for="color in ['primary', 'secondary']"
            :key="color"
            :color="color"
            disabled
            closable
            :append-icon="mdiCheck"
            >Custom Icon</v-chip
          >
        </div></ExampleCard
      ><ExampleCard title="Sizes"
        ><div class="b5-chip-row">
          <v-chip
            v-for="size in ['x-small', 'small', 'default', 'large', 'x-large']"
            :key="size"
            :size="size"
            color="primary"
            >{{ size === "default" ? "Default" : size }}</v-chip
          >
        </div></ExampleCard
      ><ExampleCard title="Closable" wide
        ><div class="b5-chip-row">
          <v-chip
            v-for="color in colors.filter((c) => !hidden.includes(c))"
            :key="color"
            :color="color"
            closable
            :close-label="'Delete ' + color + ' chip'"
            @click:close="remove(color)"
            >{{ color[0].toUpperCase() + color.slice(1) }} Deletable</v-chip
          >
        </div></ExampleCard
      >
    </div>
    <div class="example-footer">
      <span>Close chips individually, then restore the examples.</span
      ><v-btn color="primary" variant="text" @click="hidden = []"
        >Reset chips</v-btn
      >
    </div></UiPage
  >
</template>
