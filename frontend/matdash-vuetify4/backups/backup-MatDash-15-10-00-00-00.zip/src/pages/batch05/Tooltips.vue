<script setup>
import { ref } from "vue";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const visible = ref(false);
</script>
<template>
  <UiPage title="Tooltip" bare
    ><div class="example-grid">
      <ExampleCard title="Simple" class="standalone-example"
        ><div class="button-samples justify-center">
          <v-tooltip
            v-for="location in ['start', 'end', 'top', 'bottom']"
            :key="location"
            :text="location[0].toUpperCase() + location.slice(1) + ' tooltip'"
            :location="location"
            ><template #activator="{ props }"
              ><v-btn v-bind="props" color="primary">{{
                location[0].toUpperCase() + location.slice(1)
              }}</v-btn></template
            ></v-tooltip
          >
        </div></ExampleCard
      ><ExampleCard title="Icon" class="standalone-example"
        ><div class="button-samples justify-center">
          <v-tooltip
            v-for="[icon, color, label] in [
              ['user', 'primary', 'Profile'],
              ['shield', 'secondary', 'Security'],
              ['bell', 'warning', 'Notifications'],
              ['heart', 'error', 'Favorites'],
            ]"
            :key="label"
            :text="label"
            location="top"
            ><template #activator="{ props }"
              ><v-btn
                v-bind="props"
                :aria-label="label"
                :color="color"
                icon
                size="38"
                ><Icon :name="icon" :size="21" /></v-btn></template
          ></v-tooltip></div></ExampleCard
      ><ExampleCard title="Toggle Tolltip" class="standalone-example" wide
        ><div class="button-samples">
          <v-btn
            color="primary"
            :aria-pressed="visible"
            @click="visible = !visible"
            >{{ visible ? "Hide Tooltip" : "Show Tooltip" }}</v-btn
          ><v-tooltip
            v-model="visible"
            text="Your shopping cart"
            location="top"
            :open-on-hover="false"
            :open-on-focus="false"
            :open-on-click="false"
            ><template #activator="{ props }"
              ><v-btn
                v-bind="props"
                color="primary"
                icon
                size="42"
                aria-label="Demo cart tooltip target"
                ><Icon name="cart" :size="21" /></v-btn></template
          ></v-tooltip></div
      ></ExampleCard></div
  ></UiPage>
</template>
