<script setup>
import { ref, reactive } from "vue";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { required, validEmail, notify } from "../../composables/useFeedback";
const active = ref(null),
  nested = ref(false),
  form = ref();
const profile = reactive({ name: "", email: "" }),
  settings = reactive({ notifications: true, sound: false }),
  choice = ref("United States");
const demos = [
  ["Simple", "Open Simple Dialog", "primary"],
  ["V-model", "Open Dialog", "secondary"],
  ["Transition", "Open Transition Dialog", "success"],
  ["Form", "Open Form Dialog", "warning"],
  ["Full screen", "Open Fullscreen Dialog", "error"],
  ["Persistent", "Open Dialog", "primary"],
  ["Scrollable", "Open Scrolling Dialog", "success"],
  ["Nested Dialog", "Open Dialog 1", "secondary"],
];
function close() {
  nested.value = false;
  active.value = null;
}
async function save() {
  if (active.value === "Form" && !(await form.value.validate()).valid) return;
  notify(
    active.value === "Form"
      ? "Demo form validated. Nothing was sent."
      : active.value === "Scrollable"
        ? "Selected locally: " + choice.value
        : "Dialog changes applied to this page.",
  );
  close();
}
</script>
<template>
  <UiPage title="Dialog"
    ><div class="example-grid three">
      <ExampleCard
        v-for="[title, label, color] in demos"
        :key="title"
        :title="title"
        ><v-btn :color="color" block @click="active = title">{{
          label
        }}</v-btn></ExampleCard
      >
    </div></UiPage
  ><v-dialog
    :model-value="!!active"
    :persistent="active === 'Persistent'"
    :fullscreen="active === 'Full screen'"
    :max-width="active === 'Full screen' ? 'none' : 560"
    :scrollable="active === 'Scrollable'"
    :transition="
      active === 'Transition' ? 'dialog-bottom-transition' : 'dialog-transition'
    "
    @update:model-value="
      (value) => {
        if (!value) close();
      }
    "
    ><v-card class="b5-dialog-card"
      ><header>
        <h2>
          {{
            active === "Full screen"
              ? "Settings"
              : active === "Form"
                ? "User profile"
                : active === "Scrollable"
                  ? "Select a country"
                  : active === "Nested Dialog"
                    ? "Dialog 1"
                    : active + " Dialog"
          }}
        </h2>
        <v-btn
          v-if="active !== 'Persistent'"
          icon
          variant="text"
          aria-label="Close dialog"
          @click="close"
          ><Icon name="close"
        /></v-btn>
      </header>
      <div
        :class="[
          'b5-dialog-body',
          { 'b5-dialog-scroll': active === 'Scrollable' },
        ]"
      >
        <v-form v-if="active === 'Form'" ref="form" @submit.prevent="save"
          ><div class="control-stack">
            <v-text-field
              v-model="profile.name"
              label="Full name"
              :rules="[required]"
              hide-details="auto"
            /><v-text-field
              v-model="profile.email"
              label="Email"
              type="email"
              :rules="[required, validEmail]"
              hide-details="auto"
            /></div></v-form
        ><template v-else-if="active === 'Full screen'"
          ><h3 class="mb-5">Notifications &amp; preferences</h3>
          <v-switch
            v-model="settings.notifications"
            label="Enable notifications"
            color="primary"
            hide-details
          /><v-switch
            v-model="settings.sound"
            label="Sound effects"
            color="primary"
            hide-details
          />
          <p class="muted mt-5">
            These settings are demonstration values only.
          </p></template
        ><v-radio-group
          v-else-if="active === 'Scrollable'"
          v-model="choice"
          color="primary"
          ><v-radio
            v-for="country in [
              'United States',
              'United Kingdom',
              'Algeria',
              'Australia',
              'Austria',
              'Belgium',
              'Brazil',
              'Canada',
              'China',
              'Denmark',
              'Egypt',
              'Finland',
              'France',
              'Germany',
              'India',
              'Indonesia',
              'Italy',
              'Japan',
              'Mexico',
              'Morocco',
              'Netherlands',
              'New Zealand',
              'Norway',
              'Portugal',
              'South Africa',
              'Spain',
              'Sweden',
              'Switzerland',
              'Tunisia',
              'Turkey',
            ]"
            :key="country"
            :label="country"
            :value="country" /></v-radio-group
        ><template v-else
          ><p class="b5-prose">
            {{
              active === "Persistent"
                ? "This dialog stays open when you click outside or press Escape. Choose Agree or Disagree to close it."
                : "A dialog focuses attention on a decision or a small piece of information. This is a local demonstration of Vuetify dialog behaviour."
            }}
          </p>
          <v-btn
            v-if="active === 'Nested Dialog'"
            color="primary"
            class="mt-6"
            @click="nested = true"
            >Open Dialog 2</v-btn
          ></template
        >
      </div>
      <footer>
        <v-btn variant="text" @click="close">{{
          active === "Persistent" ? "Disagree" : "Cancel"
        }}</v-btn
        ><v-btn color="primary" @click="save">{{
          active === "Persistent"
            ? "Agree"
            : active === "Form"
              ? "Save"
              : active === "Scrollable"
                ? "Select"
                : "Done"
        }}</v-btn>
      </footer>
      <v-dialog v-model="nested" max-width="400"
        ><v-card class="dialog-body"
          ><h2>Dialog 2</h2>
          <p class="my-5">This nested dialog appears above Dialog 1.</p>
          <v-btn color="primary" @click="nested = false"
            >Close Dialog 2</v-btn
          ></v-card
        ></v-dialog
      ></v-card
    ></v-dialog
  >
</template>
