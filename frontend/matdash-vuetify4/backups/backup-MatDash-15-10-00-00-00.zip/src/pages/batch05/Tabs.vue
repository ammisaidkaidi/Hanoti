<script setup>
import UiPage from "../../components/ui/UiPage.vue";
import TabExample from "../../components/ui/TabExample.vue";
</script>
<template>
  <UiPage title="Tabs"
    ><div class="example-stack">
      <TabExample
        v-for="title in [
          'Basic',
          'Stacked',
          'Center Active',
          'Custom Icons',
          'Align Center',
          'Align End',
          'Icon',
          'Disabled',
          'Colors',
        ]"
        :key="title"
        :title="title"
      /></div
  ></UiPage>
</template>
