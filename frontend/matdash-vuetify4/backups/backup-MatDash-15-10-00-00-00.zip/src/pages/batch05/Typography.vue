<script setup>
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const text =
  "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos blanditiis tenetur";
const headingSizes = [
  [36, 60],
  [30, 36],
  [22, 32],
  [20, 25],
  [18, 25],
  [16, 25],
];
const bodyStyles = [
  ["Subtitle 1", 15, 17.6],
  ["Subtitle 2", 13, 16],
  ["Body 1", 14, 24],
  ["Body 2", 12, 24],
  ["Caption", 14, 24],
  ["Overline", 12, 24],
];
</script>
<template>
  <UiPage title="Typography" heading="Basic Typography"
    ><div class="example-stack">
      <ExampleCard title="Heading"
        ><div
          v-for="([size, line], i) in headingSizes"
          :key="i"
          class="b5-type-sample"
        >
          <component
            :is="'h' + (i + 1)"
            :style="{
              fontSize: size + 'px',
              lineHeight: line + 'px',
              fontWeight: 600,
            }"
            >h{{ i + 1 }}.Heading</component
          >
          <p>
            font size: {{ size }} | line-height: {{ line }} | font weight: 600
          </p>
        </div>
        <div
          v-for="[label, size, line] in bodyStyles"
          :key="label"
          class="b5-type-sample"
        >
          <div
            :style="{
              fontSize: size + 'px',
              lineHeight: line + 'px',
              fontWeight: 400,
              textTransform: label === 'Overline' ? 'uppercase' : undefined,
            }"
          >
            {{ label }}. {{ text }}
          </div>
          <p>
            font size: {{ size }} | line-height: {{ line }} | font weight: 400
          </p>
        </div></ExampleCard
      ><ExampleCard title="Default Text"
        ><div
          v-for="color in [
            'primary',
            'secondary',
            'info',
            'warning',
            'error',
            'success',
          ]"
          :key="color"
          class="b5-type-sample"
          :class="'text-' + color"
        >
          <h3>Text {{ color[0].toUpperCase() + color.slice(1) }}</h3>
          <p :class="'text-' + color">{{ text }}</p>
        </div></ExampleCard
      ><ExampleCard title="Text-alignment"
        ><div class="b5-type-lines">
          <p>Left aligned on all viewport sizes.</p>
          <p class="text-center">Center aligned on all viewport sizes.</p>
          <p class="text-right">Right aligned on all viewport sizes.</p>
          <p
            v-for="size in ['sm', 'md', 'lg', 'xl']"
            :key="size"
            :class="'text-' + size + '-left'"
          >
            Left aligned on viewports {{ size.toUpperCase() }} or wider.
          </p>
        </div></ExampleCard
      ><ExampleCard title="Decoration"
        ><div class="b5-type-lines">
          <router-link to="/pages/route-directory" class="text-decoration-none"
            >Non-underlined link</router-link
          >
          <p class="text-decoration-line-through">Line-through text</p>
          <p class="text-decoration-overline">Overline text</p>
          <p class="text-decoration-underline">Underline text</p>
        </div></ExampleCard
      ><ExampleCard title="Opacity"
        ><div class="b5-type-lines">
          <p class="text-high-emphasis">
            High-emphasis has an opacity of 87% in light skin and 100% in dark.
          </p>
          <p class="text-medium-emphasis">
            Medium-emphasis text and hint text have opacities of 60% in light
            skin and 70% in dark.
          </p>
          <p class="text-disabled">
            Disabled text has an opacity of 38% in light skin and 50% in dark.
          </p>
        </div></ExampleCard
      >
    </div></UiPage
  >
</template>
