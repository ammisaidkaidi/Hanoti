<script setup>
import { ref } from "vue";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { notify } from "../../composables/useFeedback";
const types = ["error", "warning", "info", "success"],
  visible = ref(true),
  warning = ref(true),
  info = ref(true);
</script>
<template>
  <UiPage title="Alert"
    ><div class="example-stack">
      <ExampleCard
        v-for="[title, variant] in [
          ['Basic', 'tonal'],
          ['Filled', 'flat'],
          ['Outlined', 'outlined'],
        ]"
        :key="title"
        :title="title"
        ><div class="b5-alert-stack">
          <v-alert
            v-for="type in types"
            :key="type"
            :type="type"
            :variant="variant"
            :icon="title === 'Basic' ? false : undefined"
            density="compact"
            >This is an {{ type }} alert — check it out!</v-alert
          >
        </div></ExampleCard
      ><ExampleCard title="Description"
        ><div class="b5-alert-stack">
          <v-alert
            v-for="type in types"
            :key="type"
            :type="type"
            variant="tonal"
            :title="type[0].toUpperCase() + type.slice(1)"
            >This is an {{ type }} alert — check it out!</v-alert
          >
        </div></ExampleCard
      ><ExampleCard title="Action"
        ><div class="b5-alert-stack">
          <v-alert
            v-if="warning"
            type="warning"
            variant="flat"
            density="compact"
            >This is a warning alert — check it out!<template #append
              ><v-btn
                variant="text"
                size="small"
                @click="
                  warning = false;
                  notify('Warning acknowledged locally.');
                "
                >Undo</v-btn
              ></template
            ></v-alert
          ><v-alert v-if="info" type="info" variant="flat" density="compact"
            >This is an info alert — check it out!<template #append
              ><v-btn
                icon
                variant="text"
                size="small"
                aria-label="Dismiss info alert"
                @click="info = false"
                ><Icon name="close" :size="18" /></v-btn></template></v-alert
          ><v-btn
            v-if="!warning || !info"
            variant="text"
            color="primary"
            @click="
              warning = true;
              info = true;
            "
            >Reset action alerts</v-btn
          >
        </div></ExampleCard
      ><ExampleCard title="With Icons"
        ><div class="b5-alert-stack">
          <v-alert
            v-for="[type, icon] in [
              ['success', 'check'],
              ['info', 'info'],
              ['warning', 'bell'],
              ['error', 'close'],
            ]"
            :key="type"
            :type="type"
            variant="tonal"
            density="compact"
            ><template #prepend><Icon :name="icon" :size="22" /></template>This
            is a {{ type }} alert.</v-alert
          >
        </div></ExampleCard
      ><ExampleCard title="Closable"
        ><v-alert
          v-model="visible"
          title="Closable Alert"
          closable
          close-label="Close closable alert"
          color="primary"
          variant="tonal"
          border="start"
          >Aenean imperdiet. Quisque id odio. Cras dapibus. Pellentesque ut
          neque. Vivamus consectetuer hendrerit lacus. Sed mollis, eros et
          ultrices tempus, mauris ipsum aliquam libero.</v-alert
        ><v-btn
          v-if="!visible"
          variant="tonal"
          color="primary"
          @click="visible = true"
          >Restore alert</v-btn
        ></ExampleCard
      >
    </div></UiPage
  >
</template>
