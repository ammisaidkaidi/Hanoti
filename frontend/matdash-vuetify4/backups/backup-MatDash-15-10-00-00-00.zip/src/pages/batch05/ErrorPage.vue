<script setup>
import { asset } from "../../data/app-seed";
</script>
<template>
  <section class="b5-error-page" data-page-ready="true" data-batch="5">
    <img :src="asset('errorimg-')" alt="404 error illustration" />
    <h1>Opps!!!</h1>
    <p>This page you are looking for could not be found.</p>
    <v-btn color="primary" to="/dashboards/dashboard1">Go Back To Home</v-btn>
  </section>
</template>
