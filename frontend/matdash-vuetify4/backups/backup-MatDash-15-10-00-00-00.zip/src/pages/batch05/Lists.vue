<script setup>
import { ref } from "vue";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const selected = ref([]),
  rounded = ref([]),
  nested = ref([]),
  wifi = ref(true),
  bluetooth = ref(false),
  folder = ref(""),
  scrollItem = ref("");
const items = [
  ["Sample Page", "file"],
  ["Elements", "shapes"],
  ["Page Layouts", "layers"],
  ["Components", "grid"],
];
</script>
<template>
  <UiPage title="Lists" heading="List"
    ><div class="example-grid">
      <ExampleCard title="Simple List"
        ><v-list v-model:selected="selected" color="primary" density="compact"
          ><v-list-item
            v-for="[name, icon] in items"
            :key="name"
            :value="name"
            :title="name"
            ><template #prepend
              ><Icon
                :name="icon"
                :size="18"
                class="mr-4" /></template></v-list-item
        ></v-list>
        <p v-if="selected.length" class="field-help">
          Selected: {{ selected[0] }}
        </p></ExampleCard
      ><ExampleCard title="Nested List"
        ><h4 class="mb-3">Nested List Items</h4>
        <v-list v-model:selected="nested" color="primary" density="compact"
          ><v-list-item title="Sent Mail" value="Sent Mail"
            ><template #prepend
              ><Icon
                name="send"
                :size="18"
                class="mr-4" /></template></v-list-item
          ><v-list-item title="Drafts" value="Drafts"
            ><template #prepend
              ><Icon
                name="file"
                :size="18"
                class="mr-4" /></template></v-list-item
          ><v-list-group value="inbox"
            ><template #activator="{ props }"
              ><v-list-item v-bind="props" title="inbox"
                ><template #prepend
                  ><Icon
                    name="email"
                    :size="18"
                    class="mr-4" /></template></v-list-item></template
            ><v-list-item title="Starred" value="Starred" /><v-list-item
              title="Important"
              value="Important" /></v-list-group
        ></v-list>
        <p v-if="nested.length" class="field-help">
          Selected: {{ nested[0] }}
        </p></ExampleCard
      ><ExampleCard title="Folder List"
        ><v-list
          ><v-list-item
            v-for="[name, date] in [
              ['Photos', 'Jan 9, 2023'],
              ['Works', 'Jan 17, 2023'],
              ['Vacation', 'Jan 18, 2023'],
            ]"
            :key="name"
            :title="name"
            :subtitle="date"
            :active="folder === name"
            color="primary"
            @click="folder = name"
            ><template #prepend
              ><v-avatar color="primary" variant="tonal" size="38" class="mr-4"
                ><Icon
                  name="folder"
                  :size="
                    19
                  " /></v-avatar></template></v-list-item></v-list></ExampleCard
      ><ExampleCard title="Disabled List"
        ><v-list disabled density="compact"
          ><v-list-item
            v-for="[name, icon] in items.slice(0, 3)"
            :key="name"
            :title="name"
            ><template #prepend
              ><Icon
                :name="icon"
                :size="18"
                class="mr-4" /></template></v-list-item></v-list></ExampleCard
      ><ExampleCard title="Switch List"
        ><v-list
          ><v-list-item title="Wi-Fi"
            ><template #prepend
              ><Icon name="globe" :size="18" class="mr-4" /></template
            ><template #append
              ><v-switch
                v-model="wifi"
                color="primary"
                aria-label="Wi-Fi"
                hide-details /></template></v-list-item
          ><v-list-item title="Bluetooth"
            ><template #prepend
              ><Icon name="phone" :size="18" class="mr-4" /></template
            ><template #append
              ><v-switch
                v-model="bluetooth"
                color="primary"
                aria-label="Bluetooth"
                hide-details /></template></v-list-item></v-list></ExampleCard
      ><ExampleCard title="Rounded List"
        ><v-list v-model:selected="rounded" color="primary" rounded="xl"
          ><v-list-item
            v-for="[name, icon] in items.slice(0, 3)"
            :key="name"
            :title="name"
            :value="name"
            rounded="xl"
            ><template #prepend
              ><Icon
                :name="icon"
                :size="18"
                class="mr-4" /></template></v-list-item></v-list></ExampleCard
      ><ExampleCard title="Custom Aligned List"
        ><v-list
          ><v-list-item
            v-for="([name, growth, value], i) in [
              ['Bajaj Finsery', '10% Profit', '$1839.00'],
              ['TTML', '10% Loss', '$100.00'],
              ['Reliance', '10% Profit', '$200.00'],
              ['TTML', '10% Loss', '$189.00'],
            ]"
            :key="i"
            :title="name"
            :subtitle="growth"
            ><template #append
              ><span class="b5-stock-value"
                >{{ value }}
                <Icon
                  name="trending"
                  :size="17"
                  :class="
                    i % 2 ? 'text-error' : 'text-success'
                  " /></span></template></v-list-item></v-list></ExampleCard
      ><ExampleCard title="Scrollable List"
        ><v-list class="b5-scroll-list" density="compact"
          ><v-list-item
            v-for="n in 200"
            :key="n"
            :title="'Item ' + n"
            :active="scrollItem === 'Item ' + n"
            color="primary"
            @click="scrollItem = 'Item ' + n"
        /></v-list>
        <p v-if="scrollItem" class="field-help">
          Selected: {{ scrollItem }}
        </p></ExampleCard
      >
    </div></UiPage
  >
</template>
