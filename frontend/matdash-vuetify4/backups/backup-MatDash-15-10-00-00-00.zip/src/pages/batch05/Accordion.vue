<script setup>
import { reactive } from "vue";
import {
  VExpansionPanels,
  VExpansionPanel,
  VExpansionPanelTitle,
  VExpansionPanelText,
} from "vuetify/components";
import { mdiPlus, mdiMinus } from "@mdi/js";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const state = reactive({
  Basic: undefined,
  "Default Expand": 0,
  Inset: undefined,
  Popout: undefined,
  Advance: undefined,
  "Customized Icon": undefined,
});
const text =
  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.";
</script>
<template>
  <UiPage title="Accordian"
    ><div class="example-stack">
      <ExampleCard
        v-for="title in Object.keys(state)"
        :key="title"
        :title="title"
        ><v-expansion-panels
          v-model="state[title]"
          :variant="
            title === 'Inset'
              ? 'inset'
              : title === 'Popout'
                ? 'popout'
                : 'accordion'
          "
          ><v-expansion-panel
            v-for="(label, i) in title === 'Advance'
              ? [
                  'General settings',
                  'Users',
                  'Advance Settings',
                  'Personal data',
                ]
              : ['Accordion 1', 'Accordion 2', 'Accordion 3']"
            :key="label"
            ><v-expansion-panel-title
              :expand-icon="title === 'Customized Icon' ? mdiPlus : undefined"
              :collapse-icon="
                title === 'Customized Icon' ? mdiMinus : undefined
              "
              ><div class="b5-accordion-title">
                <span>{{ label }}</span
                ><small v-if="title === 'Advance'" class="muted">{{
                  [
                    "I am an accordion",
                    "You are currently not an owner",
                    "Filtering has been entirely disabled for whole web server",
                    "",
                  ][i]
                }}</small>
              </div></v-expansion-panel-title
            ><v-expansion-panel-text
              ><p class="b5-prose">{{ text }}</p></v-expansion-panel-text
            ></v-expansion-panel
          ></v-expansion-panels
        ></ExampleCard
      >
    </div></UiPage
  >
</template>
