<script setup>
import { ref, mergeProps } from "vue";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { notify } from "../../composables/useFeedback";
const location = ref("bottom"),
  popover = ref(false);
const choose = (item) => notify(item + " selected in this demo.");
</script>
<template>
  <UiPage title="Menus"
    ><div class="example-grid">
      <ExampleCard title="Anchor"
        ><v-select
          v-model="location"
          label="Location"
          :items="['top', 'bottom', 'start', 'end']"
          class="mb-5" />
        <div class="b5-demo-center">
          <v-menu :location="location"
            ><template #activator="{ props }"
              ><v-btn v-bind="props" color="primary">Dropdown</v-btn></template
            ><v-list density="compact"
              ><v-list-item
                v-for="n in 4"
                :key="n"
                :title="'Item ' + n"
                @click="choose('Item ' + n)" /></v-list
          ></v-menu></div></ExampleCard
      ><ExampleCard title="Hover"
        ><div class="b5-demo-center b5-tall-example">
          <v-menu open-on-hover :open-on-click="true"
            ><template #activator="{ props }"
              ><v-btn v-bind="props" color="secondary"
                >Dropdown</v-btn
              ></template
            ><v-list density="compact"
              ><v-list-item
                v-for="n in 4"
                :key="n"
                :title="'Hover item ' + n"
                @click="choose('Hover item ' + n)" /></v-list
          ></v-menu></div></ExampleCard
      ><ExampleCard title="Activator and tooltip"
        ><div class="b5-demo-center">
          <v-menu
            ><template #activator="{ props: menuProps }"
              ><v-tooltip text="Open the example menu" location="top"
                ><template #activator="{ props: tipProps }"
                  ><v-btn
                    v-bind="mergeProps(menuProps, tipProps)"
                    color="primary"
                    >Dropdown W/ Tooltip</v-btn
                  ></template
                ></v-tooltip
              ></template
            ><v-list
              ><v-list-item
                v-for="label in ['Profile', 'Settings', 'Help']"
                :key="label"
                :title="label"
                @click="choose(label)" /></v-list
          ></v-menu></div></ExampleCard
      ><ExampleCard title="Popover"
        ><div class="b5-demo-center">
          <v-menu
            v-model="popover"
            :close-on-content-click="false"
            location="bottom"
            ><template #activator="{ props }"
              ><v-btn v-bind="props" color="secondary"
                >Menu As Popover</v-btn
              ></template
            ><v-card class="pa-6 b5-popover"
              ><h3>A little more information</h3>
              <p class="my-4 muted">
                Menus can hold more than a list. This popover keeps a short
                piece of information close to its activator.
              </p>
              <v-btn color="primary" @click="popover = false"
                >Got it</v-btn
              ></v-card
            ></v-menu
          >
        </div></ExampleCard
      >
    </div></UiPage
  >
</template>
