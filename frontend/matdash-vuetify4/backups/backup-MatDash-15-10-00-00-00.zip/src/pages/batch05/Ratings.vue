<script setup>
import { reactive } from "vue";
import {
  mdiHeart,
  mdiHeartOutline,
  mdiHeartHalfFull,
  mdiCircle,
  mdiCircleOutline,
  mdiCircleHalfFull,
} from "@mdi/js";
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
const ratings = reactive({
  basic: 3,
  clear: 3,
  hover: 3,
  half: 3.5,
  length: 5,
  label: 3,
  second: 3,
  heart: 3.5,
  circle: 3.5,
  sizes: [3, 3, 3],
});
</script>
<template>
  <UiPage title="Rating"
    ><div class="example-grid three">
      <ExampleCard title="Basic"
        ><v-rating v-model="ratings.basic" color="warning" size="29" hover />
        <p class="field-help">{{ ratings.basic }} / 5</p></ExampleCard
      ><ExampleCard title="Read Only"
        ><v-rating
          :model-value="2"
          color="warning"
          size="29"
          readonly /></ExampleCard
      ><ExampleCard title="Clearable"
        ><v-rating
          v-model="ratings.clear"
          color="warning"
          size="29"
          clearable
        />
        <p class="field-help">
          Click the current rating again to clear.
        </p></ExampleCard
      ><ExampleCard title="Hover"
        ><v-rating
          v-model="ratings.hover"
          color="warning"
          size="29"
          hover /></ExampleCard
      ><ExampleCard title="Half Ratting"
        ><v-rating
          v-model="ratings.half"
          color="warning"
          size="29"
          half-increments
          hover
        />
        <p class="field-help">{{ ratings.half }} / 5</p></ExampleCard
      ><ExampleCard title="Length"
        ><v-rating
          v-model="ratings.length"
          :length="10"
          color="warning"
          size="20"
          density="compact" /></ExampleCard
      ><ExampleCard title="Label"
        ><div class="b5-rating-labels"><span>sad</span><span>happy</span></div>
        <v-rating v-model="ratings.label" color="warning" size="29" /><v-rating
          v-model="ratings.second"
          color="warning"
          size="29"
          :item-labels="['1', '2', '3', '4', '5']"
          item-label-position="bottom" /></ExampleCard
      ><ExampleCard title="Icons"
        ><v-rating
          v-model="ratings.heart"
          half-increments
          color="error"
          :full-icon="mdiHeart"
          :empty-icon="mdiHeartOutline"
          :half-icon="mdiHeartHalfFull"
          size="28" /><v-rating
          v-model="ratings.circle"
          half-increments
          color="primary"
          :full-icon="mdiCircle"
          :empty-icon="mdiCircleOutline"
          :half-icon="mdiCircleHalfFull"
          size="28" /></ExampleCard
      ><ExampleCard title="Size"
        ><v-rating
          v-for="(size, i) in [18, 25, 32]"
          :key="size"
          v-model="ratings.sizes[i]"
          color="warning"
          :size="size"
      /></ExampleCard></div
  ></UiPage>
</template>
