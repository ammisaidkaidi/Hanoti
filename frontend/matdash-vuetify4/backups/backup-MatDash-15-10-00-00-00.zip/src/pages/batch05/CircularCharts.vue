<script setup>
import { computed, ref } from "vue";
import { useRoute } from "vue-router";
import { useTheme } from "vuetify";
import ApexChart from "vue3-apexcharts";
import WorkspacePage from "../../components/apps/WorkspacePage.vue";
import TableCard from "../../components/tables/TableCard.vue";
const radial = useRoute().path.includes("radialbar"),
  theme = useTheme(),
  show = ref({});
const charts = radial
  ? [
      {
        title: "Radialbar Chart",
        type: "radialBar",
        series: [44, 55, 67, 83],
        labels: ["Apples", "Oranges", "Bananas", "Berries"],
      },
      {
        title: "Radar Chart",
        type: "radar",
        series: [{ name: "Series 1", data: [80, 50, 30, 40, 100, 20] }],
        labels: ["January", "February", "March", "April", "May", "June"],
      },
    ]
  : [
      {
        title: "Donut Chart",
        type: "donut",
        series: [44, 55, 13, 43, 22],
        labels: ["series-1", "series-2", "series-3", "series-4", "series-5"],
      },
      {
        title: "Pie Chart",
        type: "pie",
        series: [44, 55, 13, 43, 22],
        labels: ["Team A", "Team B", "Team C", "Team D", "Team E"],
      },
    ];
const configs = computed(() =>
  charts.map((c) => ({
    chart: {
      toolbar: { show: false },
      animations: { enabled: false },
      fontFamily: "Manrope, sans-serif",
      background: "transparent",
      foreColor: theme.current.value.dark ? "#acb9cb" : "#98a4ae",
    },
    theme: { mode: theme.current.value.dark ? "dark" : "light" },
    labels: c.labels,
    colors:
      c.type === "radar"
        ? ["#635bff"]
        : ["#39c6df", "#635bff", "#ff6692", "#36c76c", "#ffd648"],
    stroke: { width: c.type === "radar" ? 2 : 0 },
    dataLabels: { enabled: false },
    legend: {
      show: c.type === "donut" || c.type === "pie",
      position: "bottom",
      fontSize: "11px",
      itemMargin: { horizontal: 7 },
    },
    plotOptions: {
      pie: { donut: { size: "68%" } },
      radialBar: {
        hollow: { size: "35%" },
        track: { background: theme.current.value.dark ? "#344254" : "#f1f3f6" },
        dataLabels: {
          name: { fontSize: "17px" },
          value: { fontSize: "20px" },
          total: {
            show: true,
            label: "Total",
            formatter: () => c.series.reduce((a, b) => a + b, 0),
          },
        },
      },
      radar: {
        polygons: {
          strokeColors: theme.current.value.dark ? "#344254" : "#edf0f4",
          fill: { colors: ["transparent"] },
        },
      },
    },
    fill: { opacity: c.type === "radar" ? 0.45 : 1 },
    xaxis: { categories: c.labels, labels: { style: { fontSize: "11px" } } },
    yaxis:
      c.type === "radar"
        ? {
            min: 0,
            max: 120,
            tickAmount: 4,
            labels: { style: { fontSize: "10px" } },
          }
        : { show: false },
    markers: { size: c.type === "radar" ? 3 : 0 },
    tooltip: { theme: theme.current.value.dark ? "dark" : "light" },
  })),
);
function values(c) {
  return c.type === "radar" ? c.series[0].data : c.series;
}
function download(c) {
  const csv =
    "Label,Value\n" +
    c.labels.map((label, i) => label + "," + values(c)[i]).join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = c.type + "-sample.csv";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
</script>
<template>
  <WorkspacePage
    :title="radial ? 'Radialbar & Radar Chart' : 'Doughnut Chart'"
    data-batch="5"
    ><div class="example-grid">
      <TableCard v-for="(c, i) in charts" :key="c.type" :title="c.title"
        ><div class="b5-circular-chart">
          <ApexChart
            :type="c.type"
            :options="configs[i]"
            :series="c.series"
            :height="350"
            width="100%"
          />
        </div>
        <div class="b5-chart-buttons">
          <v-btn
            variant="text"
            color="primary"
            size="small"
            :aria-expanded="!!show[c.type]"
            @click="show[c.type] = !show[c.type]"
            >{{ show[c.type] ? "Hide data" : "View data" }}</v-btn
          ><v-btn
            variant="tonal"
            color="primary"
            size="small"
            @click="download(c)"
            >Download CSV</v-btn
          >
        </div>
        <v-table v-if="show[c.type]" class="mt-4"
          ><thead>
            <tr>
              <th>Label</th>
              <th>Value</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(label, j) in c.labels" :key="label">
              <td>{{ label }}</td>
              <td>{{ values(c)[j] }}</td>
            </tr>
          </tbody></v-table
        ></TableCard
      >
    </div></WorkspacePage
  >
</template>
