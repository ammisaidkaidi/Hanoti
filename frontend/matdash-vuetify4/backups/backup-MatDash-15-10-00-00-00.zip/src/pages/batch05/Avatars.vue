<script setup>
import UiPage from "../../components/ui/UiPage.vue";
import ExampleCard from "../../components/forms/ExampleCard.vue";
import { avatar } from "../../data/app-seed";
const colors = ["primary", "secondary", "error", "warning", "success"];
</script>
<template>
  <UiPage title="Avatar"
    ><div class="example-grid three">
      <ExampleCard title="Image Avatars"
        ><div class="b5-avatar-row">
          <v-avatar v-for="n in [2, 3, 4]" :key="n" size="44"
            ><img :src="avatar(n)" :alt="'Sample person ' + n"
          /></v-avatar></div></ExampleCard
      ><ExampleCard title="Letter Avatars"
        ><div class="b5-avatar-row">
          <v-avatar
            v-for="(color, i) in colors"
            :key="color"
            :color="color"
            size="40"
            >{{ "ABCDE"[i] }}</v-avatar
          >
        </div></ExampleCard
      ><ExampleCard title="Icon Avatars"
        ><div class="b5-avatar-row">
          <v-avatar
            v-for="color in colors"
            :key="color"
            :color="color"
            size="40"
            ><Icon name="user" :size="22"
          /></v-avatar></div></ExampleCard
      ><ExampleCard title="Variant"
        ><div class="b5-avatar-row">
          <v-avatar
            v-for="rounded in [0, 'lg', 'circle']"
            :key="String(rounded)"
            :rounded="rounded"
            color="primary"
            size="44"
            ><Icon name="user" :size="23"
          /></v-avatar></div></ExampleCard
      ><ExampleCard title="Sizes" class="b5-span-two"
        ><div class="b5-avatar-row">
          <v-avatar
            v-for="size in [24, 32, 40, 50, 64]"
            :key="size"
            :size="size"
            ><img :src="avatar(4)" :alt="size + ' pixel avatar'"
          /></v-avatar></div
      ></ExampleCard></div
  ></UiPage>
</template>
