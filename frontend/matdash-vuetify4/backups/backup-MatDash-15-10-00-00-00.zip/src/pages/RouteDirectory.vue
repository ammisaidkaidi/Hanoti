<script setup>
import { computed, ref } from "vue";
import { routeCatalog } from "../data/navigation";
import PageHeader from "../components/PageHeader.vue";
const query = ref(""),
  category = ref("All categories"),
  status = ref("All statuses");
const categories = [
  "All categories",
  ...new Set(routeCatalog.map((p) => p.category)),
];
const ready = routeCatalog.filter((p) => p.status === "ready");
const filtered = computed(() =>
  routeCatalog.filter(
    (p) =>
      (category.value === "All categories" || p.category === category.value) &&
      (status.value === "All statuses" ||
        p.status === (status.value === "Ready" ? "ready" : "queued")) &&
      `${p.title} ${p.path}`.toLowerCase().includes(query.value.toLowerCase()),
  ),
);
const byCategory = computed(() =>
  categories
    .slice(1)
    .map((name) => ({
      name,
      pages: filtered.value.filter((p) => p.category === name),
    }))
    .filter((g) => g.pages.length),
);
</script>
<template>
  <div class="route-directory">
    <PageHeader title="Route Directory" /><v-card class="directory-intro"
      ><div>
        <span class="eyebrow">MATDASH · BUILD PROGRESS</span>
        <h2>One workspace. Every route connected.</h2>
        <p class="muted">
          All original sidebar destinations now open locally. Follow the staged
          rebuild below.
        </p>
      </div>
      <v-avatar size="72" color="lightprimary" rounded="xl"
        ><Icon name="layers" :size="34" class="text-primary" /></v-avatar
    ></v-card>
    <div class="route-metrics">
      <v-card
        ><span>Mapped routes</span><strong>{{ routeCatalog.length }}</strong>
        <p>Local navigation with Vue Router</p></v-card
      ><v-card
        ><span>Ready pages</span
        ><strong class="text-success">{{ ready.length }}</strong>
        <p>Implemented front-end pages across completed batches</p></v-card
      ><v-card
        ><span>Queued pages</span
        ><strong class="text-primary">{{
          routeCatalog.length - ready.length
        }}</strong>
        <p>Explicit placeholders, not finished recreations</p></v-card
      >
    </div>
    <v-card class="directory-content"
      ><div class="directory-filters">
        <v-text-field
          v-model="query"
          aria-label="Find a route"
          placeholder="Search pages or paths…"
          density="compact"
          ><template #prepend-inner
            ><Icon name="search" :size="19" /></template></v-text-field
        ><v-select
          v-model="category"
          :items="categories"
          aria-label="Filter route category"
        /><v-select
          v-model="status"
          :items="['All statuses', 'Ready', 'Queued']"
          aria-label="Filter route status"
        />
      </div>
      <p class="text-caption muted mb-5">
        {{ filtered.length }} routes found · “Ready” refers to the front-end
        demo; no backend is connected.
      </p>
      <section
        v-for="group in byCategory"
        :key="group.name"
        class="route-group"
      >
        <h3>
          {{ group.name }} <span>{{ group.pages.length }}</span>
        </h3>
        <div class="route-card-grid">
          <router-link
            v-for="page in group.pages"
            :key="page.path"
            :to="page.path"
            class="route-link"
            ><v-avatar size="40" color="rail" rounded="lg"
              ><Icon :name="page.icon" :size="20"
            /></v-avatar>
            <div>
              <h4>{{ page.title }}</h4>
              <code>{{ page.path }}</code>
            </div>
            <v-chip
              :color="page.status === 'ready' ? 'success' : 'primary'"
              variant="tonal"
              size="x-small"
              >{{ page.status === "ready" ? "Ready" : "Queued" }}</v-chip
            ></router-link
          >
        </div>
      </section>
      <div v-if="!filtered.length" class="route-empty">
        <Icon name="search" :size="32" />
        <h3>No matching routes</h3>
        <p class="muted">Try a different page name, category, or status.</p>
        <v-btn
          variant="tonal"
          color="primary"
          class="mt-4"
          @click="
            query = '';
            category = 'All categories';
            status = 'All statuses';
          "
          >Clear filters</v-btn
        >
      </div></v-card
    >
  </div>
</template>
