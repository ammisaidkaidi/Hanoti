<script setup>
import { useRoute } from "vue-router";
const route = useRoute();
</script>
<template>
  <v-card class="not-found"
    ><span>404</span>
    <h1>This page isn’t in your workspace</h1>
    <p class="muted">
      No route matches <code>{{ route.path }}</code
      >.
    </p>
    <div class="queued-actions">
      <v-btn color="primary" to="/dashboards/dashboard1"
        >Back to dashboard</v-btn
      ><v-btn variant="outlined" color="primary" to="/pages/route-directory"
        >Browse routes</v-btn
      >
    </div></v-card
  >
</template>
