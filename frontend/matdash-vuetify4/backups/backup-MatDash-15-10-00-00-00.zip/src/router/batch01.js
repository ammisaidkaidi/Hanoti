// Batch 1: shared implementations for twenty reference routes.
export const batch01Loaders = {
  "/ecommerce/products": () => import("../pages/apps/Products.vue"),
  "/ecommerce/productlist": () => import("../pages/apps/Products.vue"),
  "/ecommerce/product/detail/1": () =>
    import("../pages/apps/ProductDetail.vue"),
  "/ecommerce/add-product": () => import("../pages/apps/ProductEditor.vue"),
  "/ecommerce/edit-product": () => import("../pages/apps/ProductEditor.vue"),
  "/ecommerce/checkout": () => import("../pages/apps/Checkout.vue"),
  "/apps/invoice": () => import("../pages/apps/Invoices.vue"),
  "/apps/invoice/details/102": () => import("../pages/apps/Invoices.vue"),
  "/apps/invoice/create": () => import("../pages/apps/Invoices.vue"),
  "/apps/invoice/edit/102": () => import("../pages/apps/Invoices.vue"),
  "/apps/calendar": () => import("../pages/apps/Calendar.vue"),
  "/apps/email": () => import("../pages/apps/Email.vue"),
  "/apps/chats": () => import("../pages/apps/Chats.vue"),
  "/apps/notes": () => import("../pages/apps/Notes.vue"),
  "/apps/kanban": () => import("../pages/apps/Kanban.vue"),
  "/apps/contacts": () => import("../pages/apps/Contacts.vue"),
  "/apps/tickets": () => import("../pages/apps/Tickets.vue"),
  "/apps/blog/posts": () => import("../pages/apps/Blog.vue"),
  "/apps/blog/early-black-friday-amazon-deals-cheap-tvs-headphones": () =>
    import("../pages/apps/Blog.vue"),
  "/apps/user/profile": () => import("../pages/apps/Profile.vue"),
};
