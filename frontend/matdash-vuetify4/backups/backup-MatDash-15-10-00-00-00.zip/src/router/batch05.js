export const batch05Loaders = {
  "/charts/doughnut-pie-chart": () =>
    import("../pages/batch05/CircularCharts.vue"),
  "/charts/radialbar-chart": () =>
    import("../pages/batch05/CircularCharts.vue"),
  "/ui-components/alert": () => import("../pages/batch05/Alerts.vue"),
  "/ui-components/accordion": () => import("../pages/batch05/Accordion.vue"),
  "/ui-components/avatar": () => import("../pages/batch05/Avatars.vue"),
  "/ui-components/chip": () => import("../pages/batch05/Chips.vue"),
  "/ui-components/dialogs": () => import("../pages/batch05/Dialogs.vue"),
  "/ui-components/list": () => import("../pages/batch05/Lists.vue"),
  "/ui-components/menus": () => import("../pages/batch05/Menus.vue"),
  "/ui-components/rating": () => import("../pages/batch05/Ratings.vue"),
  "/ui-components/tabs": () => import("../pages/batch05/Tabs.vue"),
  "/ui-components/tooltip": () => import("../pages/batch05/Tooltips.vue"),
  "/ui-components/typography": () => import("../pages/batch05/Typography.vue"),
  "/auth/404": () => import("../pages/batch05/ErrorPage.vue"),
  "/auth/login": () => import("../pages/batch05/Auth.vue"),
  "/auth/login2": () => import("../pages/batch05/Auth.vue"),
  "/auth/register": () => import("../pages/batch05/Auth.vue"),
  "/auth/register2": () => import("../pages/batch05/Auth.vue"),
  "/auth/forgot-password": () => import("../pages/batch05/Auth.vue"),
  "/auth/forgot-password2": () => import("../pages/batch05/Auth.vue"),
};
