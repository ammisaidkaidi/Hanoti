export const batch04Loaders = {
  "/tables/basic": () => import("../pages/batch04/PlainTables.vue"),
  "/tables/dark": () => import("../pages/batch04/PlainTables.vue"),
  "/tables/density": () => import("../pages/batch04/PlainTables.vue"),
  "/tables/fixed-header": () => import("../pages/batch04/PlainTables.vue"),
  "/tables/height": () => import("../pages/batch04/PlainTables.vue"),
  "/tables/editable": () => import("../pages/batch04/Editable.vue"),
  "/tables/datatables/basic": () => import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/header": () => import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/selection": () =>
    import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/sorting": () => import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/pagination": () =>
    import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/filtering": () =>
    import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/grouping": () =>
    import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/slots": () => import("../pages/batch04/DataTables.vue"),
  "/tables/datatables/crudtable": () =>
    import("../pages/batch04/CrudTable.vue"),
  "/charts/line-chart": () => import("../pages/batch04/Charts.vue"),
  "/charts/gredient-chart": () => import("../pages/batch04/Charts.vue"),
  "/charts/area-chart": () => import("../pages/batch04/Charts.vue"),
  "/charts/candlestick-chart": () => import("../pages/batch04/Charts.vue"),
  "/charts/column-chart": () => import("../pages/batch04/Charts.vue"),
};
