// Batch 2: all thirteen form-element siblings first, then forms and Contact Us.
export const batch02Loaders = {
  "/forms/form-elements/combobox": () => import("../pages/forms/Combobox.vue"),
  "/forms/form-elements/autocomplete": () =>
    import("../pages/forms/Autocomplete.vue"),
  "/forms/form-elements/button": () => import("../pages/forms/Buttons.vue"),
  "/forms/form-elements/checkbox": () => import("../pages/forms/Choices.vue"),
  "/forms/form-elements/custominputs": () =>
    import("../pages/forms/CustomInputs.vue"),
  "/forms/form-elements/fileinputs": () =>
    import("../pages/forms/FileInputs.vue"),
  "/forms/form-elements/radio": () => import("../pages/forms/Choices.vue"),
  "/forms/form-elements/date-time": () => import("../pages/forms/DateTime.vue"),
  "/forms/form-elements/select": () => import("../pages/forms/Select.vue"),
  "/forms/form-elements/slider": () => import("../pages/forms/Sliders.vue"),
  "/forms/form-elements/switch": () => import("../pages/forms/Choices.vue"),
  "/forms/form-elements/time-picker": () =>
    import("../pages/forms/TimePickers.vue"),
  "/forms/form-elements/stepper": () => import("../pages/forms/Steppers.vue"),
  "/forms/form-layouts": () => import("../pages/forms/FormLayouts.vue"),
  "/forms/form-horizontal": () => import("../pages/forms/DirectionalForms.vue"),
  "/forms/form-vertical": () => import("../pages/forms/DirectionalForms.vue"),
  "/forms/form-custom": () => import("../pages/forms/CustomForm.vue"),
  "/forms/form-validation": () => import("../pages/forms/Validation.vue"),
  "/forms/editor": () => import("../pages/forms/Editor.vue"),
  "/front-page/contact-us": () => import("../pages/front/ContactUs.vue"),
};
