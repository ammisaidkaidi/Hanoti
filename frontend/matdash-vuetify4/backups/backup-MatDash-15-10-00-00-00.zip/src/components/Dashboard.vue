<script setup>
import { computed, ref } from "vue";
import DashboardChart from "./DashboardChart.vue";
import { productSets } from "../data/dashboard";
const tab = ref("App");
const period = ref("Sept 2025");
const selected = ref(null);
const periods = ["Sept 2025", "Oct 2025", "Nov 2025"];
const products = computed(() =>
  productSets[tab.value].map((p) => ({
    ...p,
    progress: Math.min(
      100,
      +(p.progress + periods.indexOf(period.value) * 4.1).toFixed(1),
    ),
    budget: Math.round(p.budget * (1 + periods.indexOf(period.value) * 0.08)),
  })),
);
const budget = (n) => "$" + (n / 1000).toFixed(1) + "K";
const tabs = [
  { name: "App", icon: "grid" },
  { name: "Mobile", icon: "phone" },
  { name: "Sass", icon: "calculator" },
  { name: "Others", icon: "folder" },
];
const orders = [
  {
    title: "64 new orders",
    caption: "Processing",
    icon: "store",
    color: "primary",
  },
  { title: "4 orders", caption: "On hold", icon: "shapes", color: "error" },
  { title: "6 orders", caption: "Delivered", icon: "pill", color: "secondary" },
];
defineExpose({
  selectTab: (value) => {
    tab.value = value;
    document.querySelector("#products")?.scrollIntoView({ behavior: "smooth" });
  },
});
</script>
<template>
  <div class="dashboard-grid">
    <section class="overview-stack" aria-label="Account overview">
      <v-card class="welcome-card" color="primary">
        <div class="welcome-content">
          <div class="welcome-title">
            <v-avatar size="48" rounded="lg" color="white"
              ><Icon name="trending" :size="25" class="welcome-icon"
            /></v-avatar>
            <h1>
              Welcome<br class="welcome-break" />
              Back David
            </h1>
          </div>
          <div class="welcome-stats">
            <div>
              <p>Budget</p>
              <strong>$98,450</strong>
            </div>
            <div>
              <p>Expense</p>
              <strong>$2,440</strong>
            </div>
          </div>
        </div>
        <img
          src="/assets/welcome-bg-BCkZs0On.png"
          class="welcome-image"
          alt="An arrow hitting a purple target"
        />
      </v-card>
      <div class="stats-grid">
        <v-card color="lightsecondary" class="stat-card"
          ><div class="stat-copy">
            <p>Customers</p>
            <div class="stat-value">
              <h2>36,358</h2>
              <span>-12%</span>
            </div>
          </div>
          <DashboardChart kind="customers" :height="70"
        /></v-card>
        <v-card color="lighterror" class="stat-card"
          ><div class="stat-copy">
            <p>Projects</p>
            <div class="stat-value">
              <h2>78,298</h2>
              <span>+31.8%</span>
            </div>
          </div>
          <div class="project-spark">
            <DashboardChart kind="projects" :height="55" /></div
        ></v-card>
      </div>
    </section>
    <v-card id="revenue" class="revenue-card panel">
      <div class="card-heading">
        <v-avatar size="48" rounded="lg" color="lightprimary"
          ><Icon name="layers" :size="25" class="text-primary"
        /></v-avatar>
        <div>
          <h2>Revenue Forecast</h2>
          <p class="subtitle">Overview of Profit</p>
        </div>
      </div>
      <div class="revenue-chart">
        <DashboardChart kind="revenue" :height="315" />
      </div>
    </v-card>
    <v-card id="performance" class="performance-card panel">
      <h2>Your Performance</h2>
      <p class="subtitle">Last check on 25 february</p>
      <div class="performance-content">
        <div class="order-list">
          <div v-for="order in orders" :key="order.title" class="order-item">
            <v-avatar :color="'light' + order.color" rounded="lg" size="45"
              ><Icon
                :name="order.icon"
                :class="'text-' + order.color"
                :size="25"
            /></v-avatar>
            <div>
              <h3>{{ order.title }}</h3>
              <p>{{ order.caption }}</p>
            </div>
          </div>
        </div>
        <div class="performance-gauge">
          <div class="gauge-chart">
            <DashboardChart kind="performance" :height="210" />
          </div>
          <h3>275</h3>
          <p>Learn insights how to manage all aspects of your startup.</p>
        </div>
      </div>
    </v-card>
    <div class="insights-grid">
      <v-card id="customers" class="customers-card panel"
        ><div class="d-flex justify-space-between align-center">
          <h2>Customers</h2>
          <span class="text-success growth">+26.5%</span>
        </div>
        <p class="subtitle">Last 7 days</p>
        <div class="customer-chart">
          <DashboardChart kind="customerTrend" :height="105" />
        </div>
        <div class="customer-legend">
          <div>
            <span><i class="dot purple"></i>April 07 - April 14</span
            ><span>6,380</span>
          </div>
          <div>
            <span><i class="dot pale"></i>Last Week</span><span>4,298</span>
          </div>
        </div></v-card
      >
      <v-card id="sales" class="sales-card panel"
        ><h2>Sales Overview</h2>
        <p class="subtitle">Last 7 days</p>
        <div class="sales-graphic">
          <span class="radial-label zero">0%</span
          ><span class="radial-label quarter">25%</span
          ><span class="radial-label half">50%</span
          ><span class="radial-label threequarters">75%</span
          ><DashboardChart kind="sales" :height="220" /></div
      ></v-card>
    </div>
    <div class="bottom-grid">
      <v-card id="products" class="products-card panel"
        ><div class="product-header">
          <h2>Revenue by Product</h2>
          <v-select
            v-model="period"
            :items="periods"
            aria-label="Revenue period"
            class="period-select"
          />
        </div>
        <v-tabs
          v-model="tab"
          class="product-tabs"
          hide-slider
          height="46"
          color="primary"
          ><v-tab
            v-for="item in tabs"
            :key="item.name"
            :value="item.name"
            :class="{ 'active-tab': tab === item.name }"
            ><Icon :name="item.icon" :size="16" /><span>{{
              item.name
            }}</span></v-tab
          ></v-tabs
        >
        <v-table class="product-table"
          ><thead>
            <tr>
              <th>Assigned</th>
              <th>Progress</th>
              <th>Priority</th>
              <th>Budget</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="product in products"
              :key="product.name"
              tabindex="0"
              role="button"
              :aria-label="'View ' + product.name"
              @click="selected = product"
              @keydown.enter="selected = product"
              @keydown.space.prevent="selected = product"
            >
              <td>
                <div class="product-info">
                  <v-avatar size="48" rounded="lg"
                    ><img
                      :src="'/assets/product-' + product.image + '.jpg'"
                      :alt="product.name"
                      width="48"
                      height="48"
                  /></v-avatar>
                  <div>
                    <h3>{{ product.name }}</h3>
                    <p>{{ product.person }}</p>
                  </div>
                </div>
              </td>
              <td class="muted">{{ product.progress }}%</td>
              <td>
                <v-chip
                  :color="product.color"
                  size="small"
                  rounded="sm"
                  variant="tonal"
                  >{{ product.priority }}</v-chip
                >
              </td>
              <td>{{ budget(product.budget) }}</td>
            </tr>
          </tbody></v-table
        >
        <div v-if="products.length < 4" class="table-summary">
          {{ products.length }} projects · {{ period }}
        </div>
      </v-card>
      <v-card
        id="settlements"
        class="settlements-card panel"
        color="lightprimary"
        ><div class="card-heading">
          <v-avatar color="white" size="48" rounded="lg"
            ><Icon name="package" :size="25" class="text-primary"
          /></v-avatar>
          <div>
            <p>Total settlements</p>
            <h2>$122,580</h2>
          </div>
        </div>
        <div class="settlements-chart">
          <DashboardChart kind="settlements" :height="315" />
        </div>
        <div class="settlement-totals">
          <div>
            <p>Total balance</p>
            <h3>$122,580</h3>
          </div>
          <div>
            <p>Withdrawals</p>
            <h3>$31,640</h3>
          </div>
        </div></v-card
      >
    </div>
  </div>
  <v-dialog :model-value="!!selected" @update:model-value="selected = null"
    ><v-card v-if="selected" class="pa-7" rounded="xl"
      ><div class="d-flex justify-space-between align-center mb-6">
        <h2>Project overview</h2>
        <v-btn
          icon
          size="small"
          variant="text"
          aria-label="Close project"
          @click="selected = null"
          ><Icon name="close"
        /></v-btn>
      </div>
      <div class="product-info mb-6">
        <v-avatar size="64" rounded="lg"
          ><img
            :src="'/assets/product-' + selected.image + '.jpg'"
            width="64"
            :alt="selected.name"
        /></v-avatar>
        <div>
          <h2>{{ selected.name }}</h2>
          <p class="muted">Managed by {{ selected.person }}</p>
        </div>
      </div>
      <div class="d-flex justify-space-between mb-3">
        <span>Project progress</span><strong>{{ selected.progress }}%</strong>
      </div>
      <v-progress-linear
        :model-value="selected.progress"
        height="9"
        rounded
        color="primary"
      /><v-divider class="my-6" />
      <div class="d-flex justify-space-between">
        <div>
          <p class="muted mb-2">Budget · {{ period }}</p>
          <h2>${{ selected.budget.toLocaleString() }}</h2>
        </div>
        <div>
          <p class="muted mb-2">Priority</p>
          <v-chip :color="selected.color">{{ selected.priority }}</v-chip>
        </div>
      </div>
      <p class="mt-6 text-caption muted">
        Sample project data for this dashboard preview.
      </p>
      <v-btn block color="primary" class="mt-5" @click="selected = null"
        >Done</v-btn
      ></v-card
    ></v-dialog
  >
</template>
